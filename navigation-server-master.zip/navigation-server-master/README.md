# navigation-server
navigation study server defines the RESTful API the client uses to communicate, the planning component and the explanation generation component
