package logger;

import java.io.File;
import java.io.IOException;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

public class EventLogger {

     public static final Logger LOGGER = Logger.getLogger(Logger.class.getName());
        private static FileHandler handler;

        public static void initLog(String path) {
            try {
                System.setProperty("java.util.logging.SimpleFormatter.format", "%5$s%6$s%n");
                final File logDir = new File(path);
                EventLogger.handler = new FileHandler(path);
                EventLogger.LOGGER.addHandler(handler);
                SimpleFormatter formatter = new SimpleFormatter();
                EventLogger.handler.setFormatter(formatter);
            } catch (SecurityException | IOException e) {
                System.err.println(e.getMessage());
                System.exit(-1);
            }
        }

}
