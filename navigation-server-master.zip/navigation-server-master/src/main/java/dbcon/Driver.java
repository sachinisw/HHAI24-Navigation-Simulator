package dbcon;

import logger.EventLogger;

import java.sql.*;
import java.util.Properties;
import java.util.logging.Level;

public class Driver {

    Properties properties;

    public Driver(Properties prop){
        properties = prop;
    }

    public Connection getConnection() {
        try {
            String dbuser = properties.getProperty("DB-USER");
            String dbpass = properties.getProperty("DB-PASS");
            String serverName = properties.getProperty("DB-SERVER");
            String portNumber = properties.getProperty("DB-PORT");

            //System.out.println("jdbc:" + "mysql" + "://" + serverName + ":" + portNumber + "/");
            Connection conn = DriverManager.getConnection(
                        "jdbc:" + "mysql" + "://" +
                                serverName + ":" + portNumber + "/", dbuser, dbpass);
            return conn;
        } catch (SQLException ex) {
            EventLogger.LOGGER.log(Level.SEVERE, ex.getErrorCode()+": "+ex.getMessage());
        }
        return null;
    }

    public void executeQuery (String query, Connection connection){
        try (Statement stmt = connection.createStatement()) {
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {
                String uuid = rs.getString("uuid");
                String q1 = rs.getString("q1");
                String q2 = rs.getString("q2");
                String q3 = rs.getString("q3");
                String q4 = rs.getString("q4");
                System.out.println(uuid + ", " + q1 + ", " + q2 + ", " + q3 + ", " + q4);
            }
            rs.close();
        } catch (SQLException e) {
            EventLogger.LOGGER.log(Level.SEVERE, e.getErrorCode()+": "+e.getMessage());
        }
    }

}
