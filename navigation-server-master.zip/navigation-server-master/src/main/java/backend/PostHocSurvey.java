package backend;

import java.util.Properties;

public class PostHocSurvey extends ParticipantRecord {
    public String q1;
    public String q2;
    public String q3;
    public String q4;

    public PostHocSurvey(String task, Properties log, String q1, String q2, String q3, String q4, String prolific) {
        super(task, prolific, log);
        this.q1 = q1;
        this.q2 = q2;
        this.q3 = q3;
        this.q4 = q4;
    }

    public String toString() {
        return "Subject:" + prolificId + "\n Q1:" + q1 + "\n Q2:" + q2 + "\n Q3:" + q3 + "\n Q4:" + q4 ;
    }

    public String queryInsertIntoPosthocTrust(){
        return "INSERT INTO " + prop.getProperty("DB-NAME") + ".posthoc_trust " +
                "(time, prolificid, q1, q2, q3, q4, taskid) " +
                "VALUES ((SELECT CURRENT_TIMESTAMP),?,?,?,?,?,?)";
    }
}
