package backend;

import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

public class IDGenerator {
    public static String generateId() throws NoSuchAlgorithmException {
        final SecureRandom random = SecureRandom.getInstance("SHA1PRNG");
        final byte[] bytes = new byte[5];
        random.nextBytes(bytes);
        return IDGenerator.byteArrayToHex(bytes);
    }

    public static String byteArrayToHex(final byte[] bytes) {
        final StringBuffer sb = new StringBuffer();
        for (int i = 0; i < bytes.length; i++) {
            final String theHex = Integer.toHexString(bytes[i] & 0xFF).toUpperCase();
            sb.append(theHex.length() == 1 ? "0" + theHex : theHex);
        }
        return sb.toString();
    }
}