package backend;

import java.util.Properties;


public class ParticipantRecord {
    public String prolificId;
    public Properties prop;
    public String agentName;

    public ParticipantRecord(String agent, String prolific, Properties log) {
        this.prop = log;
        this.prolificId = prolific;
        this.agentName = agent;
    }

    public String querySelectParticipantFromInformedConsent(){
        return "SELECT prolificid from " + prop.getProperty("DB-NAME") + ".informed_consent " +
                "WHERE prolificid=?";
    }
}