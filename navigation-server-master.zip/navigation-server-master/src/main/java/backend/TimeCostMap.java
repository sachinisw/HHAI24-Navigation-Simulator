package backend;

import com.google.gson.JsonArray;

import java.util.Properties;

public class TimeCostMap {
    int [] times;

    public TimeCostMap(Properties properties){
        int height = Integer.parseInt(properties.getProperty("MAP-HEIGHT"));
        int width = Integer.parseInt(properties.getProperty("MAP-WIDTH"));
        times = new int[height*width];
    }

    public void populate(Properties properties){ //cost maps are hardcoded in config file. same map to all participants
        String values = properties.getProperty("DISTANCE-COSTS");
        String [] items = values.split(",");
        int index = 0;
        for(String s: items){
            times[index++] = Integer.parseInt(s);
        }
    }

    public void populate(JsonArray times) {
        for(int i=0; i<times.size(); i++){
            String s = times.get(i).getAsString();
            this.times[i] = Integer.parseInt(s);
        }
    }

    public String toString(){
        StringBuilder costs = new StringBuilder();
        for (int j : times) {
            costs.append(j).append(",");
        }
        return costs.substring(0,costs.length()-1);
    }

    public int[] getTimes(){
        return times;
    }
}
