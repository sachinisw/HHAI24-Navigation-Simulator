package backend;

import java.util.Properties;

public class Demographics extends ParticipantRecord {
    public String q1;
    public String q2;
    public String q3;
    public String q4;
    public String q5;
    public String q6;
    public String q7;
    public String q8;
    public String q9;
    public String q10;
    public String q11;
    private static final String TYPE = "DEMOGRAPHICS";

    public Demographics(String q1, String q2, String q3,
                             String q4, String q5, String q6,
                             String q7, String q8, String q9,
                             String q10, String q11,
                             String prolific, Properties prop) {
        super(TYPE, prolific, prop);
        this.q1 = q1;
        this.q2 = q2;
        this.q3 = q3;
        this.q4 = q4;
        this.q5 = q5;
        this.q6 = q6;
        this.q7 = q7;
        this.q8 = q8;
        this.q9 = q9;
        this.q10 = q10;
        this.q11 = q11;
    }

    @Override
    public String toString() {
        return "Subject:" + this.prolificId + "\n Q1:" + this.q1 + "\n Q2:" + this.q2 +
                "\n Q3:" + this.q3 + "\n Q4:" + this.q4 + "\n Q5:" + this.q5 +
                "\n Q6:" + this.q6 + "\n Q7:" + this.q7 + "\n Q8:" + this.q8 + "\n Q9:" + this.q9 +
                "\n Q10:" + this.q10 + "\n Q11:" + this.q11;
    }


    public String queryInsertIntoDemographics(){
        return "INSERT INTO " + prop.getProperty("DB-NAME") + ".demographics " +
                "(time, prolificid, q1, q2, q3, q4, q5, q6, q7, q8, q9, q10, q11) " +
                "VALUES ((SELECT CURRENT_TIMESTAMP),?,?,?,?,?,?,?,?,?,?,?,?)";
    }
}