package backend;

import java.util.Properties;

public class InterimSurvey extends ParticipantRecord {
    public String rating;
    public String landmark;
    public String helpfulness;
    public String helpfulnessExplained;


    public InterimSurvey(String task, String loc, Properties log, String q1, String prolific, String help, String helpex) {
        super(task, prolific, log);
        this.rating = q1;
        this.landmark = loc;
        helpfulness = help;
        helpfulnessExplained = helpex;
    }

    public String toString() {
        return "Subject:" + prolificId + "\n Q1:" + rating + "\n Q2:" + helpfulness + "\n Q3:" + helpfulnessExplained ;
    }

    public String queryInsertIntoInterimTrust(){
        return "INSERT INTO "+ prop.getProperty("DB-NAME") + ".landmark_trust " +
                "(time, prolificid, q1, landmark, taskid, helprating, explanation) " +
                "VALUES ((SELECT CURRENT_TIMESTAMP),?,?,?,?,?,?)";
    }
}
