package backend;

import com.google.gson.JsonArray;

import java.util.Properties;

public class SafetyCostMap {
    int [] safeties;

    public SafetyCostMap(Properties properties){
        int height = Integer.parseInt(properties.getProperty("MAP-HEIGHT"));
        int width = Integer.parseInt(properties.getProperty("MAP-WIDTH"));
        safeties = new int[height*width];
    }

    public void populate(Properties properties) { //cost maps are hardcoded in config file. same map to all participants
        String values = properties.getProperty("SAFETY-COSTS");
        String[] items = values.split(",");
        int index = 0;
        for (String s : items) {
            safeties[index++] = Integer.parseInt(s);
        }
    }

    public void populate(JsonArray safeties) {
        for(int i=0; i<safeties.size(); i++){
            String s = safeties.get(i).getAsString();
            this.safeties[i] = Integer.parseInt(s);
        }
    }

    public String toString(){
        StringBuilder costs = new StringBuilder();
        for (int j : safeties) {
            costs.append(j).append(",");
        }
        return costs.substring(0,costs.length()-1);
    }

    public String toStringSpaceSeparated(){
        StringBuilder costs = new StringBuilder();
        for (int j : safeties) {
            costs.append(j).append(" ");
        }
        return costs.substring(0,costs.length()-1);
    }

    public int[] getSafeties(){
        return safeties;
    }
}
