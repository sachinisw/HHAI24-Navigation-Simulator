package backend;
import java.util.Properties;

public class ConsentSurvey extends ParticipantRecord {
    public String q1;
    public String q2;
    public String q3;
    public String q4;
    public String q5;
    public String q6;
    public String q7;
    public String q8;
    private static final String TYPE = "CONSENT";

    public ConsentSurvey(final String q1, final String q2, final String q3,
                              final String q4, final String q5, final String q6,
                              final String q7, final String q8, final String prolific,
                         Properties prop) {
        super(ConsentSurvey.TYPE, prolific, prop);
        this.q1 = q1;
        this.q2 = q2;
        this.q3 = q3;
        this.q4 = q4;
        this.q5 = q5;
        this.q6 = q6;
        this.q7 = q7;
        this.q8 = q8;
    }

    @Override
    public String toString() {
        return "Subject:" + prolificId + "\n ProlificId:" + prolificId +"\n Q1:" + q1 + "\n Q2:" + q2 +
                "\n Q3:" + q3 + "\n Q4:" + q4 + "\n Q5:" + q5 +
                "\n Q6:" + q6 + "\n Q7:" + q7 + "\n Q8:" + q8 ;
    }

    public String queryInsertIntoInformedConsent(){
        return "INSERT INTO " + prop.getProperty("DB-NAME") + ".informed_consent " +
                "(time, prolificid, q1, q2, q3, q4, q5, q6, q7, q8) " +
                "VALUES ((SELECT CURRENT_TIMESTAMP),?,?,?,?,?,?,?,?,?)";
    }

}
