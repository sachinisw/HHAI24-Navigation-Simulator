package backend;

public class Constants {
    public static final String ERR_DIRECTORY = "Failed to create directory";
    public static final String ERR_DBCON = "Failed to connect to the database";
    public static final String ERR_SQL = "Failed to execute the SQL statement";
    public static final String ERR_USER = "The Prolific ID already exists in the database";
}