package messages;

public class DemographicsResponse {

    private final String type = "DEMOGRAPHICS-RESPONSE";
    private String uuid;
    private String message;

    public DemographicsResponse(final String usr, final String msg) {
        uuid = usr;
        message = msg;
    }

    public String getType() {
        return type;
    }

    @Override
    public String toString() {
        return "DemographicSurveyResponse{" +
                ", uuid='" + this.uuid + '\'' +
                ", type='" + this.type + '\'' +
                ", message=" + this.message +
                '}';
    }
}
