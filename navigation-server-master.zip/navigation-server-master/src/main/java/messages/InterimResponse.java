package messages;

public class InterimResponse {
    private String type = "INTERIM-RESPONSE";
    private String uuid;
    private String message;

    public InterimResponse(String usr, String msg, String loc) {
        this.uuid = usr;
        this.message = msg;
        this.type += "-"+loc;
    }

    @Override
    public String toString() {
        return "InterimResponse{" +
                ", uuid='" + uuid + '\'' +
                ", type='" + type + '\'' +
                ", message=" + message +
                '}';
    }
}
