package messages;

public class PosthocResponse {
    private String type = "POSTHOC-RESPONSE";
    private String uuid;
    private String message;

    public PosthocResponse(String usr, String msg, String taskid) {
        this.uuid = usr;
        this.message = msg;
        this.type += "-"+taskid;
    }

    @Override
    public String toString() {
        return "PosthocResponse{" +
                ", uuid='" + uuid + '\'' +
                ", type='" + type + '\'' +
                ", message=" + message +
                '}';
    }
}
