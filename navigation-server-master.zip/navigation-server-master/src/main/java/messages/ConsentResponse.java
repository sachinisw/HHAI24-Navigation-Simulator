package messages;

public class ConsentResponse {
    private final String type = "CONSENT-RESPONSE";
    private String message;
    private String prolificId;

    public ConsentResponse(String prolific, String msg) {
        this.message = msg;
        this.prolificId = prolific;
    }

    @Override
    public String toString() {
        return "ConsentResponse{" +
                ", prolificid='" + prolificId + '\'' +
                ", type='" + type + '\'' +
                ", message=" + message +
                '}';
    }

}
