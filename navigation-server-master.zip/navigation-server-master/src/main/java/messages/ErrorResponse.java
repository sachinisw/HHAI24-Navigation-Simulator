package messages;


public class ErrorResponse {
    private final String type = "ERROR-RESPONSE";
    private String msg;

    public ErrorResponse(String msg) {
        this.msg = msg;
    }

    @Override
    public String toString() {
        return "ErrorResponse{" +
                "msg='" + this.msg + '\'' +
                ", type='" + this.type + '\'' +
                '}';
    }

}
