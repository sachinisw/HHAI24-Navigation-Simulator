package messages;

public class FrontEndEventLogResponse {

    private final String type = "FRONTENDEVENTLOG-RESPONSE";
    private String uuid;
    private String message;

    public FrontEndEventLogResponse(final String usr, final String msg) {
        uuid = usr;
        message = msg;
    }

    public String getType() {
        return type;
    }

    @Override
    public String toString() {
        return "FrontEndEventLogResponse{" +
                ", uuid='" + this.uuid + '\'' +
                ", type='" + this.type + '\'' +
                ", message=" + this.message +
                '}';
    }
}
