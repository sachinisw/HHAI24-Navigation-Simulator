package messages;

public class ClientRequest {
    private String type = ""; //start game, end game, consent, satisfaction survey, phase 1 demographics, phase 2 demographics
    private String parameters = ""; //user id, user steps

    public ClientRequest(final String parameters, final String type) {
        this.parameters = parameters;
        this.type = type;
    }

    public String getParameters() {
        return this.parameters;
    }

    public void setParameters(final String parameters) {
        this.parameters = parameters;
    }

    public String getType() {
        return this.type;
    }

    public void setId(final String t) {
        type = t;
    }

    @Override
    public String toString() {
        return "ClientRequest{" +
                "type='" + this.type + '\'' + "parameters='" + this.parameters + '\'' + "'}'";
    }
}