package server;

import java.util.ArrayList;
import java.util.Properties;
import java.util.Random;

public class CounterBalance {
    // each participant does all three tasks. the task order must be counter balanced.
    // new: TIME (SAFETY BLIND) and SAFETY configurations make 2 counter balanced assignments.
    private static final Random random = new Random();

    public static String getTaskOrder(Properties properties){
        ArrayList<String> order = new ArrayList<>();
        order.add(properties.getProperty("TASK-SAFETY")+"@"+properties.getProperty("TASK-TIME"));
        order.add(properties.getProperty("TASK-TIME")+"@"+properties.getProperty("TASK-SAFETY"));

        //return order.get(random.nextInt(order.size()));
        return order.get(0);
    }

}
