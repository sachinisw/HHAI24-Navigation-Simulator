package server;

import backend.SafetyCostMap;
import backend.TimeCostMap;

import java.util.Arrays;

public class Grid {
    public int rows;
    public int columns;
    public int grocery;
    public int home;
    public int hospital;
    public int construction;
    public int school;
    public int [] blocked;
    public TimeCostMap timeCosts;
    public SafetyCostMap safetyCosts;

    public Grid(int r, int c, int hm, int hs, int g, int ct, int s, int[] b, TimeCostMap ti, SafetyCostMap sf){
        rows = r;
        columns = c;
        home = hm;
        hospital = hs;
        grocery = g;
        construction = ct;
        school = s;
        blocked = b;
        timeCosts = ti;
        safetyCosts = sf;
    }

    @Override
    public String toString() {
        return "Grid{" +
                "rows=" + rows +
                ", columns=" + columns +
                ", grocery=" + grocery +
                ", home=" + home +
                ", hospital=" + hospital +
                ", construction=" + construction +
                ", school=" + school +
                ", blocked=" + Arrays.toString(blocked) +
                ", time=" + timeCosts.toString() +
                ", safety=" + safetyCosts.toString() +
                '}';
    }
}
