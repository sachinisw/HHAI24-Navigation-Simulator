package server;

import java.util.Arrays;

public class InitialPlanningTask {
    private final String type = "START-RESPONSE";
    private Grid game;
    private String uuid;
    private String taskId;
    private String taskOrder;
    private String[] solution;
    private int solutionCost;
    private int init;
    private int goal;

    public InitialPlanningTask(String usr, String tid, String order, Grid game, String[] steps, int cost, int from, int to) {
        this.game = game; //rows, columns, 3 stops, start, end
        uuid = usr;
        taskId  = tid;
        taskOrder = order;
        solution = steps;
        solutionCost = cost;
        init = from;
        goal = to;
    }

    @Override
    public String toString() {
        return "GameStartResponse{" +
                "game='" + game + '\'' +
                ", uuid='" + uuid + '\'' +
                ", taskId='" + taskId + '\'' +
                ", taskOrder='" + taskOrder + '\'' +
                ", solution=" + Arrays.toString(solution) + '\'' +
                ", cost=" + solutionCost + '\'' +
                ", from=" + init + '\'' +
                ", to=" + goal + '\'' +
                '}';
    }
}
