package server;

import java.util.Arrays;

public class ModifiedPlanningTask extends PlanningTask {
    public final String type = "CHOICE-RESPONSE";

    public ModifiedPlanningTask(String usr, String tid, String cs, Grid gm, String[] steps, int a, int cost, String i, String g) {
        super(usr, tid, cs, gm, steps, a, cost, i, g);
    }

    @Override
    public String toString() {
        return "GameModifyResponse{" +
                "game='" + game + '\'' +
                ", uuid='" + uuid + '\'' +
                ", taskId='" + taskId + '\'' +
                ", cause='" + cause + '\'' +
                ", solution=" + Arrays.toString(solution) + '\'' +
                ", solutionCost=" + solutionCost + '\'' +
                ", at=" + at + '\'' +
                ", init =" + init + '\'' +
                ", goal=" + goal + '\'' +
                '}';
    }
}
