package server;

public class PlanningTask {
    public Grid game;
    public String uuid;
    public String taskId;
    public String cause;
    public String[] solution;
    public int solutionCost;
    public int at;
    public String init;
    public String goal;

    public PlanningTask(String usr, String tid, String cs, Grid gm, String[] steps, int a, int cost, String i, String g) {
        this.game = gm; //rows, columns, 3 stops, start, end
        uuid = usr;
        taskId  = tid;
        solution = steps;
        at = a;
        solutionCost = cost;
        cause = cs;
        init = i;
        goal = g;
    }
}
