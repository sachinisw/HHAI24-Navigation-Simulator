package server;

import java.util.Arrays;

public class PlanningTaskForNextMilestone extends PlanningTask {
    public final String type = "NEXT-MILESTONE-RESPONSE";

    public PlanningTaskForNextMilestone(String usr, String tid, String cs, Grid gm, String[] steps, int a, int cost, String i, String g) {
        super(usr, tid, cs, gm, steps, a, cost, i, g);
    }

    @Override
    public String toString() {
        return "GameNextMilestoneResponse{" +
                "game='" + game + '\'' +
                ", uuid='" + uuid + '\'' +
                ", taskId='" + taskId + '\'' +
                ", cause='" + cause + '\'' +
                ", solution=" + Arrays.toString(solution) + '\'' +
                ", solutionCost=" + solutionCost + '\'' +
                ", at=" + at + '\'' +
                ", init =" + init + '\'' +
                ", goal =" + goal + '\'' +
                '}';
    }
}
