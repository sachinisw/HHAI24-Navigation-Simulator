package server;

import backend.*;
import com.google.gson.*;
import com.google.gson.reflect.TypeToken;
import dbcon.Driver;
import logger.EventLogger;
import messages.*;
import planning.*;
import spark.Request;
import spark.Response;
import spark.Spark;

import java.io.*;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.sql.*;
import java.util.Date;
import java.util.*;
import java.util.logging.Level;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Server {
    public static String upMode = "";

    public static void main(final String[] args) {
        Server.upMode = args[0];
        Server.run();
    }

    public static void run() {
        final Properties properties = Server.setupServer(Server.upMode);
        if (properties != null) {
            final Server server = new Server();
            switch (Server.upMode) {
                case "REMOTE":
                    EventLogger.LOGGER.log(Level.INFO, "Server Starting on Production Mode Remotely With Security");
                    server.startSecureServer(properties);
                    break;
                case "LOCAL":
                    EventLogger.LOGGER.log(Level.INFO, "Server Starting on Production Mode Remotely");
                    server.startServer(properties);
                    break;
                case "NONE":
                    EventLogger.LOGGER.log(Level.INFO, "Server Starting on Development Mode Locally");
                    server.startServer(properties);
                    break;
                default:
                    EventLogger.LOGGER.log(Level.SEVERE, "ERROR: Unknown Server Starting Mode");
                    System.exit(-1);
                    break;
            }
        } else {
            System.err.println("Error During Server Setup. Exiting...");
            System.exit(-1);
        }
    }

    public static Properties setupServer(final String mode) {
        Properties properties = null;
        switch (mode) {
            case "NONE":
                properties = Server.initLocalProperties();
                break;
            case "REMOTE":
                properties = Server.initRemoteSecureProperties();
                break;
            case "LOCAL":
                properties = Server.initRemoteProperties();
                break;
        }

        return properties;
    }

    public static Properties initLocalProperties() {
        Properties prop = null;
        try (final InputStream input = Server.class.getClassLoader().getResourceAsStream("config.properties")) {
            prop = new Properties();
            if (input == null) {
                System.err.println("Unable to find config.properties");
                return null;
            }
            prop.load(input);
        } catch (final IOException ex) {
            System.err.println(ex.getMessage());
        }
        return prop;
    }

    public static Properties initRemoteSecureProperties() {
        Properties prop = null;
        try (final InputStream input = Server.class.getClassLoader().getResourceAsStream("webacad017.config.properties")) {
            prop = new Properties();
            if (input == null) {
                System.err.println("Unable to find webacad017.config.properties file");
                return null;
            }
            prop.load(input);
        } catch (final IOException ex) {
            System.err.println(ex.getMessage());
        }
        return prop;
    }

    public static Properties initRemoteProperties() {
        Properties prop = null;
        try (final InputStream input = Server.class.getClassLoader().getResourceAsStream("webacad017.local.config.properties")) {
            prop = new Properties();
            if (input == null) {
                System.err.println("Unable to find webacad017.local.config.properties file");
                return null;
            }
            prop.load(input);
        } catch (final IOException ex) {
            System.err.println(ex.getMessage());
        }
        return prop;
    }

    public void startSecureServer(Properties properties) {
        EventLogger.initLog(properties.getProperty("SERVERLOG"));
        final Gson gson = new Gson();
        Spark.secure(properties.getProperty("KEYSTORE"), properties.getProperty("KEYSTOREPASS"), null, null);
        Spark.port(Integer.parseInt(properties.getProperty("SERVERPORT")));
        Spark.post("/api", this::handleClientRequest, gson::toJson); //Create new listener
    }

    public void startServer(final Properties properties) { //unsecure localhost for testing
        EventLogger.initLog(properties.getProperty("SERVERLOG"));
        final Gson gson = new Gson();
        Spark.port(Integer.parseInt(properties.getProperty("SERVERPORT")));
        Spark.post("/api", this::handleClientRequest, gson::toJson); //Create new listener post target name = api handled by method handleClientRequest())
    }

    private void setHeaders(Response res) {
        res.header("Content-Type", "application/json; text/html"); // Declares returning type json
        if(Server.upMode.equals("REMOTE") || Server.upMode.equals("LOCAL")){
            res.header("Access-Control-Allow-Origin", "https://collabplan-9090.nms.kcl.ac.uk");
        }else{
            res.header("Access-Control-Allow-Origin", "http://localhost:9090");
        }
        res.header("Access-Control-Allow-Headers", "Content-Type, x-requested-with");

    }

    private Object handleClientRequest(final Request request, final Response response) {
        this.setHeaders(response); //Set the return headers
        final JsonParser parser = new JsonParser();
        final JsonElement elm = parser.parse(request.body()); //Grab the json body from POST
        final Gson gson = new Gson();
        final ClientRequest fromClient = gson.fromJson(elm, ClientRequest.class);
        EventLogger.LOGGER.log(Level.INFO, this.getTimestamp() + "  ::" + " Received message from client:" + fromClient);
        String jsonResult = "";
        Properties properties = null;
        switch (Server.upMode) {
            case "REMOTE":
                properties = Server.initRemoteSecureProperties();
                break;
            case "LOCAL":
                properties = Server.initRemoteProperties();
                break;
            case "NONE":
                properties = Server.initLocalProperties();
                break;
            default:
                System.err.println("The server must be started with the LOCAL or REMOTE option");
                System.exit(-1); //server up mode not set

        }
        if (fromClient.getType().equals(properties.getProperty("EVENT-CONSENT"))) { //after consent agree, client sends 10-item consent check
            jsonResult = this.receiveBeginSession(fromClient.getParameters(), properties);
        } else if (fromClient.getType().equals(properties.getProperty("EVENT-START-GAME"))){
            jsonResult = this.sendInitialPlanningTask(fromClient.getParameters(), properties);
        } else if (fromClient.getType().equals(properties.getProperty("EVENT-USER-CHOICE"))){
            jsonResult = this.sendPlanningTaskForUserChoice(fromClient.getParameters(), properties);
        } else if (fromClient.getType().equals(properties.getProperty("EVENT-NEXT-MILESTONE"))){
            jsonResult = this.sendPlanningTaskForUserChoice(fromClient.getParameters(), properties);
        } else if (fromClient.getType().equals(properties.getProperty("EVENT-INTERIM"))){
            jsonResult = this.receiveInterimQuestionnaire(fromClient.getParameters(), properties);
        } else if (fromClient.getType().equals(properties.getProperty("EVENT-DEMOGRAPHY"))) {
            jsonResult = this.receiveDemographics(fromClient.getParameters(), properties);
        } else if (fromClient.getType().equals(properties.getProperty("EVENT-POSTHOC"))) {
            jsonResult = this.receivePostHoc(fromClient.getParameters(), properties);
        } else if(fromClient.getType().equals(properties.getProperty("EVENT-NEXT-GAME"))){
            jsonResult = this.sendNextPlanningTask(fromClient.getParameters(), properties);
        } else if(fromClient.getType().equals(properties.getProperty("EVENT-FRONTEND-EVENTLOG"))){
            jsonResult = this.saveEventLog(fromClient.getParameters(), properties);
        }
        EventLogger.LOGGER.log(Level.INFO, this.getTimestamp() + "  ::" + " Sending response to client:" + jsonResult);
        return jsonResult;
    }

    private void printPlannerStdout(Process proc){ //DEBUG METHOD
        BufferedReader reader = new BufferedReader(new InputStreamReader(proc.getInputStream(), StandardCharsets.UTF_8));
        String line;
        try{
            while((line = reader.readLine()) != null){
                System.out.println("stdout: "+ line);
            }
        }catch(IOException e){
            System.err.println("Exception in reading output"+ e);
        }
    }

    public String receiveInterimQuestionnaire(String param, final Properties properties){
        final Gson gson = new Gson();
        final JsonElement element = gson.fromJson(param, JsonElement.class);
        final JsonObject object = element.getAsJsonObject();
        final String taskId = object.get("taskid").getAsString();
        final String quiz = object.get("quiz").getAsString();
        final String prolific = object.get("prolificid").getAsString();
        final JsonArray rating = object.get("answers").getAsJsonArray();
        String q1 = "", q2 = "", q3 = "";
        for (int i = 0; i < rating.size(); i++) {
            final JsonObject ob = rating.get(i).getAsJsonObject();
            final Set<Map.Entry<String, JsonElement>> entries = ob.entrySet();
            for (Object o : entries) {
                final Map.Entry entry = (Map.Entry) o;
                if (entry.getKey().equals("q1")) {
                    q1 = entry.getValue().toString();
                }else if (entry.getKey().equals("q2")) {
                    q2 = entry.getValue().toString();
                }else if (entry.getKey().equals("q3")) {
                    q3 = entry.getValue().toString();
                }
            }
        }
        final InterimSurvey interim = new InterimSurvey(taskId, quiz, properties, q1, prolific, q2, q3);
        String result = saveInterimSurvey(properties, interim);
        String logInterimResult = "Interim-questionnaire-responses-saved-to-database " + getTimestamp() + "@" + "prolific-id " + prolific + "@" + " db-access-result " + result;
        writeToUserLog(properties, prolific, logInterimResult);
        return result;
    }

    public String saveInterimSurvey(Properties properties, InterimSurvey interim){
        Driver driver = new Driver(properties);
        Connection connection = driver.getConnection();
        String sql = interim.queryInsertIntoInterimTrust();
        if(connection!=null){
            try {
                PreparedStatement insert = connection.prepareStatement(sql);
                connection.setAutoCommit(false);

                insert.setString(1, interim.prolificId);
                insert.setString(2, interim.rating);
                insert.setString(3, interim.landmark);
                insert.setString(4, interim.agentName);
                insert.setString(5, interim.helpfulness);
                insert.setString(6, interim.helpfulnessExplained);

                insert.executeUpdate();
                connection.commit();
                insert.close();
                connection.close();
                InterimResponse ir = new InterimResponse(interim.prolificId, properties.getProperty("RESPONSE-CODE-SUCCESS"), interim.landmark);
                Gson gsonResponse = new Gson();
                Type resultType = new TypeToken<InterimResponse>() {}.getType();
                return gsonResponse.toJson(ir, resultType);
            } catch (SQLException e) {
                EventLogger.LOGGER.log(Level.SEVERE, e.getSQLState()+ " "+ e.getMessage());
                return produceSQLErrorResponse();
            }
        }else{
            EventLogger.LOGGER.log(Level.SEVERE, "Creating connection to the database server failed");
            return produceDBConErrorResponse();
        }
    }

    public String receivePostHoc(String param, final Properties properties){
        final Gson gson = new Gson();
        final JsonElement element = gson.fromJson(param, JsonElement.class);
        final JsonObject object = element.getAsJsonObject();
        final String taskId = object.get("taskid").getAsString();
        final String prolificid = object.get("prolificid").getAsString();
        final JsonArray rating = object.get("answers").getAsJsonArray();
        String q1 = "", q2 = "", q3= "" , q4 = "";
        for (int i = 0; i < rating.size(); i++) {
            final JsonObject ob = rating.get(i).getAsJsonObject();
            final Set<Map.Entry<String, JsonElement>> entries = ob.entrySet();
            for (Object o : entries) {
                final Map.Entry entry = (Map.Entry) o;
                if (entry.getKey().equals("q1")) {
                    q1 = entry.getValue().toString();
                } else if (entry.getKey().equals("q2")) {
                    q2 = entry.getValue().toString();
                } else if (entry.getKey().equals("q3")) {
                    q3 = entry.getValue().toString();
                } else if (entry.getKey().equals("q4")) {
                    q4 = entry.getValue().toString();
                }
            }
        }
        final PostHocSurvey post = new PostHocSurvey(taskId, properties, q1, q2, q3, q4, prolificid);
        String result =  savePostHoc(properties, post);
        String logPosthocResult = "Posthoc-questionnaire-responses-saved-to-database " + getTimestamp() + "@" + "prolific-id " + prolificid + "@" + " db-access-result " + result;
        writeToUserLog(properties, prolificid, logPosthocResult);
        return result;
    }

    public String savePostHoc(Properties properties, PostHocSurvey posthoc) {
        Driver driver = new Driver(properties);
        Connection connection = driver.getConnection();
        String sql = posthoc.queryInsertIntoPosthocTrust();
        if (connection != null) {
            try {
                PreparedStatement insert = connection.prepareStatement(sql);
                connection.setAutoCommit(false);

                insert.setString(1, posthoc.prolificId);
                insert.setString(2, posthoc.q1);
                insert.setString(3, posthoc.q2);
                insert.setString(4, posthoc.q3);
                insert.setString(5, posthoc.q4);
                insert.setString(6, posthoc.agentName);

                insert.executeUpdate();
                connection.commit();
                insert.close();
                connection.close();
                PosthocResponse pr = new PosthocResponse(posthoc.prolificId, properties.getProperty("RESPONSE-CODE-SUCCESS"), posthoc.agentName);
                Gson gsonResponse = new Gson();
                Type resultType = new TypeToken<PosthocResponse>() {
                }.getType();
                return gsonResponse.toJson(pr, resultType);
            } catch (SQLException e) {
                EventLogger.LOGGER.log(Level.SEVERE, e.getSQLState() + " " + e.getMessage());
                return produceSQLErrorResponse();
            }
        } else {
            EventLogger.LOGGER.log(Level.SEVERE, "Creating connection to the database server failed");
            return produceDBConErrorResponse();
        }
    }

    public String sendPlanningTaskForUserChoice(String param, final Properties properties){
        final Gson gson = new Gson();
        final JsonElement element = gson.fromJson(param, JsonElement.class);
        final JsonObject object = element.getAsJsonObject();
        final String user = object.get("uid").getAsString();
        final String task = object.get("task").getAsString();
        final String cause = object.get("cause").getAsString();
        final JsonArray landmarks = object.get("visited").getAsJsonArray(); //which stops have been visited
        final JsonArray safety = object.get("safety").getAsJsonArray();
        final JsonArray times = object.get("times").getAsJsonArray();
        final JsonArray blocked = object.get("blocked").getAsJsonArray();
        final int choice = object.get("choice").getAsInt(); //which cell did the user pick to go
        final int at = object.get("at").getAsInt(); //where is the blob currently
        final long timestamp = object.get("timestamp").getAsLong();

        int rows = Integer.parseInt(properties.getProperty("MAP-HEIGHT")),
                columns = Integer.parseInt(properties.getProperty("MAP-WIDTH")),
                start = Integer.parseInt(properties.getProperty("GRID-POS-HOME")),
                end = Integer.parseInt(properties.getProperty("GRID-POS-HOSPITAL")),
                construction = Integer.parseInt(properties.getProperty("GRID-POS-CONSTRUCTION")),
                school = Integer.parseInt(properties.getProperty("GRID-POS-SCHOOL")),
                grocery = Integer.parseInt(properties.getProperty("GRID-POS-GROCERY")); //positions are zero-index based

        int[] stops = new int[landmarks.size()];
        for(int i=0; i<landmarks.size(); i++){
            String s = landmarks.get(i).getAsString();
            if(s.matches("[0-9]+")){
                stops[i] = Integer.parseInt(s);
            }else{
                stops[i] = -1;
            }
        }

        TimeCostMap timeCosts = new TimeCostMap(properties);
        timeCosts.populate(times);

        SafetyCostMap safetyCosts = new SafetyCostMap(properties);
        safetyCosts.populate(safety);

        int[] blockedCells = new int[blocked.size()];
        for(int i=0; i<blocked.size(); i++){
            String s = blocked.get(i).getAsString();
            blockedCells[i] = Integer.parseInt(s);
        }

        Grid domain = new Grid(rows, columns, start, end, grocery, construction, school, blockedCells, timeCosts, safetyCosts);
        RLPolicy policy = generateRLPlanForUserChoice(user, properties, String.valueOf(choice), stops, blockedCells, domain, task);
        String changedPlanningTask;
        System.out.println("----planner successful"+ policy.SxA);
        if(policy!=null){
            String points [] = policy.getPolicyAsArray(); // non-deterministic planner
            int planCost = 0;

            String logChangedPlan;
            if(!cause.equals("MILESTONE_REACHED")){
                ModifiedPlanningTask problem = new ModifiedPlanningTask(user, task, cause, domain, points, at, planCost, policy.initialState, policy.goalState);
                final Gson gsonResponse = new Gson();
                final Type resultType = new TypeToken<ModifiedPlanningTask>() {
                }.getType();
                changedPlanningTask = gsonResponse.toJson(problem, resultType);

                logChangedPlan = "User-started-direction-change " + getTimestamp() + "@" + "prolific-id " + user + "@" + "planning-task " + changedPlanningTask;
            }else{
                PlanningTaskForNextMilestone problem = new PlanningTaskForNextMilestone(user, task, cause, domain, points, at, planCost, policy.initialState, policy.goalState);
                final Gson gsonResponse = new Gson();
                final Type resultType = new TypeToken<PlanningTaskForNextMilestone>() {
                }.getType();
                changedPlanningTask = gsonResponse.toJson(problem, resultType);
                logChangedPlan = "Milestone-reached-replan-to-next-milestone " + getTimestamp() + "@" + "prolific-id " + user + "@" + "planning-task " + changedPlanningTask;

            }
            writeToUserLog(properties, user, logChangedPlan);
            return changedPlanningTask;
        }else{
            ErrorResponse error = new ErrorResponse(properties.getProperty("ERROR-CODE-PLAN"));
            final Gson gsonResponse = new Gson();
            final Type resultType = new TypeToken<ErrorResponse>() {
            }.getType();
            String changePlanError = gsonResponse.toJson(error, resultType);
            String logChangedPlanErr = "User-started-direction-change " + getTimestamp() + "@" + "prolific-id " + user + "@" + "planning-task-error " + changePlanError;
            writeToUserLog(properties, user, logChangedPlanErr);
            return changePlanError;
        }
    }

    public String sendInitialPlanningTask(String userId, final Properties properties){
        //generate the task order for this user.
        //send the plan + the domain for the first task + remaining task order to the client
        String order = CounterBalance.getTaskOrder(properties);
        String [] configs = order.split("@");

        StringBuilder remainingTasks = new StringBuilder();
        for(int i=1; i< configs.length; i++){
            remainingTasks.append(configs[i]).append("@");
        }
        int rows = Integer.parseInt(properties.getProperty("MAP-HEIGHT")),
                columns = Integer.parseInt(properties.getProperty("MAP-WIDTH")),
                start = Integer.parseInt(properties.getProperty("GRID-POS-HOME")),
                end = Integer.parseInt(properties.getProperty("GRID-POS-HOSPITAL")),
                construction = Integer.parseInt(properties.getProperty("GRID-POS-CONSTRUCTION")),
                school = Integer.parseInt(properties.getProperty("GRID-POS-SCHOOL")),
                grocery = Integer.parseInt(properties.getProperty("GRID-POS-GROCERY")); //positions are zero-index based

        TimeCostMap times = new TimeCostMap(properties);
        SafetyCostMap safety = new SafetyCostMap(properties);
        times.populate(properties);
        safety.populate(properties);

        Grid domain = new Grid(rows, columns, start, end, grocery, construction, school, null, times, safety);
        RLPolicy policy = generateInitialRLPlan(userId, properties, configs[0]);            //RL planner
        System.out.println("NON DETERMINISTIC PLAN======================"+ policy.SxA);
        if(policy!=null){
            String [] points = policy.getPolicyAsArray();
            int planCost = 0; //deterministic planner. not relevant for non-det

            InitialPlanningTask task = new InitialPlanningTask(userId, configs[0], remainingTasks.substring(0,remainingTasks.length()-1), domain, points, planCost,
                    Integer.parseInt(policy.initialState), Integer.parseInt(policy.goalState));
            final Gson gsonResponse = new Gson();
            final Type resultType = new TypeToken<InitialPlanningTask>() {
            }.getType();
            String initialPlanningTask = gsonResponse.toJson(task, resultType);
            String logInitialPlan = "Initial-plan-task-send " + getTimestamp() + "@" + "prolific-id " + userId + "@" + "planning-task " + initialPlanningTask;
            writeToUserLog(properties, userId, logInitialPlan);
            return initialPlanningTask;
        }else{
            ErrorResponse error = new ErrorResponse(properties.getProperty("ERROR-CODE-PLAN"));
            final Gson gsonResponse = new Gson();
            final Type resultType = new TypeToken<ErrorResponse>() {
            }.getType();
            String initialPlanningTaskError = gsonResponse.toJson(error, resultType);
            String logInitialPlanErr = "Initial-plan-task-error " + getTimestamp() + "@" + "prolific-id " + userId + "@" + "planning-task-error " + initialPlanningTaskError;
            writeToUserLog(properties, userId, logInitialPlanErr);
            return initialPlanningTaskError;
        }
    }

    public String sendNextPlanningTask(String param, final Properties properties){
        //generate the task order for this user.
        //send the plan + the domain for the first task + task order to the client
        final Gson gson = new Gson();
        final JsonElement element = gson.fromJson(param, JsonElement.class);
        final JsonObject jsonObject = element.getAsJsonObject();
        final String prolific = jsonObject.get("prolific").getAsString();
        final String order = jsonObject.get("order").getAsString();  //remaining task configs
        int rows = Integer.parseInt(properties.getProperty("MAP-HEIGHT")),
                columns = Integer.parseInt(properties.getProperty("MAP-WIDTH")),
                start = Integer.parseInt(properties.getProperty("GRID-POS-HOME")),
                end = Integer.parseInt(properties.getProperty("GRID-POS-HOSPITAL")),
                construction = Integer.parseInt(properties.getProperty("GRID-POS-CONSTRUCTION")),
                school = Integer.parseInt(properties.getProperty("GRID-POS-SCHOOL")),
                grocery = Integer.parseInt(properties.getProperty("GRID-POS-GROCERY")); //positions are zero-index based

        String [] configs = order.split("@");
        String thisTask = configs[0];
        StringBuilder remainingTasks = new StringBuilder();
        if(configs.length>1){
            for(int i=1; i<configs.length; i++){
                remainingTasks.append(configs[i]).append("@");
            }
        }else{
            remainingTasks = new StringBuilder(properties.getProperty("EVENT-TASKS-FINISHED") + "@");
        }
        TimeCostMap times = new TimeCostMap(properties);
        SafetyCostMap safety = new SafetyCostMap(properties);
        times.populate(properties);
        safety.populate(properties);

        Grid domain = new Grid(rows, columns, start, end, grocery, construction, school, null, times, safety);
        RLPolicy policy = generateInitialRLPlan(prolific, properties, thisTask);        //nondeterministic planner

        if(policy!=null){
            int plancost = 0;
            String [] points = policy.getPolicyAsArray(); // non-deterministic planner

            InitialPlanningTask task = new InitialPlanningTask(prolific, configs[0], remainingTasks.substring(0, remainingTasks.length()-1), domain, points, plancost,
                    Integer.parseInt(policy.initialState), Integer.parseInt(policy.goalState));
            final Gson gsonResponse = new Gson();
            final Type resultType = new TypeToken<InitialPlanningTask>() {
            }.getType();
            String nextPlanningTask = gsonResponse.toJson(task, resultType);
            String logNextPlan = "Next-plan-task-send " + getTimestamp() + "@" + "prolific-id " + prolific + "@" + "next-planning-task " + nextPlanningTask;
            writeToUserLog(properties, prolific, logNextPlan);
            return nextPlanningTask;

        }else{
            ErrorResponse error = new ErrorResponse(properties.getProperty("ERROR-CODE-PLAN"));
            final Gson gsonResponse = new Gson();
            final Type resultType = new TypeToken<ErrorResponse>() {
            }.getType();
            String nextPlanningTaskErr = gsonResponse.toJson(error, resultType);
            String logNextPlanErr = "Next-plan-task-task-err " + getTimestamp() + "@" + "prolific-id " + prolific + "@" + "next-planning-task-error " + nextPlanningTaskErr;
            writeToUserLog(properties, prolific, logNextPlanErr);
            return nextPlanningTaskErr;
        }
    }

    //returns the q-value map from running value-iteration algorithm from home location to the first closest landmark.
    private RLPolicy generateInitialRLPlan(String user, Properties properties, String order) {
        int rows = Integer.parseInt(properties.getProperty("MAP-HEIGHT")),
                columns = Integer.parseInt(properties.getProperty("MAP-WIDTH")),
                start = Integer.parseInt(properties.getProperty("GRID-POS-HOME")),
                end = Integer.parseInt(properties.getProperty("GRID-POS-HOSPITAL")),
                construction = Integer.parseInt(properties.getProperty("GRID-POS-CONSTRUCTION")),
                school = Integer.parseInt(properties.getProperty("GRID-POS-SCHOOL")),
                grocery = Integer.parseInt(properties.getProperty("GRID-POS-GROCERY")); //positions are zero-index based

        TimeCostMap times = new TimeCostMap(properties);
        SafetyCostMap safety = new SafetyCostMap(properties);
        times.populate(properties);
        safety.populate(properties);

        Grid domain = new Grid(rows, columns, start, end, grocery, construction, school, null, times, safety);

        if (order.equalsIgnoreCase(properties.getProperty("TASK-SAFETY"))) {
            System.out.println("SAFETY TASK--------------------------------------------");
            RLPlanner rlp = new RLPlanner(properties);
            String milestones = String.valueOf(domain.grocery) ;
            String costmap = domain.safetyCosts.toStringSpaceSeparated();
            return rlp.getRLPolicy("SAFETY", String.valueOf(domain.home), milestones, costmap);
        } else {
            System.out.println("TIME TASK--------------------------------------------");
            RLPlanner rlp = new RLPlanner(properties);
            String milestones = String.valueOf(domain.grocery); //+ " "+ domain.school + " " + domain.construction + " " + domain.hospital;
            String costmap = domain.safetyCosts.toStringSpaceSeparated();
            return rlp.getRLPolicy("TIME", String.valueOf(domain.home), milestones, costmap);
        }
    }

    //generates plan from running value-iteration algorithm from where the user initiated an interrupt
    public RLPolicy generateRLPlanForUserChoice(String user, Properties properties, String choice, int[] stops, int[] blockedCells,  Grid domain, String order){
        //milestones should only have unvisited locs. already visited are in stops[].
        StringBuilder nextMilestone = new StringBuilder();
        StringBuilder costmap = new StringBuilder();
        ArrayList<Integer> landmarks = new ArrayList<>();
        ArrayList<Integer> stopsList = new ArrayList<>();

        landmarks.add(domain.home);
        landmarks.add(domain.grocery);
        landmarks.add(domain.school);
        landmarks.add(domain.construction);
        landmarks.add(domain.hospital);
        for (int s : stops) {
            stopsList.add(s);
        }
        for(int s:landmarks){ //add the first unvisited landmark as the next destination.
            if(!stopsList.contains(s) && s!=-1){
                nextMilestone.append(s).append(" ");
                break;
            }
        }

        //changed blocked cells [] costs to 100
        int[] costs =  domain.safetyCosts.getSafeties();
        for(int s:blockedCells){
            costs[s] = Integer.parseInt(properties.getProperty("MAX-COST"));
        }
        for(int s:costs){
            costmap.append(s).append(" ");
        }
        System.out.println("cm==="+costmap);
        System.out.println("ms==="+nextMilestone);
        if (order.equalsIgnoreCase(properties.getProperty("TASK-SAFETY"))) {
            System.out.println("USER CHOICE SAFETY TASK--------------------------------------------");
            RLPlanner rlp = new RLPlanner(properties);
            return rlp.getRLPolicy("SAFETY", choice, nextMilestone.toString(), costmap.toString());
        } else {
            System.out.println("USER CHOICE TIME TASK--------------------------------------------");
            RLPlanner rlp = new RLPlanner(properties);
            return rlp.getRLPolicy("TIME", choice, nextMilestone.toString(), costmap.toString() );
        }
    }

    public int[] convertPolicyToArray(String result){
        int length = 0;
        String sol = result.split("#")[1];
        Pattern extractsteps = Pattern.compile("\\([0-9],\\s[0-9]\\)");
        Matcher m = extractsteps.matcher(sol);
        ArrayList<Integer> temp = new ArrayList<>();

        while(m.find()){
            String c = m.group();
            String [] parts;
            parts = c.substring(c.indexOf("(")+1, c.indexOf(")")).split(",");
            temp.add(Integer.parseInt(parts[0].trim())*10 + Integer.parseInt(parts[1].trim()));
            length++;
        }
        int[] points = new int[length];
        int index = 0;
        for (Integer i: temp ) {
            points[index++] = i;
        }
        return points;
    }

    public int getPlanCost(String result){
        String[] parts = result.split("#");
        return Integer.parseInt(parts[0]);
    }

    public String invokeFD(Properties prop, String domain, String problem, String output, String outfilename, boolean parameterized) {
        final FDPlanner fd = new FDPlanner(prop, domain, problem);
        final FDPlan plan = fd.getFDPlan(output, outfilename);
        if (plan != null) {
            StringBuilder actions = new StringBuilder();
            if(parameterized) {
                for (String action : plan.getActions()) {
                    actions.append(action).append(",");
                }
            }else{
                for (String action : plan.getActions()) {
                    String s = action.replace("_", " ");
                    actions.append(s).append(",");
                }
            }
            if(plan.getPlanCost()>0) {
                return plan.getPlanCost() + "#" + actions.substring(0, actions.length() - 1);
            }else{
                return 0 + "#" + "EMPTY_PLAN";
            }
        } else { //some error occurred. plan not found
            return prop.getProperty("ERROR-CODE-PLAN");
        }
    }

    public String receiveBeginSession(String param, final Properties properties) {
        String q1 = "", q2 = "", q3 = "", q4 = "", q5 = "", q6 = "", q7 = "", q8 = "";
        final Gson gson = new Gson();
        final JsonElement element = gson.fromJson(param, JsonElement.class);
        final JsonObject jsonObject = element.getAsJsonObject();
        final JsonArray answers = jsonObject.get("answers").getAsJsonArray();
        final String prolific = jsonObject.get("prolific").getAsString();
        for (int i = 0; i < answers.size(); i++) {
            final JsonObject object = answers.get(i).getAsJsonObject();
            final Set<Map.Entry<String, JsonElement>> entries = object.entrySet();
            for (Object o : entries) {
                final Map.Entry entry = (Map.Entry) o;
                if (entry.getKey().equals("q1")) {
                    q1 = entry.getValue().toString();
                } else if (entry.getKey().equals("q2")) {
                    q2 = entry.getValue().toString();
                } else if (entry.getKey().equals("q3")) {
                    q3 = entry.getValue().toString();
                } else if (entry.getKey().equals("q4")) {
                    q4 = entry.getValue().toString();
                } else if (entry.getKey().equals("q5")) {
                    q5 = entry.getValue().toString();
                } else if (entry.getKey().equals("q6")) {
                    q6 = entry.getValue().toString();
                } else if (entry.getKey().equals("q7")) {
                    q7 = entry.getValue().toString();
                } else if (entry.getKey().equals("q8")) {
                    q8 = entry.getValue().toString();
                }
            }
        }
        boolean userExists = checkUserExist(properties, prolific);
        if(userExists){
            String userExistsError = produceUserExistsResponse();
            String logUserError = "User-prolific-id-already-exists-error " + getTimestamp() + "@" + "prolific-id " + prolific + "@" + " user-directory-create-result " + userExistsError;
            writeToUserLog(properties, prolific, logUserError);
            return userExistsError;
        }else{
            boolean success = createUserDataDirectories(properties, prolific);
            if(success){
                final ConsentSurvey ss = new ConsentSurvey(q1, q2, q3, q4, q5, q6, q7, q8, prolific, properties);
                String logConsent = "Consent-received " + getTimestamp() + "@" + "prolific-id " + prolific;
                writeToUserLog(properties, prolific, logConsent);
                String result = saveInformedConsent(properties, ss);
                String logConsentResult = "Consent-data-saved-to-database " + getTimestamp() + "@" + "prolific-id " + prolific + "@" + " db-access-result " + result;
                writeToUserLog(properties, prolific, logConsentResult);
                return result;
            }else{
                String logConsentDirectoryError = produceDirectoryErrorResponse();
                String logConsentError = "Consent-error-create-user-directory " + getTimestamp() + "@" + "prolific-id " + prolific + "@" + " user-directory-create-result " + logConsentDirectoryError;
                writeToUserLog(properties, prolific, logConsentError);
                return logConsentDirectoryError;
            }
        }
    }

    private boolean checkUserExist(Properties properties, String prolific){
        Driver driver = new Driver(properties);
        Connection connection = driver.getConnection();
        ParticipantRecord pr = new ParticipantRecord("", prolific ,properties); //when checkUserExist occurs there is no agent type assigned.
        String sql = pr.querySelectParticipantFromInformedConsent();
        String prolificUser = "";
        if(connection!=null){
            try {
                PreparedStatement select = connection.prepareStatement(sql);
                select.setString(1, prolific);
                connection.setAutoCommit(false);
                ResultSet resultSet = select.executeQuery();
                while(resultSet.next()){
                    prolificUser = resultSet.getString(1);
                }
                resultSet.close();
                select.close();
                connection.close();
                return prolificUser.equalsIgnoreCase(prolific);
            } catch (SQLException e) {
                EventLogger.LOGGER.log(Level.SEVERE, e.getSQLState()+ " "+ e.getMessage());
                return false;
            }
        }else{
            EventLogger.LOGGER.log(Level.SEVERE, "Creating connection to the database server failed");
            return false;
        }
    }

    private String saveInformedConsent(Properties properties, ConsentSurvey cs){
        Driver driver = new Driver(properties);
        Connection connection = driver.getConnection();
        String sql = cs.queryInsertIntoInformedConsent();
        if(connection!=null){
            try {
                PreparedStatement insert = connection.prepareStatement(sql);
                connection.setAutoCommit(false);

                insert.setString(1, cs.prolificId);
                insert.setString(2, cs.q1);
                insert.setString(3, cs.q2);
                insert.setString(4, cs.q3);
                insert.setString(5, cs.q4);
                insert.setString(6, cs.q5);
                insert.setString(7, cs.q6);
                insert.setString(8, cs.q7);
                insert.setString(9, cs.q8);

                insert.executeUpdate();
                connection.commit();
                insert.close();
                connection.close();
                ConsentResponse csr = new ConsentResponse(cs.prolificId, properties.getProperty("RESPONSE-CODE-SUCCESS"));
                Gson gsonResponse = new Gson();
                Type resultType = new TypeToken<ConsentResponse>() {}.getType();
                return gsonResponse.toJson(csr, resultType);
            } catch (SQLException e) {
                EventLogger.LOGGER.log(Level.SEVERE, e.getSQLState()+ " "+ e.getMessage());
                return produceSQLErrorResponse();
            }
        }else{
            EventLogger.LOGGER.log(Level.SEVERE, "Creating connection to the database server failed");
            return produceDBConErrorResponse();
        }
    }

    public String receiveDemographics(String param, Properties properties) {
        String q1 = "";
        String q2 = "";
        String q3 = "";
        String q4 = "";
        StringBuilder q5 = new StringBuilder();
        StringBuilder q6 = new StringBuilder();
        StringBuilder q7 = new StringBuilder();
        StringBuilder q8 = new StringBuilder();
        StringBuilder q9 = new StringBuilder();
        StringBuilder q10 = new StringBuilder();
        StringBuilder q11 = new StringBuilder();
        final Gson gson = new Gson();
        final JsonElement element = gson.fromJson(param, JsonElement.class);
        final JsonObject jsonObject = element.getAsJsonObject();
        final String prolificId = jsonObject.get("prolificid").getAsString();
        final JsonArray answers = jsonObject.get("answers").getAsJsonArray();
        for (int i = 0; i < answers.size(); i++) {
            final JsonObject object = answers.get(i).getAsJsonObject();
            final Set<Map.Entry<String, JsonElement>> entries = object.entrySet();
            for (Object o : entries) {
                final Map.Entry entry = (Map.Entry) o;
                if (entry.getKey().equals("q1")) {
                    q1 = entry.getValue().toString();
                } else if (entry.getKey().equals("q2")) {
                    q2 = entry.getValue().toString();
                } else if (entry.getKey().equals("q3")) {
                    q3 = entry.getValue().toString();
                } else if (entry.getKey().equals("q4")) {
                    q4 = entry.getValue().toString();
                } else if (entry.getKey().equals("q5")) {
                    q5.append(entry.getValue().toString());
                } else if (entry.getKey().equals("q6")) {
                    q6.append(entry.getValue().toString());
                } else if (entry.getKey().equals("q7")) {
                    q7.append(entry.getValue().toString());
                } else if (entry.getKey().equals("q8")) {
                    q8.append(entry.getValue().toString());
                } else if (entry.getKey().equals("q9")) {
                    q9.append(entry.getValue().toString());
                } else if (entry.getKey().equals("q10")) {
                    q10.append(entry.getValue().toString());
                } else if (entry.getKey().equals("q11")) {
                    q11.append(entry.getValue().toString());
                }
            }
        }
        final Demographics demos = new Demographics(q1, q2, q3, q4, q5.toString(), q6.toString(), q7.toString(), q8.toString(), q9.toString(), q10.toString(), q11.toString(), prolificId, properties);
        String result = saveDemographics(properties, demos);
        String logDemographics = "Demographic-questionnaire-responses-saved-to-database " + getTimestamp() + "@" + "prolific-id " + prolificId + "@" + " db-access-result " + result;
        writeToUserLog(properties, prolificId, logDemographics);
        return result;
    }

    private String saveDemographics(Properties properties, Demographics demos){
        Driver driver = new Driver(properties);
        Connection connection = driver.getConnection();
        String sql = demos.queryInsertIntoDemographics();
        if(connection!=null){
            try {
                PreparedStatement insert = connection.prepareStatement(sql);
                connection.setAutoCommit(false);

                insert.setString(1, demos.prolificId);
                insert.setString(2, demos.q1);
                insert.setString(3, demos.q2);
                insert.setString(4, demos.q3);
                insert.setString(5, demos.q4);
                insert.setString(6, demos.q5);
                insert.setString(7, demos.q6);
                insert.setString(8, demos.q7);
                insert.setString(9, demos.q8);
                insert.setString(10, demos.q9);
                insert.setString(11, demos.q10);
                insert.setString(12, demos.q11);

                insert.executeUpdate();
                connection.commit();
                insert.close();
                connection.close();
                DemographicsResponse dr = new DemographicsResponse(demos.prolificId, properties.getProperty("RESPONSE-CODE-SUCCESS"));
                Gson gsonResponse = new Gson();
                Type resultType = new TypeToken<DemographicsResponse>() {}.getType();
                return gsonResponse.toJson(dr, resultType);
            } catch (SQLException e) {
                EventLogger.LOGGER.log(Level.SEVERE, e.getSQLState()+ " "+ e.getMessage());
                return produceSQLErrorResponse();
            }
        }else{
            EventLogger.LOGGER.log(Level.SEVERE, "Creating connection to the database server failed");
            return produceDBConErrorResponse();
        }
    }

    private String saveEventLog(String param, Properties properties){
        final Gson gson = new Gson();
        final JsonElement element = gson.fromJson(param, JsonElement.class);
        final JsonObject jsonObject = element.getAsJsonObject();
        final String prolific = jsonObject.get("prolific").getAsString();
        final String task = jsonObject.get("task").getAsString();
        final JsonArray log = jsonObject.get("log").getAsJsonArray();

        StringBuilder text = new StringBuilder();
        Iterator<JsonElement> iteratorObj = log.iterator();
        while (iteratorObj.hasNext()) {
            text.append(iteratorObj.next()).append("\n");
        }

        writeUserFrontEndLog(properties, prolific, task, text.toString());
        FrontEndEventLogResponse fr = new FrontEndEventLogResponse(prolific, properties.getProperty("RESPONSE-CODE-SUCCESS"));
        Gson gsonResponse = new Gson();
        Type resultType = new TypeToken<FrontEndEventLogResponse>() {}.getType();
        return gsonResponse.toJson(fr, resultType);
    }

    private boolean createUserDataDirectories(final Properties prop, String prolific){
        String path = prop.getProperty("USERDATA");
        final String directoryName = path.concat(prolific);
        final String dirTime = path.concat(prolific+"/"+prop.getProperty("TASK-TIME"));
        final String dirSafe = path.concat(prolific+"/"+prop.getProperty("TASK-SAFETY"));
        final String dirTimeSafe = path.concat(prolific+"/"+prop.getProperty("TASK-TIMESAFETY"));

        final File parent = new File(directoryName);
        final File time = new File(dirTime);
        final File safety = new File(dirSafe);
        final File timeSafe = new File(dirTimeSafe);
        if (!parent.exists()) {
            boolean parentOk = parent.mkdir();
            new File(directoryName + prolific + ".log");
            if(parentOk){
               boolean timeOk = time.mkdir();
               if(timeOk){
                   boolean safeOk = safety.mkdir();
                   if(safeOk){
                       return timeSafe.mkdir();
                   }else{
                       return false; //safe dir failed
                   }
               }else {
                   return false;    //time dir failed
               }
            }else{
                return false;       //parent dir failed
            }
        }
        return false;
    }

    public String getTimestamp() {
        final Date date = new Date();
        final long time = date.getTime();
        final Timestamp ts = new Timestamp(time);
        return ts.toString();
    }

    private String produceSQLErrorResponse(){
        final ErrorResponse errorResponse = new ErrorResponse(Constants.ERR_SQL);
        final Gson gsonResponse = new Gson();
        final Type resultType = new TypeToken<ErrorResponse>() {}.getType();
        return gsonResponse.toJson(errorResponse, resultType);
    }

    private String produceDirectoryErrorResponse(){
        final ErrorResponse errorResponse = new ErrorResponse(Constants.ERR_DIRECTORY);
        final Gson gsonResponse = new Gson();
        final Type resultType = new TypeToken<ErrorResponse>() {}.getType();
        return gsonResponse.toJson(errorResponse, resultType);
    }

    private String produceUserExistsResponse(){
        final ErrorResponse errorResponse = new ErrorResponse(Constants.ERR_USER);
        final Gson gsonResponse = new Gson();
        final Type resultType = new TypeToken<ErrorResponse>() {}.getType();
        return gsonResponse.toJson(errorResponse, resultType);
    }

    private String produceDBConErrorResponse(){
        final ErrorResponse errorResponse = new ErrorResponse(Constants.ERR_DBCON);
        final Gson gsonResponse = new Gson();
        final Type resultType = new TypeToken<ErrorResponse>() {}.getType();
        return gsonResponse.toJson(errorResponse, resultType);
    }

    private void writeToUserLog(Properties properties, String prolific, String text){
        String root = properties.getProperty("USERDATA");
        String dir = root.concat(prolific+"/");
        try(FileWriter fw = new FileWriter(dir.concat(prolific.concat(".log")), true);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter out = new PrintWriter(bw) )
        {
            out.println(text);
        } catch (IOException e) {
            EventLogger.LOGGER.log(Level.SEVERE, "Writing to user's event log failed");
        }
    }

    private void writeUserFrontEndLog(Properties properties, String prolific, String task, String text){
        String root = properties.getProperty("USERDATA");
        String dir = root.concat(prolific+"/");
        String filename = prolific+"_"+task+".log";
        try(FileWriter fw = new FileWriter(dir.concat(filename), true);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter out = new PrintWriter(bw) )
        {
            out.println(text);
        } catch (IOException e) {
            EventLogger.LOGGER.log(Level.SEVERE, "Writing to user's front end event log failed");
        }
    }
}
