package planning;

import logger.EventLogger;

import java.io.*;
import java.util.ArrayList;
import java.util.Properties;
import java.util.logging.Level;

public class ENHSPPlanner {

    private final String domainFile;
    private final String problemFile;
    private final Properties properties;
    private final static String FILE_EXTENSION = ".enhsp";


    public ENHSPPlanner(final Properties prop, final String d, final String p) {
        this.domainFile = d;
        this.problemFile = p;
        this.properties = prop;
    }

    public String runENHSP() {
        String command = "java -jar "+ properties.get("ENHSP") + " -o " + domainFile + " -f " + problemFile + " -planner opt-hrmax"; //replace with opt-hmax or opt-hrmax
        //System.out.println(command);
        Process proc = null;
        final StringBuilder sb = new StringBuilder();

        try {
            proc = Runtime.getRuntime().exec(command);
            final BufferedReader reader = new BufferedReader(new InputStreamReader(proc.getInputStream()));
            String line = "";
            while ((line = reader.readLine()) != null) {
                sb.append(line + "\n");
            }
            proc.waitFor();
        } catch (IOException | InterruptedException e) {
            EventLogger.LOGGER.log(Level.SEVERE, properties.get("ERROR-CODE-PLANNER").toString());
        }finally {
            proc.destroy();
        }
        return sb.toString();
    }

    public void writeConsoleOutputToFile(final String outfile, final String text) {
        PrintWriter writer = null;
        try {
            writer = new PrintWriter(outfile, "UTF-8");
            writer.write(text);
            writer.println();
        } catch (final FileNotFoundException | UnsupportedEncodingException e) {
            EventLogger.LOGGER.log(Level.SEVERE, e.getMessage());
        } finally {
            writer.close();
        }
    }

    public ENHSPPlan readSolutionFile(String solutionpath, String filename) {
        FileReader fileReader;
        ArrayList<String> lines = new ArrayList<>();
        int metricValue = 0;
        boolean actionsBegin = false;
        try {
            fileReader = new FileReader(solutionpath+filename); //path + problem file name
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            String outstr = "";
            while ((outstr = bufferedReader.readLine()) != null) {
                if(outstr.contains("Problem Solved")){
                    actionsBegin = true;
                }
                if(actionsBegin){
                    if(outstr.contains("drive")){ //collect actions
                        lines.add(outstr.substring(outstr.indexOf("(")+1,outstr.indexOf(")")).toUpperCase());
                    }
                }
                if(outstr.contains("Metric (Search)") && actionsBegin){ //collect the plan cost
                    actionsBegin = false;
                    metricValue = (int)Double.parseDouble(outstr.substring(outstr.indexOf(":")+1));
                }
            }
            bufferedReader.close();
            fileReader.close();
        } catch (IOException e) {
            EventLogger.LOGGER.log(Level.SEVERE, properties.getProperty("ERROR-CODE-SOLUTIONFILES"));
        }
        ENHSPPlan plan = new ENHSPPlan(metricValue);
        plan.setActions(lines);
        return plan;
    }

    //run planner, get output. This will generate one optimal plan
    public ENHSPPlan getENHSPPlan(String planoutpath, String problemfilename) {
        String planReturned = runENHSP();
        writeConsoleOutputToFile(planoutpath + problemfilename + FILE_EXTENSION, planReturned);
        if (planReturned.contains("Problem Solved")) {
            ENHSPPlan plan = readSolutionFile(planoutpath, problemfilename + FILE_EXTENSION);
            return plan;
        } else { //error occurred while invoking planner. or no solution found
            EventLogger.LOGGER.log(Level.SEVERE, properties.get("ERROR-CODE-PLANNER").toString());
            return null;
        }
    }

}
