package planning;

public class LPGTDPlan extends Plan{

    private int cost;

    public LPGTDPlan(int cost) {
        this.cost = cost;
    }

    public int getPlanCost() {
        return cost;
    }

}
