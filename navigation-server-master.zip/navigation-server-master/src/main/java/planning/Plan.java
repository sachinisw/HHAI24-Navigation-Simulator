package planning;

import java.util.ArrayList;
import java.util.Arrays;

public abstract class Plan {
    private ArrayList<String> actions;

    public Plan() {
        this.actions = new ArrayList<>();
    }

    public ArrayList<String> getActions() {
        return this.actions;
    }

    public void setActions(final ArrayList<String> actions) {
        this.actions = actions;
    }

    public String toString() {
        return Arrays.toString(this.getActions().toArray());
    }

    public abstract int getPlanCost();
}