package planning;

import logger.EventLogger;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;
import java.util.logging.Level;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RLPlanner {
    private final Properties properties;
    private HashMap<String, ArrayList<RLState>> qValues;
    private ArrayList<Integer> costs;
    private ArrayList<Integer> blocks;

    public RLPlanner(final Properties prop) {
        this.properties = prop;
        this.qValues = new HashMap<>();
        this.costs = new ArrayList<>();
        this.blocks = new ArrayList<>();
    }

    public void runRLPlanner(String objective, String init, String milestones, String costmap) {
        String command;
        //call the reinforcement learning agent  -o -n -q -i 90 -ms 73 -cm 1 1 1 3 3 3 3 1 1 1 1 1 1 3 1 3 3 1 1 1 1 1 1 3 1 3 3 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 3 3 1 3 1 1 1 1 1 3 3 3 3 3 1 1 3 3 3 1 1 1 1 1 1 1 3 3 3 1 1 1 1 1 1 1 3 3 3 3 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1
        //if obj = true is safety agent / if obj = false, time agent
        if(objective.equalsIgnoreCase("SAFETY")){
            command = properties.get("RL").toString() + " -o -n -q" + " -i "+ init + " -ms "+ milestones + " -cm "+ costmap;
        }else{
            command = properties.get("RL").toString() + " -n -q" + " -i "+ init + " -ms "+ milestones + " -cm "+ costmap;
        }
        System.out.println(command);
        Pattern extractQValues = Pattern.compile("[0-9]{1,2}\\s\\{('\\b(?:up|down|left|right)\\b':\\s\\-*\\d*\\.*\\d*\\,*\\s*)+\\}"); //q-value line
        Pattern extractKey = Pattern.compile("[0-9]{1,2}\\s");
        Pattern extractValue = Pattern.compile("\\s\\{('\\b(?:up|down|left|right)\\b':\\s\\-*\\d*\\.*\\d*\\,*\\s*)+\\}");
        Pattern extractDirection = Pattern.compile("'\\b(?:up|down|left|right)\\b':\\s\\-*\\d*\\.*\\d*");
        Pattern extractCost = Pattern.compile("[0-9]+");
        try {
            Process proc = Runtime.getRuntime().exec(command);
            final BufferedReader reader = new BufferedReader(new InputStreamReader(proc.getInputStream()));
            String line, key = "", val = "";
            while ((line = reader.readLine()) != null) {
                Matcher m = extractQValues.matcher(line);
                if(m.find()){ //extract lines of the q-values map.
                    String mapLine = m.group();
                    Matcher n = extractKey.matcher(mapLine);
                    Matcher o = extractValue.matcher(mapLine);
                    if(n.find()){
                        key = n.group();
                    }
                    if(o.find()){
                        val = o.group();
                    }
                    ArrayList<RLState> values = new ArrayList<>();
                    Matcher p = extractDirection.matcher(val);
                    while(p.find()){
                        String x = p.group();
                        String xParts [] = x.split(":");
                        RLState s = new RLState(xParts[0].trim(), xParts[1].trim());
                        values.add(s);
                    }
                    qValues.put(key.trim(), values);
                }

                if(line.startsWith("Total cost:")){
                    Matcher c = extractCost.matcher(line);
                    if(c.find()){
                        String cost = c.group();
                        costs.add(Integer.parseInt(cost));
                    }
                }

                if(line.startsWith("Total length:")){
                    Matcher c = extractCost.matcher(line);
                    if(c.find()){
                        String b = c.group();
                        blocks.add(Integer.parseInt(b));
                    }
                }
            }
            proc.waitFor();
        } catch (final IOException | InterruptedException e) {
            EventLogger.LOGGER.log(Level.SEVERE, properties.get("ERROR-CODE-PLANNER").toString());
        }
        //DEBUG PRINT
        Iterator itr = qValues.keySet().iterator();
        while(itr.hasNext()){
            String key = (String) itr.next();
            System.out.println(key + " --> " +qValues.get(key));
        }

    }

    public String getBestActionInState(String state){
        ArrayList<RLState> directions = qValues.get(state);
        Random rand = new Random();
        String bestDirection = directions.get(rand.nextInt(directions.size())).direction; //initialize to random value.
        double bestProbability = Double.MIN_VALUE;

        for (RLState s: directions){
            if(Double.parseDouble(s.probability)>bestProbability){
                bestDirection = s.direction;
                bestProbability = Double.parseDouble(s.probability);
            }
        }
        return bestDirection;
    }

    //run planner, read output
    public RLPolicy getRLPolicy(String objective, String init, String milestone, String costs) {
        //break the trip into segments and repeat calls for each segment. home->milestone[0], milestone[1]->milestone[2] etc.
        runRLPlanner(objective, init, milestone, costs);
        RLPolicy policy = null;
        if (qValues.size()==100) { //all good.
            policy = new RLPolicy(0, init, milestone );
            for (String key : qValues.keySet()) {
                String action = getBestActionInState(key);
                policy.addToMap(key, action);
            }
        } else { //error occurred while invoking planner
            EventLogger.LOGGER.log(Level.SEVERE, properties.get("ERROR-CODE-PLANNER").toString() );
        }
        return policy;
    }

}
