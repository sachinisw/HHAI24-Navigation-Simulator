package planning;

import logger.EventLogger;
import server.Grid;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.logging.Level;

public class PDDLGenerator {
    ArrayList<java.lang.String> components;
    Grid domain;
    String problemFile;

    public PDDLGenerator(Grid d, String out){
        components = new ArrayList<>();
        domain = d;
        problemFile = out;
    }

    public void generateStartingSafetyCostDomainPDDL(){
        components.add("(define (domain navigation-variable-cost-classical)");
        components.add("(:requirements :strips :typing :action-costs)");
        components.add("(:types position)");

        StringBuilder objects = new StringBuilder();
        objects.append("(:constants");
        for(int i=0; i<domain.columns*domain.rows; i++){ //add the cells as constants
            objects.append(" " + "L").append(i);
        }
        objects.append(" - position)");
        components.add(objects.toString());
        components.add("(:predicates \n (at ?p - position) \n (accessible ?p1 ?p2 - position) \n (visited ?p - position) \n )");
        components.add("(:functions \n (total-cost) \n )");

        ArrayList<String> connections = connect(null);
        for (String s:connections) {
            String[] parts = s.substring(s.indexOf("(")+1, s.indexOf(")")).split(" ");
            String from = parts[1];
            String to = parts[2];
            String actionHeader = "(:action drive_" + from + "_" + to + "\n";
            String pre = ":precondition (and (at " + from + ") " + s + ") \n";
            String eff = ":effect (and (not (at "+ from + ")) (at " + to + ") (visited " + to + ") (increase (total-cost) " + domain.safetyCosts.getSafeties()[Integer.parseInt(to.substring(1))] +"))\n";
            String actionEnd = ")\n";
            components.add(actionHeader + pre + eff + actionEnd);
        }
        components.add(")"); //add end of domain file
    }

    public void generateIntermediateSafetyCostDomainPDDL(int [] blocked){
        components.add("(define (domain navigation-variable-cost-classical)");
        components.add("(:requirements :strips :typing :action-costs)");
        components.add("(:types position)");

        StringBuilder objects = new StringBuilder();
        objects.append("(:constants");
        for(int i=0; i<domain.columns*domain.rows; i++){ //add the cells as constants
            if(!arrayContains(blocked,i)) {
                objects.append(" " + "L").append(i);
            }
        }
        objects.append(" - position)\n");
        components.add(objects.toString());
        components.add("(:predicates \n (at ?p - position) \n (accessible ?p1 ?p2 - position) \n (visited ?p - position) \n )");
        components.add("(:functions \n (total-cost) \n )");

        ArrayList<String> connections = connect(null);
        for (String s:connections) {
            String[] parts = s.substring(s.indexOf("(")+1, s.indexOf(")")).split(" ");
            String from = parts[1];
            String to = parts[2];
            if(!arrayContains(blocked, Integer.parseInt(to.substring(1)))) {
                String actionHeader = "(:action drive_" + from + "_" + to + "\n";
                String pre = ":precondition (and (at " + from + ") " + s + ") \n";
                String eff = ":effect (and (not (at " + from + ")) (at " + to + ") (visited " + to + ") (increase (total-cost) " + domain.safetyCosts.getSafeties()[Integer.parseInt(to.substring(1))] +"))\n";
                String actionEnd = ")\n";
                components.add(actionHeader + pre + eff + actionEnd);
            }
        }
        components.add(")"); //add end of domain file
    }

    public void generateStartingSafetyCostProblemPDDL(){
        components.add("(define (problem assistant)");
        components.add("(:domain navigation-variable-cost-classical)");

        StringBuilder init = new StringBuilder("(:init \n");

        ArrayList<String> connections = connect(null); //add the connected positions
        for (String connection : connections) {
            init.append(connection).append("\n");
        }

        init.append("(at L").append(domain.home).append(")\n"); //add start position
        init.append("(visited L").append(domain.home).append(")\n"); //add home as visited
        init.append("(total-cost 0)"); //metric initialization
        init.append("\n)");

        components.add(init.toString());
        components.add("(:goal (and (at L" + domain.hospital + ") (visited L" + domain.grocery + ") (visited L" + domain.construction + ") (visited L" + domain.school + ") ))");
        components.add("(:metric minimize (total-cost))"); // add optimization criteria
        components.add("\n)");

    }

    public void generateIntermediateSafetyCostProblemPDDL(int [] blocked, int at, int choice, int[] visited){
        String visited_hospital = "", visited_grocery = "", visited_construction = "", visited_school = "";
        components.add("(define (problem assistant)");
        components.add("(:domain navigation-variable-cost-classical)");

        StringBuilder init = new StringBuilder("(:init \n");

        ArrayList<String> connections = connect(blocked); //define init - connected positions. disconnect from blocked
        for (String connection : connections) {
            init.append(connection).append("\n");
        }
        //no need to append visited[] to init. (not visited ?loc) predicate is not checked in preconditions. neg. preconditions not allowed.
        //instead, remove visited[] from goal statement
        String toVisit = refineVisitedInGoal(visited, domain.grocery, domain.school, domain.construction);

        ArrayList<String> times = applySafetyCosts(blocked); //add the safety costs of connections. dont apply cost of the blocked cell. it's removed from the objects
        for(String t: times){
            init.append(t).append("\n");
        }
        init.append("(at L").append(choice).append(")\n"); //blob's starting position = choice. generate new plan starting from user choice
        init.append("(total-cost 0)"); //metric initialization
        init.append("\n)");

        components.add(init.toString());
        components.add("(:goal (and (at L" + domain.hospital + ")" + toVisit +"))");  //goal = all unvisited landmarks + destination
        components.add("(:metric minimize (total-cost))"); // add optimization criteria
        components.add("\n)");

    }


    public void generateStartingTimeDurativeProblemPDDL(){
        components.add("(define (problem assistant)");
        components.add("(:domain navigation-time-durative)");

        StringBuilder objects = new StringBuilder("(:objects \n");
        StringBuilder init = new StringBuilder("(:init \n");

        for(int i=0; i<domain.columns*domain.rows; i++){ //add the cells as objects
            objects.append(" " + "L").append(i);
        }
        objects.append(" - position)");

        ArrayList<String> connections = connect(null); //add the connected positions
        for (String connection : connections) {
            init.append(connection).append("\n");
        }

        ArrayList<String> times = applyTimeCosts(null); //add the time costs of connections
        for(String t: times){
            init.append(t).append("\n");
        }

        init.append("(at L").append(domain.home).append(")\n"); //add start position
        init.append("(visited L").append(domain.home).append(")\n"); //add home as visited
        init.append("\n)");

        components.add(objects.toString());
        components.add(init.toString());
        components.add("(:goal (and (at L" + domain.hospital + ") (visited L" + domain.grocery + ") (visited L" + domain.construction + ") (visited L" + domain.school + ") ))");
        components.add("\n)");
    }

    public void generateStartingTimeNumericProblemPDDL(){
        components.add("(define (problem assistant)");
        components.add("(:domain navigation-time-numeric)");

        StringBuilder objects = new StringBuilder("(:objects \n");
        StringBuilder init = new StringBuilder("(:init \n");

        for(int i=0; i<domain.columns*domain.rows; i++){ //add the cells as objects
            objects.append(" " + "L").append(i);
        }
        objects.append(" - position)");

        ArrayList<String> connections = connect(null); //add the connected positions
        for (String connection : connections) {
            init.append(connection).append("\n");
        }

        ArrayList<String> times = applyTimeCosts(null); //add the time costs of connections
        for(String t: times){
            init.append(t).append("\n");
        }

        init.append("(at L").append(domain.home).append(")\n"); //add start position
        init.append("(visited L").append(domain.home).append(")\n"); //add home as visited
        init.append("(= (travel-time) 0)"); //add metric initialization
        init.append("\n)");

        components.add(objects.toString());
        components.add(init.toString());
        components.add("(:goal (and (at L" + domain.hospital + ") (visited L" + domain.grocery + ") (visited L" + domain.construction + ") (visited L" + domain.school + ") ))");
        components.add("(:metric minimize (travel-time))"); // add optimization criteria
        components.add("\n)");
    }

    public void generateStartingSafetyDurativeProblemPDDL(){
        components.add("(define (problem assistant)");
        components.add("(:domain navigation-safety-durative)");

        StringBuilder objects = new StringBuilder("(:objects \n");
        StringBuilder init = new StringBuilder("(:init \n");

        for(int i=0; i<domain.columns*domain.rows; i++){ //add the cells as objects
            objects.append(" " + "L").append(i);
        }
        objects.append(" - position)");

        ArrayList<String> connections = connect(null); //add the connected positions
        for (String connection : connections) {
            init.append(connection).append("\n");
        }

        ArrayList<String> safety = applySafetyCosts(null); //add the safety costs of connections
        for(String t: safety){
            init.append(t).append("\n");
        }

        init.append("(at L").append(domain.home).append(")\n"); //add start position
        init.append("(visited L").append(domain.home).append(")\n"); //add home as visited
        init.append("\n)");

        components.add(objects.toString());
        components.add(init.toString());
        components.add("(:goal (and (at L" + domain.hospital + ") (visited L" + domain.grocery + ") (visited L" + domain.construction + ") (visited L" + domain.school + ") ))");
        components.add("\n)");
    }

    public void generateStartingSafetyNumericProblemPDDL(){
        components.add("(define (problem assistant)");
        components.add("(:domain navigation-safety-numeric)");

        StringBuilder objects = new StringBuilder("(:objects \n");
        StringBuilder init = new StringBuilder("(:init \n");

        for(int i=0; i<domain.columns*domain.rows; i++){ //add the cells as objects
            objects.append(" " + "L").append(i);
        }
        objects.append(" - position)");

        ArrayList<String> connections = connect(null); //add the connected positions
        for (String connection : connections) {
            init.append(connection).append("\n");
        }

        ArrayList<String> safety = applySafetyCosts(null); //add the safety costs of connections
        for(String t: safety){
            init.append(t).append("\n");
        }

        init.append("(at L").append(domain.home).append(")\n"); //add start position
        init.append("(visited L").append(domain.home).append(")\n"); //add home as visited
        init.append("(= (travel-safety-cost) 0)"); //add metric initialization
        init.append("\n)");

        components.add(objects.toString());
        components.add(init.toString());
        components.add("(:goal (and (at L" + domain.hospital + ") (visited L" + domain.grocery + ") (visited L" + domain.construction + ") (visited L" + domain.school + ") ))");
        components.add("(:metric minimize (travel-safety-cost))"); // add optimization criteria
        components.add("\n)");
    }

    public void generateStartingTimeSafetyProblemDurativePDDL(){
        components.add("(define (problem assistant)");
        components.add("(:domain navigation-timesafety-durative)");

        StringBuilder objects = new StringBuilder("(:objects \n");
        StringBuilder init = new StringBuilder("(:init \n");

        for(int i=0; i<domain.columns*domain.rows; i++){ //add the cells as objects
            objects.append(" " + "L").append(i);
        }
        objects.append(" - position)");

        ArrayList<String> connections = connect(null); //add the connected positions
        for (String connection : connections) {
            init.append(connection).append("\n");
        }

        ArrayList<String> times = applyTimeCosts(null); //add the time costs of connections
        for(String t: times){
            init.append(t).append("\n");
        }

        ArrayList<String> safety = applySafetyCosts(null); //add the safety costs of connections
        for(String t: safety){
            init.append(t).append("\n");
        }

        init.append("(at L").append(domain.home).append(")\n"); //add start position
        init.append("(visited L").append(domain.home).append(")\n"); //add home as visited
        init.append("\n)");

        components.add(objects.toString());
        components.add(init.toString());
        components.add("(:goal (and (at L" + domain.hospital + ") (visited L" + domain.grocery + ") (visited L" + domain.construction + ") (visited L" + domain.school + ") ))");
        components.add("\n)");
    }

    public void generateStartingTimeSafetyProblemNumericPDDL(){
        components.add("(define (problem assistant)");
        components.add("(:domain navigation-timesafe-numeric)");

        StringBuilder objects = new StringBuilder("(:objects \n");
        StringBuilder init = new StringBuilder("(:init \n");

        for(int i=0; i<domain.columns*domain.rows; i++){ //add the cells as objects
            objects.append(" " + "L").append(i);
        }
        objects.append(" - position)");

        ArrayList<String> connections = connect(null); //add the connected positions
        for (String connection : connections) {
            init.append(connection).append("\n");
        }

        ArrayList<String> times = applyTimeCosts(null); //add the time costs of connections
        for(String t: times){
            init.append(t).append("\n");
        }

        ArrayList<String> safety = applySafetyCosts(null); //add the safety costs of connections
        for(String t: safety){
            init.append(t).append("\n");
        }

        init.append("(at L").append(domain.home).append(")\n"); //add start position
        init.append("(visited L").append(domain.home).append(")\n"); //add home as visited
        init.append("(= (travel-safety-cost) 0)"); //add metric initialization
        init.append("(= (travel-time) 0)"); //add metric initialization
        init.append("\n)");

        components.add(objects.toString());
        components.add(init.toString());
        components.add("(:goal (and (at L" + domain.hospital + ") (visited L" + domain.grocery + ") (visited L" + domain.construction + ") (visited L" + domain.school + ") ))");
        components.add("(:metric minimize (+(travel-safety-cost)(travel-time)))"); // add optimization criteria
        components.add("\n)");
    }

    public void generateIntermediateTimeProblemNumericPDDL(int [] blocked, int at, int choice, int[] visited){
        String visited_hospital = "", visited_grocery = "", visited_construction = "", visited_school = "";
        components.add("(define (problem assistant)");
        components.add("(:domain navigation-time-numeric)");

        StringBuilder objects = new StringBuilder("(:objects \n");
        StringBuilder init = new StringBuilder("(:init \n");

        for(int i=0; i<domain.columns*domain.rows; i++){ //define objects without the blocked cell
            if(!arrayContains(blocked,i)) {
                objects.append(" " + "L").append(i);
            }
        }
        objects.append(" - position)");

        ArrayList<String> connections = connect(blocked); //define init - connected positions. disconnect from blocked
        for (String connection : connections) {
            init.append(connection).append("\n");
        }
        //no need to append visited[] to init. (not visited ?loc) predicate is not checked in preconditions. neg. preconditions not allowed.
        //instead, remove visited[] from goal statement
        String toVisit = refineVisitedInGoal(visited, domain.grocery, domain.school, domain.construction);

        ArrayList<String> times = applyTimeCosts(blocked); //add the time costs of connections. dont apply cost of the blocked cell. it's removed from the objects
        for(String t: times){
            init.append(t).append("\n");
        }
        init.append("(at L").append(choice).append(")\n"); //blob's starting position = choice. generate new plan starting from user choice
        init.append("(= (travel-time) 0)"); //add metric initialization
        init.append("\n)");

        components.add(objects.toString());
        components.add(init.toString());

        components.add("(:goal (and (at L" + domain.hospital + ")" + toVisit + "))");  //goal = all unvisited landmarks + destination
        components.add("(:metric minimize (travel-time))"); // add optimization criteria
        components.add("\n)");
    }

    public void generateIntermediateSafetyProblemNumericPDDL(int [] blocked, int at, int choice, int[] visited){
        String visited_hospital = "", visited_grocery = "", visited_construction = "", visited_school = "";
        components.add("(define (problem assistant)");
        components.add("(:domain navigation-safety-numeric)");

        StringBuilder objects = new StringBuilder("(:objects \n");
        StringBuilder init = new StringBuilder("(:init \n");

        for(int i=0; i<domain.columns*domain.rows; i++){ //define objects without the blocked cell
            if(!arrayContains(blocked,i)) {
                objects.append(" " + "L").append(i);
            }
        }
        objects.append(" - position)");

        ArrayList<String> connections = connect(blocked); //define init - connected positions. disconnect from blocked
        for (String connection : connections) {
            init.append(connection).append("\n");
        }
        //no need to append visited[] to init. (not visited ?loc) predicate is not checked in preconditions. neg. preconditions not allowed.
        //instead, remove visited[] from goal statement
        String toVisit = refineVisitedInGoal(visited, domain.grocery, domain.school, domain.construction);

        ArrayList<String> times = applySafetyCosts(blocked); //add the safety costs of connections. dont apply cost of the blocked cell. it's removed from the objects
        for(String t: times){
            init.append(t).append("\n");
        }
        init.append("(at L").append(choice).append(")\n"); //blob's starting position = choice. generate new plan starting from user choice
        init.append("(= (travel-safety-cost) 0)"); //add metric initialization
        init.append("\n)");

        components.add(objects.toString());
        components.add(init.toString());

        components.add("(:goal (and (at L" + domain.hospital + ")" + toVisit +"))");  //goal = all unvisited landmarks + destination
        components.add("(:metric minimize (travel-safety-cost))"); // add optimization criteria
        components.add("\n)");
    }

    public void generateIntermediateTimeSafetyProblemNumericPDDL(int [] blocked, int at, int choice, int[] visited){
        String visited_hospital = "", visited_grocery = "", visited_construction = "", visited_school = "";
        components.add("(define (problem assistant)");
        components.add("(:domain navigation-timesafe-numeric)");

        StringBuilder objects = new StringBuilder("(:objects \n");
        StringBuilder init = new StringBuilder("(:init \n");

        for(int i=0; i<domain.columns*domain.rows; i++){ //define objects without the blocked cell
            if(!arrayContains(blocked,i)) {
                objects.append(" " + "L").append(i);
            }
        }
        objects.append(" - position)");

        ArrayList<String> connections = connect(blocked); //define init - connected positions. disconnect from blocked
        for (String connection : connections) {
            init.append(connection).append("\n");
        }
        //no need to append visited[] to init. (not visited ?loc) predicate is not checked in preconditions. neg. preconditions not allowed.
        //instead, remove visited[] from goal statement
        String toVisit = refineVisitedInGoal(visited, domain.grocery, domain.school, domain.construction);

        ArrayList<String> times = applyTimeCosts(blocked); //add the time costs of connections. dont apply cost of the blocked cell. it's removed from the objects
        for(String t: times){
            init.append(t).append("\n");
        }
        ArrayList<String> safety = applySafetyCosts(blocked); //add the safety costs of connections
        for(String t: safety){
            init.append(t).append("\n");
        }

        init.append("(at L").append(choice).append(")\n"); //blob's starting position = choice. generate new plan starting from user choice
        init.append("(= (travel-safety-cost) 0)").append("\n"); //add metric initialization
        init.append("(= (travel-time) 0)"); //add metric initialization
        init.append("\n)");

        components.add(objects.toString());
        components.add(init.toString());

        components.add("(:goal (and (at L" + domain.hospital + ") " + toVisit +"))");  //goal = all unvisited landmarks + destination
        components.add("(:metric minimize (+(travel-safety-cost)(travel-time)))"); // add optimization criteria
        components.add("\n)");
    }

    public void generateStartingUnitCostPDDL(){
        components.add("(define (problem assistant)");
        components.add("(:domain navigation-unitcost-classical)");

        StringBuilder objects = new StringBuilder("(:objects \n");
        StringBuilder init = new StringBuilder("(:init \n");

        for(int i=0; i<domain.columns*domain.rows; i++){ //add the cells as objects
            objects.append(" " + "L").append(i);
        }
        objects.append(" - position)");

        ArrayList<String> connections = connect(null); //add the connected positions
        for (String connection : connections) {
            init.append(connection).append("\n");
        }

        init.append("(at L").append(domain.home).append(")\n"); //add start position
        init.append("(visited L").append(domain.home).append(")\n"); //add home as visited
        init.append("\n)");

        components.add(objects.toString());
        components.add(init.toString());
        components.add("(:goal (and (at L" + domain.hospital + ") (visited L" + domain.grocery + ") (visited L" + domain.construction + ") (visited L" + domain.school + ") ))");
        components.add("\n)");
    }

    public void generateIntermediateUnitCostPDDL(int [] blocked, int at, int choice, int[] visited){
        String visited_hospital = "", visited_grocery = "", visited_construction = "", visited_school = "";
        components.add("(define (problem assistant)");
        components.add("(:domain navigation-unitcost-classical)");

        StringBuilder objects = new StringBuilder("(:objects \n");
        StringBuilder init = new StringBuilder("(:init \n");

        for(int i=0; i<domain.columns*domain.rows; i++){ //define objects without the blocked cell
            if(!arrayContains(blocked,i)) {
                objects.append(" " + "L").append(i);
            }
        }
        objects.append(" - position)");

        ArrayList<String> connections = connect(blocked); //define init - connected positions. disconnect from blocked
        for (String connection : connections) {
            init.append(connection).append("\n");
        }
        //no need to append visited[] to init. (not visited ?loc) predicate is not checked in preconditions. neg. preconditions not allowed.
        //instead, remove visited[] from goal statement
        String toVisit = refineVisitedInGoal(visited, domain.grocery, domain.school, domain.construction);

        init.append("(at L").append(choice).append(")\n"); //blob's starting position = choice. generate new plan starting from user choice
        init.append("\n)");

        components.add(objects.toString());
        components.add(init.toString());

        components.add("(:goal (and (at L" + domain.hospital + ")" + toVisit +"))");  //goal = all unvisited landmarks + destination
        components.add("\n)");
    }

    public String refineVisitedInGoal(int [] visited, int grocery, int school, int construction){
        String toVisit = "";
        boolean foundGrocery = false, foundSchool = false, foundConstruction = false;
        for(int i=0; i<visited.length; i++){
            if(visited[i] == grocery){
                foundGrocery = true;
                break;
            }
        }
        for(int i=0; i<visited.length; i++){
            if(visited[i] == school){
                foundSchool = true;
                break;
            }
        }
        for(int i=0; i<visited.length; i++){
            if(visited[i] == construction){
                foundConstruction = true;
                break;
            }
        }

        if(!foundGrocery){
            toVisit += "(visited L" + grocery + ")";
        }
        if(!foundSchool){
            toVisit += "(visited L" + school + ")";
        }
        if(!foundConstruction){
            toVisit += "(visited L" + construction + ")";
        }
        return toVisit;
    }

    public void writeProblemToFile() {
        try {
            PrintWriter writer = new PrintWriter(problemFile);
            for(String component: components){
                writer.println(component);
            }
            writer.close();
        } catch (FileNotFoundException e) {
            EventLogger.LOGGER.log(Level.SEVERE, "PDDL problem writing failed:"+problemFile);
        }
    }

    public void writeDomainToFile() {
        try {
            PrintWriter writer = new PrintWriter(problemFile);
            for(String component: components){
                writer.println(component);
            }
            writer.close();
        } catch (FileNotFoundException e) {
            EventLogger.LOGGER.log(Level.SEVERE, "PDDL domain writing failed:"+problemFile);
        }
    }

    public ArrayList<String> applyTimeCosts(int [] blocked){
        ArrayList <String> costsConnections = new ArrayList<String>();
        for(int i=0; i<domain.rows; i++){
            for(int j=0; j<domain.columns; j++){
                int from = j+i*domain.columns;
                if(!arrayContains(blocked, from)) {
                    if (j - 1 >= 0){  //left
                        int to = (i * domain.columns + (j - 1));
                        if(!arrayContains(blocked, to)) {
                            costsConnections.add("(= (time-required " + "L" + from + " L" + to + ") " + domain.timeCosts.getTimes()[to] + ")");
                        }
                    }
                    if (j + 1 < domain.columns){  //right
                        int to = (i * domain.columns + (j + 1));
                        if(!arrayContains(blocked, to)) {
                            costsConnections.add("(= (time-required " + "L" + from + " L" + to + ") " + domain.timeCosts.getTimes()[to] + ")");
                        }
                    }
                    if (i - 1 >= 0){ //up
                        int to = (((i - 1) * domain.columns) + j);
                        if(!arrayContains(blocked, to)) {
                            costsConnections.add("(= (time-required " + "L" + from + " L" + to + ") " + domain.timeCosts.getTimes()[to] + ")");
                        }
                    }
                    if (i + 1 < domain.rows){ //down
                        int to = (((i + 1) * domain.columns) + j);
                        if(!arrayContains(blocked, to)) {
                            costsConnections.add("(= (time-required " + "L" + from + " L" + to + ") " + domain.timeCosts.getTimes()[to] + ")");
                        }
                    }
                }
            }
        }
        return costsConnections;
    }

    public ArrayList<String> applySafetyCosts(int [] blocked){
        ArrayList <String> costsConnections = new ArrayList<String>();
        for(int i=0; i<domain.rows; i++){
            for(int j=0; j<domain.columns; j++){
                int from = j+i*domain.columns;
                if(!arrayContains(blocked, from)) {
                    if (j - 1 >= 0){  //left
                        int to = (i * domain.columns + (j - 1));
                        if(!arrayContains(blocked, to)) {
                            costsConnections.add("(= (safety-cost " + "L" + from + " L" + to + ") " + domain.safetyCosts.getSafeties()[to] + ")");
                        }
                    }
                    if (j + 1 < domain.columns){  //right
                        int to = (i * domain.columns + (j + 1));
                        if(!arrayContains(blocked, to)) {
                            costsConnections.add("(= (safety-cost " + "L" + from + " L" + to + ") " + domain.safetyCosts.getSafeties()[to] + ")");
                        }
                    }
                    if (i - 1 >= 0){ //up
                        int to = (((i - 1) * domain.columns) + j);
                        if(!arrayContains(blocked, to)) {
                            costsConnections.add("(= (safety-cost " + "L" + from + " L" + to + ") " + domain.safetyCosts.getSafeties()[to] + ")");
                        }
                    }
                    if (i + 1 < domain.rows){ //down
                        int to = (((i + 1) * domain.columns) + j);
                        if(!arrayContains(blocked, to)) {
                            costsConnections.add("(= (safety-cost " + "L" + from + " L" + to + ") " + domain.safetyCosts.getSafeties()[to] + ")");
                        }
                    }
                }
            }
        }
        return costsConnections;
    }

    public ArrayList<String> connect(int[] blocked){
        ArrayList<String> connections = new ArrayList<>();
        for(int i=0; i<domain.rows; i++){
            for(int j=0; j<domain.columns; j++){
                int from = j+i*domain.columns;
                if(!arrayContains(blocked, from)) {
                    if (j - 1 >= 0){  //left
                        int to = (i * domain.columns + (j - 1));
                        if(!arrayContains(blocked, to)) {
                            connections.add("(accessible " + "L" + from + " L" + to + ")");
                        }
                    }
                    if (j + 1 < domain.columns){  //right
                        int to = (i * domain.columns + (j + 1));
                        if(!arrayContains(blocked, to)) {
                            connections.add("(accessible " + "L" + from + " L" + to + ")");
                        }
                    }
                    if (i - 1 >= 0){ //up
                        int to = (((i - 1) * domain.columns) + j);
                        if(!arrayContains(blocked, to)) {
                            connections.add("(accessible " + "L" + from + " L" + to + ")");
                        }
                    }
                    if (i + 1 < domain.rows){ //down
                        int to = (((i + 1) * domain.columns) + j);
                        if(!arrayContains(blocked, to)) {
                            connections.add("(accessible " + "L" + from + " L" + to + ")");
                        }
                    }
                }
            }
        }
       return connections;
    }

    private boolean arrayContains(int[] arr, int val){
        if(arr==null){
            return false;
        }
        for(int i: arr){
            if(i==val){
                return  true;
            }
        }
        return false;
    }

}
