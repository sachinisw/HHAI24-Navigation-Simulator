package planning;

import logger.EventLogger;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.filefilter.TrueFileFilter;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.logging.Level;

//Generates a plan using the POPF planner
public class LPGTDPlanner {

    private final String domainFile;
    private final String problemFile;
    private final Properties properties;
    private static final int solutionCount = 3; //find 3 solutions until the planner is terminated. may not be the optimal
    private static final int cpuTime = 60; //forces the planner to terminate after 60s.


    public LPGTDPlanner(final Properties prop, final String d, final String p) {
        this.domainFile = d;
        this.problemFile = p;
        this.properties = prop;
    }

    public int runLPGTD(String outpath) {
        String command = properties.get("LPGTD") + " -o " + domainFile + " -f " + problemFile + " -v off " + " -n " + solutionCount + " -cputime " + cpuTime +" -out " + outpath;
        Process proc = null;
        try {
            proc = Runtime.getRuntime().exec(command);
            return proc.waitFor();
        } catch (IOException | InterruptedException e) {
            EventLogger.LOGGER.log(Level.SEVERE, properties.get("ERROR-CODE-PLANNER").toString());
        }finally {
            proc.destroy();
        }
        return 0;
    }

    public LPGTDPlan readSolutionFile(String solutionpath, String filename) {
        FileReader fileReader;
        ArrayList<String> lines = new ArrayList<>();
        String metricValue = "";
        try {
            fileReader = new FileReader(solutionpath+filename); //path + problem file name
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            String outstr;
            while ((outstr = bufferedReader.readLine()) != null) {
                if (!outstr.startsWith(";") && !outstr.isEmpty()) { //collect actions in the plan
                    lines.add(outstr.substring(outstr.indexOf("(")+1, outstr.indexOf(")")).toUpperCase());
                }
                if(outstr.contains("MetricValue")){ //collect the plan cost
                    metricValue = outstr.split(" ")[2];
                }
            }
            bufferedReader.close();
            fileReader.close();
        } catch (IOException e) {
            EventLogger.LOGGER.log(Level.SEVERE, properties.getProperty("ERROR-CODE-SOLUTIONFILES"));
        }
        LPGTDPlan plan = new LPGTDPlan((int) Double.parseDouble(metricValue));
        plan.setActions(lines);
        return plan;
    }

    public ArrayList<String> getSolutionFiles(String path, String problemfilename) {
        ArrayList<String> solFiles = new ArrayList<>();
        try {
            File dir = new File(path);
            List<File> files = (List<File>) FileUtils.listFiles(dir, TrueFileFilter.INSTANCE, TrueFileFilter.INSTANCE);
            for (File fileItem : files) {
                String name = fileItem.getName();
                if(name.contains(problemfilename) && name.contains(".SOL"))  {
                    solFiles.add(fileItem.getCanonicalPath());
                }
            }
        }
        catch (IOException e) {
            EventLogger.LOGGER.log(Level.SEVERE, "ERROR LPG-TD getSolutionFiles():: " + e.getMessage());
        }
        return solFiles;
    }

    //run planner, get output
    public LPGTDPlan getLPGTDPlan(String planoutpath, String problemfilename) {
        ArrayList<LPGTDPlan> plans = new ArrayList<>();
        int returnOk = runLPGTD(planoutpath+problemfilename);
        if(returnOk==0){
            ArrayList<String> paths = getSolutionFiles(planoutpath, problemfilename);
            for(String p : paths){
                LPGTDPlan plan = readSolutionFile(planoutpath, problemfilename);
                plans.add(plan);
            }
        }
        if (!plans.isEmpty()) { //all good. solution found. return the plan with the best metric value from the found 3
            LPGTDPlan best = plans.get(0);
            int cost = plans.get(0).getPlanCost();
            for(int i=1; i<plans.size(); i++){
                LPGTDPlan solution = plans.get(i);
                if(solution.getPlanCost() < cost){
                    cost = solution.getPlanCost();
                    best = solution;
                }
            }
            return best;
        } else { //error occurred while invoking planner. or no solution found
            EventLogger.LOGGER.log(Level.SEVERE, properties.get("ERROR-CODE-PLANNER").toString() );
            return null;
        }
    }
}