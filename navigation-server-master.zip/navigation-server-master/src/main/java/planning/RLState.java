package planning;

public class RLState {
    String direction;
    String probability;

    public RLState(String d, String p){
        this.direction = d;
        this.probability = p;
    }

    public String toString(){
        return direction+":"+probability;
    }
}
