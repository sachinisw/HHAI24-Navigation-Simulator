package planning;

public class POPFPlan extends Plan{

    private int cost;

    public POPFPlan(int cost) {
        this.cost = cost;
    }

    public int getPlanCost() {

        return cost;
    }

}
