package planning;


public class FDPlan extends Plan {
    private static final int UNIT_COST = 1;

    public FDPlan() {
    }

    public int getPlanCost() {
        return this.getActions().size() * FDPlan.UNIT_COST; //assumes unit cost
    }

}