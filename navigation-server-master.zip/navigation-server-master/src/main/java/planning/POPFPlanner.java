package planning;

import logger.EventLogger;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Properties;
import java.util.logging.Level;

//Generates a plan using the POPF planner
public class POPFPlanner {

    private static final String optimize = " -n "; //pop-f configuration to optimize the cost by finding many solutions.
    private final String domainFile;
    private final String problemFile;
    private final Properties properties;

    public POPFPlanner(final Properties prop, final String d, final String p) {
        this.domainFile = d;
        this.problemFile = p;
        this.properties = prop;
    }

    public ArrayList<String> runPOPF() {
        String command = properties.get("POPF") + optimize + domainFile + " " + problemFile;
        ArrayList<String> lines = new ArrayList<>();
        String line;
        boolean start = false;
        try {
            Process proc = Runtime.getRuntime().exec(command);
            proc.waitFor();
            BufferedReader input = new BufferedReader(new InputStreamReader(proc.getInputStream()));
            while((line=input.readLine()) != null){
                if(line.startsWith(";;;; Solution Found")) {
                    start = true;
                }
                if(start && !line.startsWith(";")) { //plan steps
                    lines.add(line.substring(line.indexOf("("))); //POPF plan step >> 0.000: (drive l4 l8)  [1.000]
                }
            }
            input.close();
        } catch (IOException | InterruptedException e) {
            EventLogger.LOGGER.log(Level.SEVERE, properties.get("ERROR-CODE-PLANNER").toString());
        }
        return lines;
    }

    //run planner, get output
    public POPFPlan getPOPFPlan() {
        ArrayList<String> lines = runPOPF();
        if (!lines.isEmpty()) { //all good. solution found
            ArrayList<String> cleaned = new ArrayList<>();
            int cost = 0;
            for (String s : lines) {
                cleaned.add(s.substring(s.indexOf("(")+1, s.indexOf(")")).toUpperCase()); //lose the paranthesis around actions
                cost += (int) Double.parseDouble(s.substring(s.indexOf("[")+1, s.indexOf("]")));
            }
            POPFPlan popf = new POPFPlan(cost);
            popf.setActions(cleaned);
            return popf;
        } else { //error occurred while invoking planner. or no solution found
            EventLogger.LOGGER.log(Level.SEVERE, properties.get("ERROR-CODE-PLANNER").toString() );
            return null;
        }
    }
}