package planning;

import logger.EventLogger;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Properties;
import java.util.logging.Level;

//Generates **one** plan from Fast Downward using astar with lmcut() heuristic given problem and domain.
//admissible heuristics like lmcut() produce optimal plans
public class FDPlanner {

    private static final String fdConfigAStar = "--search astar(lmcut())";
    private final String domainFile;
    private final String problemFile;
    private final Properties properties;

    public FDPlanner(final Properties prop, final String d, final String p) {
        this.domainFile = d;
        this.problemFile = p;
        this.properties = prop;
    }

    public int runFDPlanner(String path, String filename) {
        String command = properties.get("FD") + " --sas-file " + path + filename + "_output.sas" + " --plan-file " + path + filename +"_sas_plan" + " " + domainFile + " " + problemFile + " " + fdConfigAStar;
        //System.out.println(command);
        int exitCode = -1;
        try {
            Process proc = Runtime.getRuntime().exec(command);
            exitCode = proc.waitFor();
            //printPlannerStdout(proc); //enable for debug
        } catch (final IOException | InterruptedException e) {
            EventLogger.LOGGER.log(Level.SEVERE, properties.get("ERROR-CODE-PLANNER").toString());
        }
        return exitCode;
    }

    private void printPlannerStdout(Process proc){ //DEBUG METHOD
        BufferedReader reader = new BufferedReader(new InputStreamReader(proc.getInputStream(), StandardCharsets.UTF_8));
        String line;
        try{
            while((line = reader.readLine()) != null){
                System.out.println("stdout: "+ line);
            }
        }catch(IOException e){
            System.err.println("Exception in reading output"+ e.toString());
        }
    }

    public ArrayList<String> readFile(String path) {
        FileReader fileReader;
        ArrayList<String> lines = new ArrayList<>();
        try {
            fileReader = new FileReader(path + "sas_plan");
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            String outstr = "";
            while ((outstr = bufferedReader.readLine()) != null) {
                if (!outstr.contains(";") && outstr.contains("drive")) { //collect actions
                    lines.add(outstr.substring(1, outstr.indexOf(")")).trim().toUpperCase());
                }
            }
            bufferedReader.close();
        } catch (IOException e) {
            EventLogger.LOGGER.log(Level.SEVERE, properties.getProperty("ERROR-CODE-SAS"));
        }
        return lines;
    }

    //run planner, read output
    public FDPlan getFDPlan(String outputpath, String filename) {
        int ret = runFDPlanner(outputpath, filename);
        if (ret == 0) { //all good.
            ArrayList<String> lines = readFile(outputpath+filename+"_");
            FDPlan fp = new FDPlan();
            fp.setActions(lines);
            return fp;
        } else { //error occurred while invoking planner
            EventLogger.LOGGER.log(Level.SEVERE, properties.get("ERROR-CODE-PLANNER").toString() );
            return null;
        }
    }

}