package planning;

public class ENHSPPlan  extends Plan{
    private int cost;

    public ENHSPPlan(int cost) {
        this.cost = cost;
    }

    public int getPlanCost() {
        return cost;
    }


}
