package planning;

import java.util.HashMap;
import java.util.Map;

public class RLPolicy extends Plan {

    private int cost;
    public HashMap<String, String> SxA;
    public String initialState;
    public String goalState;

    public RLPolicy(int c, String init, String goal){
        this.cost = c;
        initialState = init;
        goalState = goal;
        SxA = new HashMap<>();
    }

    public void addToMap(String key, String value){
        SxA.put(key,value);
    }

    public String[] getPolicyAsArray(){
        String [] elements = new String[SxA.size()];
        for (Map.Entry<String, String> entry : SxA.entrySet()) {
            String value = entry.getValue();
            String key = entry.getKey();
            if(!value.isEmpty()){
                elements[Integer.parseInt(key)] = value.substring(1, value.length() - 1);
            }
        }
        return elements;
    }

    @Override
    public int getPlanCost() {
        return cost;
    }
}
