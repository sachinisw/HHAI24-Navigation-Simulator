const initServer = require('./server.js')
const httpport = (process.env.PORT || 9090) //this is the http port for Express backend server for the react front end
const httpsport = (process.env.PORT || 9080) //https port
const app = initServer()

app[1].listen(httpport)
console.log(`Listening at http://localhost:${httpport}`)
//app[0].listen(httpsport)
//console.log(`Listening at https://localhost:${httpsport}`)
