import React, { useState } from 'react'
import Container from 'react-bootstrap/Container'
import Button from 'react-bootstrap/Button'
import Modal from 'react-bootstrap/Modal'

class TaskEndNotification extends React.Component{
	constructor(props) {
		super(props);
	}

	render() {
    let title = "", body = ""

		if (this.props.currentTask==="TIME"){
    	title = "You have completed the task with the assistant Dede"
			if(this.props.nextTask==="SAFETY"){
				body = "Next, complete the task with the assistant Cece. Cece proposes directions to avoid red zones and minimize the travel time."
			}else if(this.props.nextTask==="END"){
				body = "Click Continue complete the demographic survey and to finish the study."
			}

    }else if (this.props.currentTask==="SAFETY"){
			title = "You have completed the task with the assistant Cece"
			if(this.props.nextTask==="TIME"){
				body = "Next, complete the task with the assistant Dede. Dede will propose directions to minimize the distance travelled."
			}else if(this.props.nextTask==="END"){
				body = "Click Continue complete the demographic survey and to finish the study."
			}
		}

		 return (

			 <Modal show={this.props.show} backdrop="static" keyboard={false} size="lg" aria-labelledby="contained-modal-title-vcenter" centered>
					<Modal.Header>
             <Modal.Title>{title}</Modal.Title>
           </Modal.Header>

          <Modal.Body>
            <h5>{body}</h5>
          </Modal.Body>

          <Modal.Footer>
              <Button onClick={this.props.getNextTask}>Continue</Button>
          </Modal.Footer>
      </Modal>

		);
	 }
}export default TaskEndNotification;
