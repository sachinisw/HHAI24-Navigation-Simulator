import React from 'react'
import Container from 'react-bootstrap/Container'
import Card from 'react-bootstrap/Card'
import Row from 'react-bootstrap/Row'
import Col from 'react-bootstrap/Col'
import Button from 'react-bootstrap/Button'
import Spinner from 'react-bootstrap/Spinner'
import {getDirection} from './Functions'

class InterruptRecovery extends React.Component{

  constructor(props) {
		super(props);
    this.state={
      waiting: null,
      delay_text: "",
    }
    this.handleClick = this.handleClick.bind(this);
  }

  handleClick(event){
    let delay = <Spinner animation="border" role="status" size="sm"> <span className="visually-hidden"></span>  </Spinner>
    let text = "Searching for a new route. Please wait"
    this.props.handleDirectionChoice(event.target.id)
    this.setState({
        waiting:delay,
        delay_text:text
    });
  }

  render() {
    let up_btn = null, down_btn = null, left_btn = null, right_btn = null

    for(let i=0; i<this.props.keys.length; i++){
      let direction = getDirection(this.props.at, this.props.keys[i]).split(" ")[1]
      if(direction==="UP"){
        up_btn = <Button variant="outline-primary" id={this.props.keys[i]} onClick={this.handleClick} className="directionChoices">{direction}</Button>
      }
      if(direction==="LEFT"){
        left_btn = <Button variant="outline-primary" id={this.props.keys[i]} onClick={this.handleClick} className="directionChoices">{direction}</Button>
      }
      if(direction==="RIGHT"){
        right_btn = <Button variant="outline-primary" id={this.props.keys[i]} onClick={this.handleClick} className="directionChoices">{direction}</Button>
      }
      if(direction==="DOWN"){
        down_btn = <Button variant="outline-primary" id={this.props.keys[i]} onClick={this.handleClick} className="directionChoices">{direction}</Button>
      }
    }

     return (

       <Row>
  			<Col sm className="instructions">

         <Card>
           <Card.Header><img className="panel-icon-img" src="../images/announcement.svg"/><b>Notifications</b></Card.Header>

   			  <Card.Body>
   				<Card.Text>
            Select a direction <br />
            <div class="recoveryButtons">
              <div class="up">{up_btn}</div>
              <div class="left">{left_btn}</div>
              <div class="right">{right_btn}</div>
              <div class="down">{down_btn}</div>
            </div>
            <hr/>
            <br /> {this.state.waiting} {this.state.delay_text}


   				</Card.Text>
   			  </Card.Body>
   			</Card>

        </Col>
  		 </Row>



    );
  }

}export default InterruptRecovery;
