import React, { useState } from 'react'
import Form from 'react-bootstrap/Form'
import FormGroup from 'react-bootstrap/FormGroup'
import Container from 'react-bootstrap/Container'
import Card from 'react-bootstrap/Card'
import Row from 'react-bootstrap/Row'
import Col from 'react-bootstrap/Col'
import Button from 'react-bootstrap/Button'
import Alert from 'react-bootstrap/Alert'
import {demoFormCompleteSingleResponse} from './FormValidator'


class Demographics extends React.Component{
	constructor(props) {
		super(props);
		this.handleFormSubmit = this.handleFormSubmit.bind(this);
		this.collectData = this.collectData.bind(this);
		this.setErrorValues = this.setErrorValues.bind(this);
		this.validateandSubmit = this.validateandSubmit.bind(this);
		this.fetch = this.fetch.bind(this);
		this.state = {
			q1:"",
			q2:"",
			q3:"",
			q4:"",
			q5:"",
			q6:"",
			q7:"",
			q8:"",
			q9:"",
			q10:"",
			q11:"",
			eq1:false,	//empty
			eq2:false,
			eq3:false,
			eq4:false,
			eq5:false,
			eq6:false,
			eq7:false,
			eq8:false,
			eq9:false,
			eq10:false,
			eq11:false,
			quiz:this.props.uid,
			alertmsg1:"",
			displayAlert:null,
			validated:false,
			connectionError:null
		};
	  }

	  handleFormSubmit(event) { //In our handler for the submit event, we need to stop the event from bubbling up and trying to submit the form to another page which causes a refresh and then posts all of our data appended to the web address. The line of code that does this is event.preventDefault()
			event.preventDefault();
			let valuearr = [{q1:this.state.q1},{q2:this.state.q2},{q3:this.state.q3},{q4:this.state.q4},
							{q5:this.state.q5},{q6:this.state.q6},{q7:this.state.q7},{q8:this.state.q8},
							{q9:this.state.q9},{q10:this.state.q10},{q11:this.state.q11}]
			let errComplete = demoFormCompleteSingleResponse(valuearr)
			this.setErrorValues(errComplete)
	  }

	validateandSubmit(){
		let al=null
		if(this.state.eq1 || this.state.eq2 ||this.state.eq3 ||this.state.eq4 ||this.state.eq5
		|| this.state.eq6 || this.state.eq7 || this.state.eq8 || this.state.eq9 || this.state.eq10 || this.state.eq11){
			al = <Alert variant="danger"> <Alert.Heading> Errors in Survey! </Alert.Heading> <hr />
				<div className="mb-0">{this.state.alertmsg1}</div>
			</Alert>
		}else{
			let valuearr = [{q1:this.state.q1},{q2:this.state.q2},{q3:this.state.q3},{q4:this.state.q4},
						{q5:this.state.q5},{q6:this.state.q6},{q7:this.state.q7},{q8:this.state.q8},
						{q9:this.state.q9},{q10:this.state.q10},{q11:this.state.q11}]
			let obj = { prolificid:this.props.uid, answers: valuearr};
			this.fetch("DEMOGRAPHY#"+JSON.stringify(obj))
		}
		this.setState({
			displayAlert:al
		});
	}

	setErrorValues(errEmpty){
		//set empty field error
		let msg='- Question(s):'
		let e1=false,e2=false,e3=false,e4=false,e5=false,e6=false,e7=false,e8=false,e9=false,e10=false,e11=false
		for(let i=0; i<errEmpty.length; i++){
			let ob=errEmpty[i]
			if(Object.keys(ob)[0]==="q1"){
				e1=true
				msg+=" 1,"
			}else if(Object.keys(ob)[0]==="q2") {
				e2=true
				msg+=" 2,"
			}else if(Object.keys(ob)[0]==="q3") {
				e3=true
				msg+=" 3,"
			}else if(Object.keys(ob)[0]==="q4") {
				e4=true
				msg+=" 4,"
			}else if(Object.keys(ob)[0]==="q5") {
				e5=true
				msg+=" 5,"
			}else if(Object.keys(ob)[0]==="q6") {
				e6=true
				msg+=" 6,"
			}else if(Object.keys(ob)[0]==="q7") {
				e7=true
				msg+=" 7,"
			}else if(Object.keys(ob)[0]==="q8") {
				e8=true
				msg+=" 8,"
			}else if(Object.keys(ob)[0]==="q9") {
				e9=true
				msg+=" 9,"
			}else if(Object.keys(ob)[0]==="q10") {
				e10=true
				msg+=" 10,"
			}else if(Object.keys(ob)[0]==="q11") {
				e11=true
				msg+=" 11"
			}
		}
		if (errEmpty.length>0) {
			msg+=" can not be blank."
		}else{
			msg=""
		}

		this.setState({
			eq1:e1,	//empty
			eq2:e2,
			eq3:e3,
			eq4:e4,
			eq5:e5,
			eq6:e6,
			eq7:e7,
			eq8:e8,
			eq9:e9,
			eq10:e10,
			eq11:e11,
			alertmsg1:msg
		},
		function ()
		{
			this.validateandSubmit();
		});
	}

	collectData(event){
		if(event.target.name==="q1"){
			this.setState({
			 q1:event.target.value
			 });
		}else if(event.target.name==="q2"){
			this.setState({
			 q2:event.target.value
			 });
		}else if(event.target.name==="q3"){
			this.setState({
			 q3:event.target.value
			 });
		}else if(event.target.name==="q4"){
			this.setState({
			 q4:event.target.value
			 });
		}else if(event.target.name==="q5"){
			this.setState({
			 q5:event.target.value
			 });
		}else if(event.target.name==="q6"){
			this.setState({
			 q6:event.target.value
			 });
		}else if(event.target.name==="q7"){
			this.setState({
			 q7:event.target.value
			 });
		}else if(event.target.name==="q8"){
			this.setState({
			 q8:event.target.value
			 });
		}else if(event.target.name==="q9"){
			this.setState({
			 q9:event.target.value
			 });
		}else if(event.target.name==="q10"){
			this.setState({
			 q10:event.target.value
			 });
		}else if(event.target.name==="q11"){
			this.setState({
			 q11:event.target.value
			 });
		}
	}

	async fetch(input) {
        let id = input.split("#")[0]; //conveys type of request. give consent
        let data = input.split("#")[1]; //gives the parameters needed for the server to produce an output for the request
        let clientRequest = {   // Create client->server request message. IMPORTANT: This object must match the structure of whatever object the server is reading into
            parameters: data,
            type: id
        };
        try {
            // Attempt to send `clientRequest` via a POST request to java backend running on port 9999// Notice how the end of the url below matches what the server is listening on
            let serverUrl = window.location.href.substring(0, window.location.href.length - 6) + ":9999/api";
            let jsonReturned = await fetch(serverUrl,
                {
                    method: "POST",
                    body: JSON.stringify(clientRequest)
                });
            let ret = await jsonReturned.json();// Wait for server to return and convert it to json.
            let retJSON = JSON.parse(ret); //parse ret to JSON object. check retJSON.type and apply correct behavior
            if(retJSON.type==="DEMOGRAPHICS-RESPONSE" && retJSON.message==="SUCCESS"){
							this.props.unmount(true)
						}
         } catch (e) {
           let err =
						<Alert color="danger">
							<h4 className="alert-heading">Error</h4>
							There was an error connecting to the remote server. <p>Contact administrator: sachini.weerawardhana@kcl.ac.uk </p>
						</Alert>
						 this.setState({
								connectionError: err
						});
        }
    }

	render() {
		 return (

			 <Card>
			  <Card.Header><b>Survey on Experience in Using Driving Assistant Technologies</b></Card.Header>
				 <Form onSubmit={this.handleFormSubmit} noValidate>
				  <Form.Group>
					<Form.Text>Dear Participant,<br />
					Thank you for contributing to our study. Please answer all the questions as accurately as possible.<br />
					</Form.Text>
				  </Form.Group>
				  <Form.Group>{this.state.displayAlert}</Form.Group>
					<Form.Group>
					  <Form.Label className={this.state.eq1?'form-label-error':''}>
						<b>Q1:</b> State your age in years.
					  </Form.Label>
					 <Form.Group as={Col}>
						<Form.Group as={Col}> <Form.Check inline="true"  type="radio" label="less than 20" name="q1" value="less than 20" onChange={this.collectData} required /> </Form.Group>
						<Form.Group as={Col}> <Form.Check inline="true" type="radio" label="20 – 25" name="q1" value="20 – 25" onChange={this.collectData} required /> </Form.Group>
						<Form.Group as={Col}> <Form.Check inline="true" type="radio" label="26 – 30" name="q1" value="26 – 30" onChange={this.collectData} required /> </Form.Group>
						<Form.Group as={Col}> <Form.Check inline="true" type="radio" label="31 – 35" name="q1" value="31 – 35" onChange={this.collectData} required /> </Form.Group>
						<Form.Group as={Col}> <Form.Check inline="true" type="radio" label="36 – 40" name="q1" value="36 – 40" onChange={this.collectData} required /> </Form.Group>
						<Form.Group as={Col}> <Form.Check inline="true" type="radio" label="41 and above" name="q1" value="41+" onChange={this.collectData} required	/> </Form.Group>
						<Form.Group as={Col}> <Form.Check inline="true" type="radio" label="I do not want to give that information"  name="q1" value="refused" onChange={this.collectData} required /> </Form.Group>
					 </Form.Group>
					</Form.Group>
					<br/>
					<Form.Group>
					  <Form.Label className={this.state.eq2?'form-label-error':''}>
						<b>Q2:</b> State your gender.
					  </Form.Label>
						<Form.Group as={Col}>
						<Form.Group as={Col}> <Form.Check inline="true" type="radio"  label="Male" name="q2" value="Male"  onChange={this.collectData} required /> </Form.Group>
						<Form.Group as={Col}> <Form.Check inline="true" type="radio" label="Female" name="q2" value="Female" onChange={this.collectData} required /> </Form.Group>
						<Form.Group as={Col}> <Form.Check inline="true" type="radio" label="Other" name="q2" value="Other" onChange={this.collectData} required /> </Form.Group>
						<Form.Group as={Col}> <Form.Check inline="true" type="radio" label="I do not want to give that information" name="q2"  value="undisclosed"  onChange={this.collectData}  required /> </Form.Group>
						</Form.Group>
					</Form.Group>
					<br/>
					<Form.Group>
					  <Form.Label className={this.state.eq3?'form-label-error':''}>
						<b>Q3:</b> What is the highest level of school you have completed or the highest degree you have received?
					  </Form.Label>
					  <Form.Group as={Col}>
						<Form.Group as={Col}> <Form.Check inline="true" type="radio" label="No formal schooling" name="q3" value="no school" onChange={this.collectData} required /> </Form.Group>
						<Form.Group as={Col}> <Form.Check inline="true" type="radio" label="Some grade school" name="q3" value="grade school" onChange={this.collectData} required /> </Form.Group>
						<Form.Group as={Col}> <Form.Check inline="true" type="radio" label="High school graduate" name="q3" value="high school" onChange={this.collectData} required /> </Form.Group>
						<Form.Group as={Col}> <Form.Check inline="true" type="radio" label="Some college, no degree" name="q3" value="some college" onChange={this.collectData} required /> </Form.Group>
						<Form.Group as={Col}> <Form.Check inline="true" type="radio" label="Bachelor's degree" name="q3" value="bachelor's" onChange={this.collectData} required /> </Form.Group>
						<Form.Group as={Col}> <Form.Check inline="true" type="radio" label="Master's degree" name="q3" value="master's" onChange={this.collectData} required /> </Form.Group>
						<Form.Group as={Col}> <Form.Check inline="true" type="radio" label="Professional school degree (law, medicine, etc.)" name="q3" value="professional school" onChange={this.collectData} required /> </Form.Group>
						<Form.Group as={Col}> <Form.Check inline="true"	type="radio" label="Academic doctorate degree" name="q3" value="phd" onChange={this.collectData} required /> </Form.Group>
						<Form.Group as={Col}> <Form.Check inline="true"	type="radio" label="I do not want to give that information" name="q3"  value="refused"  onChange={this.collectData}  required /> </Form.Group>
						</Form.Group>
					</Form.Group>
					<br/>
					<Form.Group>
					  <Form.Label className={this.state.eq4?'form-label-error':''}>
						<b>Q4:</b> Do you have a valid driving license?
					  </Form.Label>
					  <Form.Group as={Col}>
						<Form.Group as={Col}> <Form.Check inline="true" type="radio" label="Yes" name="q4" value="Yes" onChange={this.collectData} required /> </Form.Group>
						<Form.Group as={Col}> <Form.Check inline="true" type="radio" label="No" name="q4" value="No" onChange={this.collectData} required /> </Form.Group>
						</Form.Group>
					</Form.Group>
					<br/>
					<Form.Group>
					  <Form.Label className={(this.state.eq5)?'form-label-error':''}>
						<b>Q5:</b> For how many years have you been a driver?
					  </Form.Label>
					 <Form.Group as={Col}>
						<Form.Group as={Col}> <Form.Check inline="true" type="radio" label="Less than 1 year" name="q5" value="<1" onChange={this.collectData} required  /> </Form.Group>
						<Form.Group as={Col}> <Form.Check inline="true" type="radio" label="1-3 years" name="q5" value="1-3" onChange={this.collectData} required  /> </Form.Group>
						<Form.Group as={Col}> <Form.Check inline="true" type="radio" label="3-5 years" name="q5" value="3-5" onChange={this.collectData} required  /> </Form.Group>
						<Form.Group as={Col}> <Form.Check inline="true" type="radio" label="More than 5 years" name="q5" value="5<" onChange={this.collectData} required /> </Form.Group>
						</Form.Group>
					</Form.Group>
					<br/>
					<Form.Group>
					  <Form.Label className={(this.state.eq6)?'form-label-error':''}>
						<b>Q6:</b> On average, how many days a week do you drive?
					  </Form.Label>
					  <Form.Group as={Col}>
							<Form.Group as={Col}> <Form.Check inline="true" type="radio" label="One day a week"  name="q6" value="one day" onChange={this.collectData}   required /> </Form.Group>
							<Form.Group as={Col}> <Form.Check inline="true" type="radio" label="Two days a week" name="q6" value="two days" onChange={this.collectData} required /> </Form.Group>
							<Form.Group as={Col}> <Form.Check inline="true" type="radio" label="Three days a week" name="q6" value="three days" onChange={this.collectData} required /> </Form.Group>
							<Form.Group as={Col}> <Form.Check inline="true" type="radio" label="Four days a week" name="q6" value="four days" onChange={this.collectData} required /> </Form.Group>
							<Form.Group as={Col}> <Form.Check inline="true" type="radio" label="Five or more days a week" name="q6" value="5 or more days" onChange={this.collectData} required /> </Form.Group>
						</Form.Group>
					</Form.Group>
					<br/>
					<Form.Group>
					  <Form.Label className={(this.state.eq7)?'form-label-error':''}>
						<b>Q7:</b> What is your eagerness level to adopt new technologies?
					  </Form.Label>
					  <Form.Group as={Col}>
							<Form.Check inline="true" type="radio" label="1 (Extremely low eagerness)" name="q7" value="1" onChange={this.collectData} required />
							<Form.Check inline="true" type="radio" label="2" name="q7" value="2" onChange={this.collectData}  required />
							<Form.Check inline="true" type="radio" label="3" name="q7" value="3" onChange={this.collectData} required />
							<Form.Check inline="true" type="radio" label="4" name="q7" value="4" onChange={this.collectData} required />
							<Form.Check inline="true" type="radio" label="5" name="q7" value="5" onChange={this.collectData} required />
							<Form.Check inline="true" type="radio" label="6" name="q7" value="6" onChange={this.collectData} required />
							<Form.Check inline="true" type="radio" label="7 (Extremely high eagerness)" name="q7" value="7" onChange={this.collectData} required />
						</Form.Group>
					</Form.Group>
					<br/>
					<Form.Group>
					  <Form.Label className={(this.state.eq8)?'form-label-error':''}>
						<b>Q8:</b> What is your knowledge level in regard to autonomous vehicles?
					  </Form.Label>
					  <Form.Group as={Col}>
							<Form.Check inline="true" type="radio"  label="1 (Extremely low knowledge)"  name="q8"  value="1"onChange={this.collectData} required />
							<Form.Check inline="true" type="radio" label="2" name="q8" value="2" onChange={this.collectData} required />
							<Form.Check inline="true" type="radio" label="3"  name="q8" value="3" onChange={this.collectData} required	/>
							<Form.Check inline="true" type="radio" label="4" name="q8" value="4" onChange={this.collectData} required />
							<Form.Check inline="true" type="radio" label="5" name="q8" value="5" onChange={this.collectData} required />
							<Form.Check inline="true" type="radio" label="6" name="q8" value="6" onChange={this.collectData} required />
							<Form.Check inline="true" type="radio" label="7 (Extremely high knowledge)" name="q8" value="7" onChange={this.collectData} required />
						</Form.Group>
					</Form.Group>
					<br/>
					<Form.Group>
					 <Form.Label className={(this.state.eq9)? 'form-label-error':''}>
					 <b>Q9:</b> Have you heard any stories about autonomous vehicles being involved in accidents?
					 </Form.Label>
					 <Form.Group as={Col}>
						 <Form.Group as={Col}> <Form.Check inline="true" type="radio" label="Yes" name="q9" value="Yes" onChange={this.collectData} required /> </Form.Group>
						 <Form.Group as={Col}> <Form.Check inline="true" type="radio" label="No" name="q9" value="No" onChange={this.collectData} required /> </Form.Group>
					 </Form.Group>
				 </Form.Group>
				 <br/>
				 <Form.Group>
					 <Form.Label className={(this.state.eq10)?'form-label-error':''}>
					 <b>Q10:</b> Indicate how much experience you have with vehicle driving assistance technology
						 (examples: cruise control, adaptive cruise control, parking assist, lane keeping assist, blind spot detection, or others).
					 </Form.Label>
					 <Form.Group as={Col}>
						 <Form.Check inline="true" type="radio"  label="1 (Extremely low experience)" name="q10" value="1" onChange={this.collectData} required />
						 <Form.Check inline="true" type="radio" label="2" name="q10" value="2" onChange={this.collectData} required />
						 <Form.Check inline="true" type="radio" label="3"  name="q10"   value="3" onChange={this.collectData} required	/>
						 <Form.Check inline="true" type="radio" label="4" name="q10" value="4" onChange={this.collectData} required />
						 <Form.Check inline="true" type="radio" label="5" name="q10" value="5" onChange={this.collectData} required />
						 <Form.Check inline="true" type="radio" label="6" name="q10" value="6" onChange={this.collectData} required />
						 <Form.Check inline="true" type="radio" label="7 (Extremely high experience)" name="q10" value="7" onChange={this.collectData} required />
					 </Form.Group>
				 </Form.Group>
				 <br/>
					<Form.Group>
					 <Form.Label className={(this.state.eq11)? 'form-label-error':''}>
					 <b>Q11:</b> Have you ever been in a self-driving car?
					 </Form.Label>
					 <Form.Group as={Col}>
						 <Form.Group as={Col}> <Form.Check inline="true" type="radio" label="Yes" name="q11" value="Yes" onChange={this.collectData} required /> </Form.Group>
						 <Form.Group as={Col}> <Form.Check inline="true" type="radio" label="No" name="q11" value="No" onChange={this.collectData} required /> </Form.Group>
					 </Form.Group>
				 </Form.Group>

				  <Form.Group as={Row}>
					<Col sm={{ span: 10, offset: 2 }}>
						<br/>
					  <Button type="submit" >Submit and Finish</Button>
					  {this.state.connectionError}
					</Col>
				  </Form.Group>
			</Form>
			</Card>

		);
	 }
}export default Demographics;
