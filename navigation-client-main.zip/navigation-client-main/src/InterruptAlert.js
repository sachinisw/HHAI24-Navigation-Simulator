import React from 'react'
import Modal from 'react-bootstrap/Modal'
import Container from 'react-bootstrap/Container'
import Row from 'react-bootstrap/Row'
import Col from 'react-bootstrap/Col'
import Button from 'react-bootstrap/Button'

class InterruptAlert extends React.Component{

  constructor(props) {
		super(props);
	  }


    render() {
       return (

         <Modal show={this.props.show} backdrop="static">
          <Modal.Header>
            <Modal.Title>INTERRUPTION!</Modal.Title>
          </Modal.Header>
          <Modal.Body>

              <Row>
              <Col xs={6} md={3}>
                <img width="60px" class="img-responsive" src="../images/interruption.png"/>
              </Col>

                <Col xs={12} md={9}>
                  <p>You are now taking control of the navigation.</p>
                  <p>Click OK to read the messages from the assistant.</p>
                </Col>
              </Row>

          </Modal.Body>
          <Modal.Footer>
            <Button variant="primary" onClick={this.props.onInterruptOK}>OK</Button>
          </Modal.Footer>
        </Modal>


      );
    }

  }export default InterruptAlert;
