import React from 'react'
import Modal from 'react-bootstrap/Modal'
import Container from 'react-bootstrap/Container'
import Row from 'react-bootstrap/Row'
import Col from 'react-bootstrap/Col'
import Button from 'react-bootstrap/Button'

class IncidentAlert extends React.Component{

  constructor(props) {
		super(props);
	  }


    render() {
       return (

         <Modal show={this.props.show} backdrop="static">
          <Modal.Header>
            <Modal.Title>STOP!</Modal.Title>
          </Modal.Header>
          <Modal.Body>

              <Row>
                <Col xs={6} md={3}>
                  <img width="60px" class="img-responsive" src="../images/block.svg"/>
                </Col>

                <Col xs={12} md={9}>
                  <p><b>You have been stopped by a police officer who tells you that an accident had occurred in this block.</b>
                  The police have arrived at the scene and diverting all traffic to neighboring blocks.</p>
                  <p>Click OK to see the change in traffic and read the notifications.</p>
                </Col>
              </Row>

          </Modal.Body>
          <Modal.Footer>
            <Button variant="primary" onClick={this.props.onIncidentOK}>OK</Button>
          </Modal.Footer>
        </Modal>


      );
    }

  }export default IncidentAlert;
