import React from 'react'
import Button from 'react-bootstrap/Button'
import ButtonToolbar from 'react-bootstrap/ButtonToolbar'

class ActionButtonBar extends React.Component{

	constructor(props) {
		super(props);
	  }

	render() {
		let direction = this.props.nextmove.toUpperCase();
		 return (
       <ButtonToolbar>
				 	<div className="grid-span-toolbar nextmove">The assistant suggests that the best move from the current position is to: MOVE {direction} </div>
				 	<div>
	 					<Button variant="primary" id="go" onClick={this.props.handleClick} disabled={this.props.disabled}>Go</Button>
						<Button variant="outline-primary" id="stop" onClick={this.props.handleClick} disabled={this.props.disabled}>Interrupt</Button>
					</div>
   		</ButtonToolbar>
	  );
	}
}export default ActionButtonBar;
