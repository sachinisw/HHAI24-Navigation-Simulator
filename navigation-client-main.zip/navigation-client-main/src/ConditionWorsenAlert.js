import React from 'react'
import Modal from 'react-bootstrap/Modal'
import Container from 'react-bootstrap/Container'
import Row from 'react-bootstrap/Row'
import Col from 'react-bootstrap/Col'
import Button from 'react-bootstrap/Button'

class ConditionWorsenAlert extends React.Component{

  constructor(props) {
		super(props);
	  }


    render() {
       return (

         <Modal show={this.props.showCondition} backdrop="static">
          <Modal.Header>
            <Modal.Title>Friend's Condition Worsened!</Modal.Title>
          </Modal.Header>
          <Modal.Body>

              <Row>
              <Col xs={6} md={3}>
                <img width="60px" class="img-responsive" src="../images/sick.png"/>
              </Col>

                <Col xs={12} md={9}>
                  <p>Your friend's health has taken a bad turn. They are now running a high fever and feeling dizzy.</p>
                </Col>
              </Row>

          </Modal.Body>
          <Modal.Footer>
            <Button variant="primary" onClick={this.props.onCondition}>Continue</Button>
          </Modal.Footer>
        </Modal>


      );
    }

  }export default ConditionWorsenAlert;
