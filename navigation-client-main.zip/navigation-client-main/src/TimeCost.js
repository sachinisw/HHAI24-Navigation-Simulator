import React from 'react'

class TimeCost extends React.Component{

  constructor(props){
    super(props);
  };

  render(){
    return(
      <div className="valueLabels Time">{this.props.value}</div>
    );
  }
}export default TimeCost;
