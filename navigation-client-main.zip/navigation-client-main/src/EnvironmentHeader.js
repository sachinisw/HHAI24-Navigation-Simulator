import React from 'react'
import Accordion from 'react-bootstrap/Accordion'
import Col from 'react-bootstrap/Col'

class EnvironmentHeader extends React.Component{

  constructor(props) {
		super(props);
	}

	render() {
		 return (

         <Accordion defaultActiveKey={["0","1","2"]} alwaysOpen>
            <Accordion.Item eventKey="0">
              <Accordion.Header><b>What is happening?</b></Accordion.Header>
              <Accordion.Body>
              While preparing breakfast at home, your friend, who happened to be visiting you for a few days, started having stomach pains. The pain has worsened.
              You decide to drive your friend to the hospital. <br/>


              The city is arranged in a grid and the hospital is in the north-east (i.e., top-left) corner.
              You know that, on your way to the hospital you must pass three landmark locations: a grocery store, a school and a construction site.
              A cell on the grid represents a block. Click the <b>Start Task</b> button to see the layout of the city. <br/>

              Currently, the city is undergoing a lot of development.
              Navigating with Google Maps is not reliable because there are unplanned road closures and traffic.
              Ongoing development has created unsafe road conditions in some parts of the town. Unsafe areas are shown in red. It will take a longer travel time to go through the red blocks.<br />


              <br/>You must take your friend to the hospital within the <b>time budget</b>, {this.props.timeBudget} minutes, while keeping an eye out for your friend's condition.
              You must also pay attention to the <b>blocks budget</b> as your car only has <b>fuel</b> to drive {this.props.distanceBudget} blocks.
              When the blocks budget reaches zero, the car will run out of fuel. At this point your car will stop and you will not be able to complete the trip.<br/><br/>
              You are using a new intelligent assistant to help you navigate.
              </Accordion.Body>
            </Accordion.Item>
            <Accordion.Item eventKey="1">
              <Accordion.Header><b>Instructions</b></Accordion.Header>
              <Accordion.Body>
              <ul>
              <li> The marker indicates the current position. Click the <b>Go</b> button to move the marker to the hospital. The assistant will help by proposing the next direction.</li>
              <li> Click the <b>Interrupt</b> button to change the assistant's direction. </li>
              <li> Allowed moves are UP, DOWN, LEFT, RIGHT. </li>
              <li> You will complete the navigation task twice. In each instance, you will be helped by a different assistant. Which one you will be working first will be assigned randomly.</li>
                  <ul>
                    <li> The assistant <b>Dede</b> will propose directions to minimize the number of blocks travelled. You will travel 1 mile to go from one block to the next. The distances are shown on the top-right corner in each cell</li>
                    <li> The assistant <b>Cece</b> will propose directions to minimize the travel time by avoiding red blocks.
                        <b>The travel time to go through a red block is 3 minutes. The travel time to go through a normal block is 1 minute.</b></li>
                  </ul>
              </ul>
              </Accordion.Body>
            </Accordion.Item>
            <Accordion.Item eventKey="2">
              <Accordion.Header><b>Watch a Tutorial Video</b></Accordion.Header>
              <Accordion.Body>
                <div>
                  <iframe
                    style={{
                     width: "780",
                     height: "440"
                    }}
                    src="https://www.youtube.com/embed/01zvtVLTsNI"
                    frameborder="0"
                    allow="encrypted-media"
                    allowfullscreen
                  />{" "}
                </div>
              </Accordion.Body>
            </Accordion.Item>
        </Accordion>


      );
    }

}export default EnvironmentHeader;
