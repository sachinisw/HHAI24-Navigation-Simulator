import React from 'react'
import Container from 'react-bootstrap/Container'
import Card from 'react-bootstrap/Card'
import Row from 'react-bootstrap/Row'
import Col from 'react-bootstrap/Col'

class RedZoneAlert extends React.Component{

  constructor(props) {
		super(props);
  }


  render() {
    
     return (

       <Row>
  			<Col sm className="instructions">

         <Card bg="light">
           <Card.Header><img className="panel-icon-img" src="../images/alert.png"/><b>Caution</b></Card.Header>

   			  <Card.Body>
   				<Card.Text>
             The assistant's proposed next move will take you into a red block. Remember, the travel time to go through a red block is 3 minutes.
   				</Card.Text>
   			  </Card.Body>
   			</Card>

        </Col>
  		 </Row>

    );
  }

}export default RedZoneAlert;
