import React from 'react'
import Button from 'react-bootstrap/Button'
import Table from 'react-bootstrap/Table'
import Row from 'react-bootstrap/Row'
import Col from 'react-bootstrap/Col'
import Card from 'react-bootstrap/Card'
import CardGroup from 'react-bootstrap/CardGroup'
import Container from 'react-bootstrap/Container'
import Alert from 'react-bootstrap/Alert'
import Form from 'react-bootstrap/Form'
import FormGroup from 'react-bootstrap/FormGroup'
import {consentFormComplete} from './FormValidator'

class InformedConsent extends React.Component{

	constructor(props) {
		super(props);
		this.handleFormSubmit = this.handleFormSubmit.bind(this);
		this.collectData = this.collectData.bind(this);
		this.setErrorValues = this.setErrorValues.bind(this);
		this.validateandSubmit = this.validateandSubmit.bind(this);
		this.fetch = this.fetch.bind(this);
		this.state = {
			q1:"",
			q2:"",
			q3:"",
			q4:"",
			q5:"",
			q6:"",
			q7:"",
			q8:"",
			checkedQ1:"",
			checkedQ2:"",
			checkedQ3:"",
			checkedQ4:"",
			checkedQ5:"",
			checkedQ6:"",
			checkedQ7:"",
			checkedQ8:"",
			checked_false:false,
			checked_true:true,
			eq1:false,	//empty
			eq2:false,
			eq3:false,
			eq4:false,
			eq5:false,
			eq6:false,
			eq7:false,
			eq8:false,
			alertmsg1:"",
			displayAlert:null,
			connectionError:null,
			validated:false,
			consentok:false
		};
	}

	handleFormSubmit(event) { //In our handler for the submit event, we need to stop the event from bubbling up and trying to submit the form to another page which causes a refresh and then posts all of our data appended to the web address. The line of code that does this is event.preventDefault()
		event.preventDefault();
		let valuearr = [{q1:this.state.q1},{q2:this.state.q2},{q3:this.state.q3},{q4:this.state.q4},
						{q5:this.state.q5},{q6:this.state.q6},
						{q7:this.state.q7},{q8:this.state.q8}]
		let errEmpty = consentFormComplete(valuearr)
		this.setErrorValues(errEmpty)
	}

	setErrorValues(errIncomplete){
		//set empty field error
		let msg=' Question(s):'
		let e1=false,e2=false,e3=false,e4=false,e5=false,e6=false,e7=false,e8=false

		for(let i=0; i<errIncomplete.length; i++){
			let ob=errIncomplete[i]
			if(Object.keys(ob)[0]==="q1"){
				e1=true
				msg+=" 1,"
			}else if(Object.keys(ob)[0]==="q2") {
				e2=true
				msg+=" 2,"
			}else if(Object.keys(ob)[0]==="q3") {
				e3=true
				msg+=" 3,"
			}else if(Object.keys(ob)[0]==="q4") {
				e4=true
				msg+=" 4,"
			}else if(Object.keys(ob)[0]==="q5") {
				e5=true
				msg+=" 5,"
			}else if(Object.keys(ob)[0]==="q6") {
				e6=true
				msg+=" 6,"
			}else if(Object.keys(ob)[0]==="q7") {
				e7=true
				msg+=" 7,"
			}else if(Object.keys(ob)[0]==="q8") {
				e8=true
				msg+=" 8,"
			}
		}
		if (errIncomplete.length>0) {
			msg+=" can not be blank."
		}else{
			msg=""
		}
		this.setState({
			eq1:e1,	//empty
			eq2:e2,
			eq3:e3,
			eq4:e4,
			eq5:e5,
			eq6:e6,
			eq7:e7,
			eq8:e8,
			alertmsg1:msg,
		},
		function ()
		{
			this.validateandSubmit();
		});
	}

	validateandSubmit(){ //TODO: collect ProlificID from url here
		let al=null
		if(this.state.eq1 || this.state.eq2 ||this.state.eq3 ||this.state.eq4 ||this.state.eq5
		|| this.state.eq6 || this.state.eq7 || this.state.eq8 ){
			al = <Alert variant="danger"> <Alert.Heading> Errors in Consent Form! </Alert.Heading> <hr />
				<div className="mb-0">{this.state.alertmsg1}</div>
			</Alert>
		}else{
			let valuearr = [{q1:this.state.q1},{q2:this.state.q2},{q3:this.state.q3},{q4:this.state.q4},
						{q5:this.state.q5},{q6:this.state.q6},{q7:this.state.q7},{q8:this.state.q8}]
			let obj = {prolific: this.props.prolific, answers: valuearr};
			this.fetch("CONSENT#"+JSON.stringify(obj))
		}
		this.setState({
			displayAlert:al
		});
	}

	collectData(event){
		if(event.target.name==="q1"){
			if(event.target.checked){
				this.setState({
				 q1:event.target.value,
				 checkedQ1:this.state.checked_true
				 });
			}else{
				this.setState({
					q1:"",
				 	checkedQ1:this.state.checked_false
				 });
			}
		}else if(event.target.name==="q2"){
			if(event.target.checked){
				this.setState({
				 q2:event.target.value,
				 checkedQ2:this.state.checked_true
				 });
			}else{
				this.setState({
					q2:"",
				 	checkedQ2:this.state.checked_false
				 });
			}
		}else if(event.target.name==="q3"){
			if(event.target.checked){
				this.setState({
				 q3:event.target.value,
				 checkedQ3:this.state.checked_true
				 });
			}else{
				this.setState({
					q3:"",
				 	checkedQ3:this.state.checked_false
				 });
			}
		}else if(event.target.name==="q4"){
			if(event.target.checked){
				this.setState({
				 q4:event.target.value,
				 checkedQ4:this.state.checked_true
				 });
			}else{
				this.setState({
					q4:"",
				 	checkedQ4:this.state.checked_false
				 });
			}
		}else if(event.target.name==="q5"){
			if(event.target.checked){
				this.setState({
				 q5:event.target.value,
				 checkedQ5:this.state.checked_true
				 });
			}else{
				this.setState({
					q5:"",
				 	checkedQ5:this.state.checked_false
				 });
			}
		}else if(event.target.name==="q6"){
			if(event.target.checked){
				this.setState({
				 q6:event.target.value,
				 checkedQ6:this.state.checked_true
				 });
			}else{
				this.setState({
					q6:"",
				 	checkedQ6:this.state.checked_false
				 });
			}
		}else if(event.target.name==="q7"){
			if(event.target.checked){
				this.setState({
				 q7:event.target.value,
				 checkedQ7:this.state.checked_true
				 });
			}else{
				this.setState({
					q7:"",
				 	checkedQ7:this.state.checked_false
				 });
			}
		}else if(event.target.name==="q8"){
			if(event.target.checked){
				this.setState({
				 q8:event.target.value,
				 checkedQ8:this.state.checked_true
				 });
			}else{
				this.setState({
					q8:"",
				 	checkedQ8:this.state.checked_false
				 });
			}
		}
	}

	async fetch(input) {
				let id = input.split("#")[0]; //conveys type of request. give consent
				let data = input.split("#")[1]; //gives the parameters needed for the server to produce an output for the request
				let clientRequest = {   // Create client->server request message. IMPORTANT: This object must match the structure of whatever object the server is reading into
						parameters: data,
						type: id
				};
				try {
						// Attempt to send `clientRequest` via a POST request to java backend running on port 9999// Notice how the end of the url below matches what the server is listening on
						//let serverUrl = window.location.href.substring(0, window.location.href.length - 6) + ":9999/api";
						let serverUrl = "http://localhost:9999/api"
						let jsonReturned = await fetch(serverUrl,
								{
										method: "POST",
										body: JSON.stringify(clientRequest)
								});
						let ret = await jsonReturned.json();// Wait for server to return and convert it to json.
						let retJSON = JSON.parse(ret); //parse ret to JSON object. check retJSON.type and apply correct behavior
						if(retJSON.type==="CONSENT-RESPONSE" && retJSON.message==="SUCCESS"){
							this.props.consentSuccess(true)
							this.setState({
								 consentok: true
						 });
						}else{
							let msg = retJSON.msg
							if(msg.includes("Prolific ID already exists")){
								let err =
								 <Alert varient="danger">
									 <h4 className="alert-heading">Error</h4>
									 Your Prolific ID is already in the database. You can only complete this study once.
								 </Alert>
									this.setState({
										 connectionError: err,
										 consentok: false
								 });
							}else{
								let err =
								 <Alert varient="danger">
									 <h4 className="alert-heading">Error</h4>
									 Could not complete the informed consent process. <p>Contact administrator: sachini.weerawardhana@kcl.ac.uk </p>
								 </Alert>
									this.setState({
										 connectionError: err,
										 consentok: false
								 });
							}
						}
				 } catch (e) {
					 console.log(e);
					 let err =
						<Alert varient="danger">
							<h4 className="alert-heading">Error</h4>
							Could not connect to the remote server. <p>Contact administrator: sachini.weerawardhana@kcl.ac.uk </p>
						</Alert>
						 this.setState({
								connectionError: err
						});
				}
		}

	render() {
		 return (
			<Card>
			  <Card.Header><b>Consent Form to Participate in the Research Project</b></Card.Header>
			  <Card.Body>
				<Card.Text>
					Please complete this form after you have read the Information Sheet. <br/><br/>

				<b>ETHICAL CLEARNCE REFERENCE NUMBER</b> <br/>
						LRM-21/22-26742 <br/><br/>
				</Card.Text>

				<Form onSubmit={this.handleFormSubmit} noValidate>
				 <Form.Group>{this.state.displayAlert}</Form.Group>
				 <Table striped bordered hover>
					 <tbody>
						 <tr>
							 <td>
								 <Form.Label className={this.state.eq1?'form-label-error':''}>
									 1.	I confirm that I have read and understood the information sheet dated 31/1/22 for the above project. I have had the opportunity to consider the information and asked questions which have been answered to my satisfaction.
							 		</Form.Label>
								</td>
							 <td>
								 <Form.Group as={Col}>
								 <Form.Check disabled={this.state.consentok} type="checkbox" label="Yes" id="yes1" name="q1" value="Y" checked={this.state.checkedQ1} onChange={this.collectData} required/>
								 </Form.Group>
							 </td>
						 </tr>

						 <tr>
							 <td>
								 <Form.Label className={this.state.eq2?'form-label-error':''}>
								 2. I consent voluntarily to be a participant in this project.
								 I understand that I can refuse to take part and can withdraw from the project without having to give a reason before 31/8/2022.
								 I understand that withdrawal will not be possible after 31/8/2022.
								 I understand that if I decide to withdraw from the study I must use the <a href="https://participant-help.prolific.co/hc/en-gb/articles/360022342094-How-do-I-withdraw-my-participation-in-a-study-#:~:text=If%20you're%20active%20in,click%20the%20red%20looped%20arrow." target="_blank" rel="noopener noreferrer">Study Withdrawal Policy in Prolific</a> before 31/8/2022.
								 I understand that upon receiving my withdraw request the researcher will delete my data.


								 </Form.Label>
								</td>
							 <td>
								 <Form.Group as={Col}>
									 <Form.Check disabled={this.state.consentok} type="checkbox" label="Yes" id="yes2" name="q2" value="Y" checked={this.state.checkedQ2} onChange={this.collectData} required/>
								 </Form.Group>
							 </td>
						 </tr>

						 <tr>
							 <td>
								 <Form.Label className={this.state.eq3?'form-label-error':''}>
								 3.	I consent to the processing of my personal information for the purposes explained to me in the Information Sheet. I understand that such information will be handled under the terms of UK data protection law, including the UK General Data Protection Regulation (UK GDPR) and the Data Protection Act 2018.
								 </Form.Label>
								</td>
							 <td>
								 <Form.Group as={Col}>
									 <Form.Check disabled={this.state.consentok} type="checkbox" label="Yes" id="yes3" name="q3" value="Y" checked={this.state.checkedQ3} onChange={this.collectData} required/>
								 </Form.Group>
							 </td>
						 </tr>

						 <tr>
							 <td>
								 <Form.Label className={this.state.eq4?'form-label-error':''}>
								4.	I understand that my information may be subject to review by responsible individuals from the College for monitoring and audit purposes.
								</Form.Label>
								</td>
							 <td>
								 <Form.Group as={Col}>
									 <Form.Check disabled={this.state.consentok} type="checkbox" label="Yes" id="yes4" name="q4" value="Y" checked={this.state.checkedQ4} onChange={this.collectData} required/>
								 </Form.Group>
							 </td>
						 </tr>

						 <tr>
							 <td>
								 <Form.Label className={this.state.eq5?'form-label-error':''}>
								5.  I understand that confidentiality will be maintained, and it will not be possible to identify me in any research outputs.
								 </Form.Label>
								</td>
							 <td>
								 <Form.Group as={Col}>
 									<Form.Check disabled={this.state.consentok} type="checkbox" label="Yes" id="yes5" name="q5" value="Y" checked={this.state.checkedQ5} onChange={this.collectData} required/>
 							 </Form.Group>
							 </td>
						 </tr>

						 <tr>
							 <td>
								 <Form.Label className={this.state.eq6 ?'form-label-error':''}>
								 6. I agree that the research team may use my data for future research and understand that any such use of identifiable data would be reviewed and approved by a research ethics committee. (In such cases, as with this project, data would not be identifiable in any report).
								 </Form.Label>
								</td>
							 <td>
								 <Form.Group as={Col}>
								 <Form.Check disabled={this.state.consentok} type="checkbox" label="Yes" id="yes6" name="q6" value="Y" checked={this.state.checkedQ6} onChange={this.collectData} required/>
								 </Form.Group>
							 </td>
						 </tr>

						 <tr>
							 <td>
								 <Form.Label className={this.state.eq7?'form-label-error':''}>
								 	7. I understand that I must not take part if I fall under the exclusion criteria as described in the Do I Have to Take Part? Section in the online Information Sheet.
								 </Form.Label>
								</td>
							 <td>
								 <Form.Group as={Col}>
									 <Form.Check disabled={this.state.consentok} type="checkbox" label="Yes" id="yes7" name="q7" value="Y" checked={this.state.checkedQ7} onChange={this.collectData} required/>
								</Form.Group>
							 </td>
						 </tr>

						 <tr>
							 <td>
								 <Form.Label className={this.state.eq8 ?'form-label-error':''}>
								8.  I understand that the information I have submitted will be published in scientific conferences such as ACM CHI Conference on Human Factors in Computing Systems. I also understand that I can request a copy of the published work by emailing the researcher.
								 </Form.Label>
								</td>
							 <td>
								 <Form.Group as={Col}>
									 <Form.Check disabled={this.state.consentok} type="checkbox" label="Yes" id="yes8" name="q8" value="Y" checked={this.state.checkedQ8} onChange={this.collectData} required/>
								</Form.Group>
							 </td>
						 </tr>

					 </tbody>
				 </Table>


				 <Form.Group as={Row}>
				 <Col sm={{ span: 10}}>
						 {!this.state.consentok ? <Button type="submit" >Agree and Submit</Button> : null}
						 {this.state.consentok ? <Alert variant="info"> Thank you. Click the <b>Experiment Tasks</b> tab above to begin the experiment. </Alert> : null}
						 {this.state.connectionError}
				 </Col>
				 </Form.Group>
		 </Form>

			  </Card.Body>
			</Card>


	  );
	}
}export default InformedConsent;
