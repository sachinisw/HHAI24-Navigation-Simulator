import React, { useState } from 'react'
import Form from 'react-bootstrap/Form'
import FormGroup from 'react-bootstrap/FormGroup'
import Container from 'react-bootstrap/Container'
import Card from 'react-bootstrap/Card'
import Row from 'react-bootstrap/Row'
import Col from 'react-bootstrap/Col'
import Button from 'react-bootstrap/Button'
import Alert from 'react-bootstrap/Alert'
import Modal from 'react-bootstrap/Modal'
import {intermediateTrustResponse} from './FormValidator'


class InterimQuestionnaire extends React.Component{
	constructor(props) {
		super(props);
		this.handleFormSubmit = this.handleFormSubmit.bind(this);
		this.collectData = this.collectData.bind(this);
		this.setErrorValues = this.setErrorValues.bind(this);
		this.validateandSubmit = this.validateandSubmit.bind(this);
		this.fetch = this.fetch.bind(this);
		this.state = {
			q1:"",
			q2:"",
			q3:"",
			eq1:false,	//empty
			eq2:false,
      show:true,
			alertmsg1:"",
			displayAlert:null,
			validated:false,
			connectionError:null
		};
	  }

	  handleFormSubmit(event) { //In our handler for the submit event, we need to stop the event from bubbling up and trying to submit the form to another page which causes a refresh and then posts all of our data appended to the web address. The line of code that does this is event.preventDefault()
			event.preventDefault();
			let q2 = this.state.q2
			if(this.props.interrupts == 0){
				q2 = "0"
			}
			let valuearr = [{q1:this.state.q1},{q2:q2},{q3:this.state.q3}]
			let errComplete = intermediateTrustResponse(valuearr)
			this.setErrorValues(errComplete)
	  }

	validateandSubmit(){
		let al=null
		if(this.state.eq1 || this.state.eq2){
			al = <Alert variant="danger"> <Alert.Heading> Errors in Questionnaire! </Alert.Heading> <hr />
				<div className="mb-0">{this.state.alertmsg1}</div>
			</Alert>
		}else{
			let q2 = this.state.q2
			if(this.props.interrupts == 0){
				q2 = "0"
			}
			let valuearr = [{q1:this.state.q1},{q2:q2},{q3:this.state.q3}]
			let obj = { prolificid:this.props.uid, taskid:this.props.taskid, quiz:this.props.quiz, answers: valuearr};
			this.fetch("INTERIM#"+JSON.stringify(obj))
		}
		this.setState({
			displayAlert:al
    });
	}

	setErrorValues(errEmpty){
		//set empty field error
		let msg='- Question:'
		let e1=false, e2=false
		for(let i=0; i<errEmpty.length; i++){
			let ob=errEmpty[i]
			if(Object.keys(ob)[0]==="q1"){
				e1=true
				msg+=" 1,"
			}else if(Object.keys(ob)[0]==="q2") {
				e2=true
				msg+=" 2"
			}
		}
		if (errEmpty.length>0) {
			msg+=" can not be blank."
		}else{
			msg=""
		}

		this.setState({
			eq1:e1,	//empty
			eq2:e2,
			alertmsg1:msg
		},
		function ()
		{
			this.validateandSubmit();
		});
	}

	collectData(event){
		if(event.target.name==="q1"){
			this.setState({
			 q1:event.target.value
			 });
		}else if(event.target.name==="q2"){
			if(event.target.checked){
				this.setState({
				 q2:event.target.value
				 });
			}
		}else if(event.target.name==="q3"){
			this.setState({
			 q3:event.target.value
			 });
		}
	}

	async fetch(input) {
        let id = input.split("#")[0]; //conveys type of request. give consent
        let data = input.split("#")[1]; //gives the parameters needed for the server to produce an output for the request
        let clientRequest = {   // Create client->server request message. IMPORTANT: This object must match the structure of whatever object the server is reading into
            parameters: data,
            type: id
        };
        try {
            // Attempt to send `clientRequest` via a POST request to java backend running on port 9999// Notice how the end of the url below matches what the server is listening on
            let serverUrl = window.location.href.substring(0, window.location.href.length - 6) + ":9999/api";
            let jsonReturned = await fetch(serverUrl,
                {
                    method: "POST",
                    body: JSON.stringify(clientRequest)
                });
            let ret = await jsonReturned.json();// Wait for server to return and convert it to json.
            let retJSON = JSON.parse(ret); //parse ret to JSON object. check retJSON.type and apply correct behavior
            if((retJSON.type==="INTERIM-RESPONSE-GROCERY" && retJSON.message==="SUCCESS")
							|| (retJSON.type==="INTERIM-RESPONSE-SCHOOL" && retJSON.message==="SUCCESS")
						  || (retJSON.type==="INTERIM-RESPONSE-CONSTRUCTION" && retJSON.message==="SUCCESS") ){
							this.props.unmount()
              this.setState({
          			show:false
          		});
						}
         } catch (e) {
           let err =
						<Alert color="danger">
							<h4 className="alert-heading">Error</h4>
							There was an error connecting to the remote server. <p>Contact administrator: sachini.weerawardhana@kcl.ac.uk </p>
						</Alert>
						 this.setState({
								connectionError: err
						});
        }
    }

	render() {
		 return (
       <Modal show={this.state.show} backdrop="static" keyboard={false} size="lg">
         <Modal.Header>
            <Modal.Title>Evaluate the Navigation Assistant</Modal.Title>
          </Modal.Header>

          <Modal.Body>
            <Form onSubmit={this.handleFormSubmit} noValidate>

             <Form.Group>{this.state.displayAlert}</Form.Group>

						 <Form.Group><b>Considering the completed part of the trip</b><br/><br/></Form.Group>

						 <Form.Group>
               <Form.Label className={(this.state.eq1)?'form-label-error':''}>
               <b>Q1:</b> I am confident in the assistant's ability to help me find the path to the hospital while meeting the travel time and safety requirements.
               </Form.Label>
               <Form.Group as={Col}>
                 <Form.Check inline="true" type="radio" label="1 (Not at all)" name="q1" value="1" onChange={this.collectData} required />
                 <Form.Check inline="true" type="radio" label="2" name="q1" value="2" onChange={this.collectData}  required />
                 <Form.Check inline="true" type="radio" label="3" name="q1" value="3" onChange={this.collectData} required />
                 <Form.Check inline="true" type="radio" label="4" name="q1" value="4" onChange={this.collectData} required />
                 <Form.Check inline="true" type="radio" label="5" name="q1" value="5" onChange={this.collectData} required />
                 <Form.Check inline="true" type="radio" label="6" name="q1" value="6" onChange={this.collectData} required />
                 <Form.Check inline="true" type="radio" label="7" name="q1" value="7" onChange={this.collectData} required />
                 <Form.Check inline="true" type="radio" label="8" name="q1" value="8" onChange={this.collectData} required />
                 <Form.Check inline="true" type="radio" label="9" name="q1" value="9" onChange={this.collectData} required />
                 <Form.Check inline="true" type="radio" label="10 (Extremely)" name="q1" value="10" onChange={this.collectData} required />
               </Form.Group>
             </Form.Group>
						 <br/>

								 {
									 this.props.interrupts > 0 &&
									 <Form.Group>
											<Form.Label className={(this.state.eq2)?'form-label-error':''}>
											<b>Q2:</b> When you interrupted after seeing the assitant's proposed move, recall that the assitant provided an explanation as to why it suggested that move.
										 Rate the helpfulness of the assistant's explanation. <br/>
											</Form.Label>
											<Form.Group as={Col}>
												<Form.Check inline="true" type="radio" label="1 (Not at all)" name="q2" value="1" onChange={this.collectData} required />
												<Form.Check inline="true" type="radio" label="2" name="q2" value="2" onChange={this.collectData}  required />
												<Form.Check inline="true" type="radio" label="3" name="q2" value="3" onChange={this.collectData} required />
												<Form.Check inline="true" type="radio" label="4" name="q2" value="4" onChange={this.collectData} required />
												<Form.Check inline="true" type="radio" label="5" name="q2" value="5" onChange={this.collectData} required />
												<Form.Check inline="true" type="radio" label="6" name="q2" value="6" onChange={this.collectData} required />
												<Form.Check inline="true" type="radio" label="7" name="q2" value="7" onChange={this.collectData} required />
												<Form.Check inline="true" type="radio" label="8" name="q2" value="8" onChange={this.collectData} required />
												<Form.Check inline="true" type="radio" label="9" name="q2" value="9" onChange={this.collectData} required />
												<Form.Check inline="true" type="radio" label="10 (Extremely)" name="q2" value="10" onChange={this.collectData} required />
											</Form.Group>
									</Form.Group>
						 		}

						<br/>

								{
									this.props.interrupts > 0 &&
									<Form.Group>
										<label> <b>Q3:</b> Explain why you assigned the helpfulness rating: <textarea name="q3" rows="5" cols="80" wrap="true" value={this.state.q3} onChange={this.collectData} /> </label>
									</Form.Group>
								}


             <Form.Group as={Row}>
                 <Col>
                 <br/>
                 <Button type="submit">Submit</Button>
                 {this.state.connectionError}
                 </Col>
            </Form.Group>
            </Form>
          </Modal.Body>

      </Modal>

		);
	 }
}export default InterimQuestionnaire;
