import React from 'react'
import Row from 'react-bootstrap/Row'
import Col from 'react-bootstrap/Col'
import Card from 'react-bootstrap/Card'
import CardGroup from 'react-bootstrap/CardGroup'
import Container from 'react-bootstrap/Container'
import Table from 'react-bootstrap/Table'
import Alert from 'react-bootstrap/Alert'
import Form from 'react-bootstrap/Form'
import FormGroup from 'react-bootstrap/FormGroup'

class InformedConsentSuccess extends React.Component{

	constructor(props) {
		super(props);
	}

	render() {
		 return (

		 <Row>
			<Col sm>
			<Card>
				<Card.Header><b>Information Sheet for Participants</b></Card.Header>
			  <Card.Body>
				<Card.Text>
				<img src="/images/kcl_logo.png" className={"logo_kcl"}/>

				<b>ETHICAL CLEARNCE REFERENCE NUMBER</b> <br/>
				LRM-21/22-26742 <br/><br/>

			<b>VERSION NUMBER</b> <br/>
				31/1/22 <br/><br/>

				<b>TITLE OF STUDY</b> <br/>
				Understanding How Humans Interact with an Intelligent Assistant During a Collaborative Navigation Task<br/><br/>

				<b>INVITATION</b> <br/>
				I would like to invite you to participate in this research project which forms part of my post-doctoral research at the Trustworthy Autonomous Systems (TAS) Hub at the King’s College London. Before you decide whether you want to take part, it is important for you to understand why the research is being done and what your participation will involve. Please take time to read the following information carefully and discuss it with others if you wish. Please contact me via email: sachini.weerawardhana@kcl.ac.uk if there is anything that is not clear or if you would like more information.<br/><br/>

				<b>WHAT IS THE PURPOSE OF THE PROJECT?</b> <br/>
				The purpose of the project to better understand how users develop trust while interacting with an intelligent assistant. The human user must find a path from a starting location to a destination location in a game like environment, while minimizing time of travel and maintaining the required level of safety. The intelligent assistant helps the user by giving the direction to turn. <br/><br/>

				<b>WHY HAVE I BEEN INVITED TO TAKE PART?</b> <br/>
				You are being invited to participate in this project because as a user of computers and software applications, your participation in this study will help the researchers understand human user interactions with an autonomous agent. This understanding will lead to building autonomous agents that are capable of assisting users make safe decisions, while working on unfamiliar and complex environments.<br/><br/>

			  <b>WHAT WILL HAPPEN IF I TAKE PART?</b> <br/>
				If you choose to take part in the project you will be asked to complete a navigational task and answer survey questions. You will use a web based application to complete the tasks. <br/>

				First, for the experimental activities you will be asked to complete a set of navigation tasks. In each navigation task you are required to find a path from a starting location to the destination while meeting with the time travelled and safety thresholds. You will receive help from an automated navigation assistant to complete each task.<br/>
				Estimated completion time: 15 minutes.<br/>

				During the navigation task, a short survey with 1 question will ask you to rate your confidence in the agent’s ability to help you complete the task in a 10-point scale. <br/>
				If you wish, you can also give additional feedback by writing free text comments in the survey. <br/>
				Estimated completion time: 1 minute. <br/>

				After the navigation task is complete, you will be asked to complete a survey with 4 questions to assess the autonomous agent. The questions will ask you to rate in a 10 point scale, the predictability of the system, reliability, faith and overall trust you have in the autonomous agent.<br/>
				Estimated completion time: 3 minutes.<br/>

				Next, you will be asked to complete a demographic survey with 11 questions. The questions will ask about your gender, age, education background and experiences in interaction with autonomous systems.<br/>
				Estimated completion time: 3 minutes.<br/>

				Upon completion of the demographic survey, you will be paid £5.00 through your <a href="https://prolific.co/" target="_blank" rel="noopener noreferrer">Prolific account</a>. Note that you must be a registered user in <a href="https://prolific.co/" target="_blank" rel="noopener noreferrer">Prolific</a> to be able to receive the money. All tasks can be completed in one session.<br/>

				As part of participation you will be asked to provide data about your gender, age, education background and experiences in using autonomous systems. This is because in order to design user friendly autonomous assistsants, the researchers need to understand the interaction patterns in diverse user groups. The web based software application will log the events that happen during your interaction such as mouse clicks and answers to questions. This data will be used by the researchers to understand human user interactions in autonomous navigation.
				If you wish to withdraw from participation, please follow the <a href="https://participant-help.prolific.co/hc/en-gb/articles/360022342094-How-do-I-withdraw-my-participation-in-a-study-#:~:text=If%20you're%20active%20in,click%20the%20red%20looped%20arrow." target="_blank" rel="noopener noreferrer">Study Withdrawal Policy in Prolific</a>.
				Please do <b>not</b> email the researcher to withdraw from the study. There will not be any audio or video recordings of your session.<br/><br/>

				<b>DO I HAVE TO TAKE PART?</b><br/>
				You cannot participate in this study if you are below the the age of 18 years or if you cannot read and understand English language or you have not interacted with web based software applications before or are not comfortable interacting with web based software applications or are not registered in <a href="https://prolific.co/" target="_blank" rel="noopener noreferrer">Prolific</a> as a participant.<br/>

				Participation is completely voluntary. You should only take part if you want to and choosing not to take part will not disadvantage you in any way. Once you have read the information sheet, please contact the researcher if you have any questions that will help you make a decision about taking part. If you choose to take part you will be asked to provide your consent. To do this you will be asked to complete the consent form at the end of this information sheet. Consent is given for each statement in the consent form by selecting the corresponding checkbox. The consent form indicates that you have read and understand the information provided and that you consent to your data being used for the purposes explained.<br/>

				Complete the consent form by ticking the checkboxes. When you press the <b>Agree and Submit</b> button, the application will capture your Prolific ID and <b>display permanently it on the top left-hand corner </b> of the web page. If the Prolific ID displayed on the web page is not correct, Please do not proceed to the experiment tasks and contact me via email: sachini.weerawardhana@kcl.ac.uk.<br/><br/>


			<b>INCENTIVES</b><br/>
				You will be paid £5.00 as a token of appreciation for your work. This payment will be made through your Prolific account after completing all experiment tasks and submitting the surveys.
				<br/><br/>

			<b>WHAT ARE THE POSSIBLE RISKS OF TAKING PART?</b><br/>
				There are no reasonable, foreseeable discomforts, disadvantages and risks to participating in this study. You can interact with the web application at a pace you are comfortable with. The web interface will have clear and simple instructions to help you complete the tasks. Whenever your input is required, you will see text based prompts on the web application interface.<br/><br/>

			<b>WHAT ARE THE POSSIBLE BENEFITS OF TAKING PART?</b><br/>
				There are no intended benefits for the participants. However, your input will help the researchers understand how human users interact with autonomous navigation assistants. In the long term, this understanding will lead to building autonomous software capable of assisting users make safe decisions, while working on unfamiliar and complex environments.  <br/><br/>


			<b>DATA HANDLING AND CONFIDENTIALITY</b><br/>
				Your data will be processed under the terms of UK data protection law (including the UK General Data Protection
				Regulation (UK GDPR) and the Data Protection Act 2018). <br/>
				Only Sachini Weerawardhana will have access to the personal data collected during the study. This includes email addresses, self references in email communications with the researchers, Prolific id. The web application interaction data (answers to questionnaires and demographics) collected for the analysis will be pseudonymized.  The personal data will be stored in a separate table from the application interaction data. Both personal and application interaction data will be stored electronically in a secure database server in the KCL IP server space. Only Sachini Weerawardhana will have access to the secure database server. The database server will be password protected. Only the pseudonymized data will be used in the final publication. <br />
				You will not be personally identified in the final publication. <br />
				The data will be stored in the secure database server for a period of 3 years from the conclusion of the study.
				After this period, the data will be destroyed. <br />
				The data will only be shared with the research team at King’s College London. The data will be pseudonymized before being shared with the research team at King’s College London. The data will not be shared with any third parties. <br />
				The personal data will not be shared outside of the EU. <br /> <br />


			<b>DATA PROTECTION STATEMENT</b><br/>
				If you would like more information about how your data will be processed under the terms of UK data protection laws please visit: <a href="https://www.kcl.ac.uk/research/support/research-ethics/kings-college-london-statement-on-use-of-personal-data-in-research" target="_blank" rel="noopener noreferrer">KCL Statement on use of personal data in research</a>.
				<br /> <br />

				<b>WHAT IF I CHANGE MY MIND ABOUT TAKING PART?</b><br/>
				You are free withdraw at any point without having to give a reason. Withdrawing from the project will not affect you in any way. If you choose to withdraw from the project we will not retain the information you have given thus far. If you decide to withdraw from the study, please follow the <a href="https://participant-help.prolific.co/hc/en-gb/articles/360022342094-How-do-I-withdraw-my-participation-in-a-study-#:~:text=If%20you're%20active%20in,click%20the%20red%20looped%20arrow." target="_blank" rel="noopener noreferrer">Study Withdrawal Policy in Prolific</a> before 31/3/2022, and your data will be deleted. You will not be able to withdraw your data <b>after 31/3/2022</b> due to the data being pseudonymized and prepared for a peer-reviewed research article.
				<br /> <br />


				<b> HOW IS THE PROJECT BEING FUNDED?</b><br/>
					This research is funded by the UKRI Trustworthy Autonomous Systems Hub. <br/>
					Funder reference number: EP/V00784X/1 <br/><br/>

				<b>WHAT WILL HAPPEN TO THE RESULTS OF THE PROJECT?</b><br/>
				The results of the project will be summarised and published in peer reviewed research articles in ACM-CHI. Once published, the article will be available as conference proceedings. If you wish to receive a copy of the article after it has been published please email  sachini.weerawardhana@kcl.ac.uk. The pseudonymized data set will not be publicaly available. <br/><br/>

				<b>WHO SHOULD I CONTACT FOR FURTHER INFORMATION?</b><br/>
				If you have any questions or require more information about this study, please contact the researcher using the following contact details: <br/>
				<i>Sachini Weerawardhana (sachini.weerawardhana@kcl.ac.uk)</i><br/>
				<i>Luc Moreau (luc.moreau@kcl.ac.uk)</i> <br/><br/>

				<b>WHAT IF I HAVE FURTHER QUESTIONS, OR IF SOMETHING GOES WRONG?</b><br/>
				If this study has harmed you in any way or if you wish to make a complaint about the conduct of the study you can contact King's College London using the details below for further advice and information: <br/>
				<i>The Chair, BDM Research Ethics Panel, Email: rec@kcl.ac.uk</i> <br/><br/>

				<b>Thank you for reading this information sheet and for considering taking part in this research.</b>

				</Card.Text>
			  </Card.Body>
				</Card>

				<Card>
				<Card.Header><b>Consent Form to Participate in the Research Project</b></Card.Header>
			  <Card.Body>
				<Form >
				 <Table striped bordered hover>
					 <tbody>
						 <tr>
							 <td>
								 <Form.Label>
									 1.	I confirm that I have read and understood the information sheet dated 31/1/22 for the above project. I have had the opportunity to consider the information and asked questions which have been answered to my satisfaction.
									</Form.Label>
								</td>
							 <td>
								 <Form.Group as={Col}>
								 <Form.Check disabled={true} type="checkbox" label="Yes" checked={true}/>
								 </Form.Group>
							 </td>
						 </tr>

						 <tr>
							 <td>
								 <Form.Label>
								 2. I consent voluntarily to be a participant in this project.
								 I understand that I can refuse to take part and can withdraw from the project without having to give a reason before 31/3/2022.
								 I understand that withdrawal will not be possible after 31/3/2022.
								 I understand that if I decide to withdraw from the study I must use the <a href="https://participant-help.prolific.co/hc/en-gb/articles/360022342094-How-do-I-withdraw-my-participation-in-a-study-#:~:text=If%20you're%20active%20in,click%20the%20red%20looped%20arrow." target="_blank" rel="noopener noreferrer">Study Withdrawal Policy in Prolific</a> before 31/3/2022.
								 I understand that upon receiving my withdraw request the researcher will delete my data.
								 </Form.Label>
								</td>
							 <td>
								 <Form.Group as={Col}>
								 <Form.Check disabled={true} type="checkbox" label="Yes" checked={true}/>
								 </Form.Group>
							 </td>
						 </tr>

						 <tr>
							 <td>
								 <Form.Label>
								 3.	I consent to the processing of my personal information for the purposes explained to me in the Information Sheet. I understand that such information will be handled under the terms of UK data protection law, including the UK General Data Protection Regulation (UK GDPR) and the Data Protection Act 2018.
								 </Form.Label>
								</td>
							 <td>
								 <Form.Group as={Col}>
								 <Form.Check disabled={true} type="checkbox" label="Yes" checked={true}/>
								 </Form.Group>
							 </td>
						 </tr>

						 <tr>
							 <td>
								 <Form.Label>
								4.	I understand that my information may be subject to review by responsible individuals from the College for monitoring and audit purposes.
								</Form.Label>
								</td>
							 <td>
								 <Form.Group as={Col}>
								 <Form.Check disabled={true} type="checkbox" label="Yes" checked={true}/>
								 </Form.Group>
							 </td>
						 </tr>

						 <tr>
							 <td>
								 <Form.Label>
								5.  I understand that confidentiality will be maintained, and it will not be possible to identify me in any research outputs.
								 </Form.Label>
								</td>
							 <td>
								 <Form.Group as={Col}>
								 <Form.Check disabled={true} type="checkbox" label="Yes" checked={true}/>
							 </Form.Group>
							 </td>
						 </tr>

						 <tr>
							 <td>
								 <Form.Label>
								 6. I agree that the research team may use my data for future research and understand that any such use of identifiable data would be reviewed and approved by a research ethics committee. (In such cases, as with this project, data would not be identifiable in any report).
								 </Form.Label>
								</td>
							 <td>
								 <Form.Group as={Col}>
								 <Form.Check disabled={true} type="checkbox" label="Yes" checked={true}/>
								 </Form.Group>
							 </td>
						 </tr>

						 <tr>
							 <td>
								 <Form.Label>
									7. I understand that I must not take part if I fall under the exclusion criteria as described in the Do I Have to Take Part? Section in the online Information Sheet.
								 </Form.Label>
								</td>
							 <td>
								 <Form.Group as={Col}>
									 <Form.Check disabled={true} type="checkbox" label="Yes" checked={true}/>
								</Form.Group>
							 </td>
						 </tr>

						 <tr>
							 <td>
								 <Form.Label>
								8.  I understand that the information I have submitted will be published in scientific conferences ACM CHI Conference on Human Factors in Computing Systems. I also understand that I can request a copy of the published work by emailing the researcher.
								 </Form.Label>
								</td>
							 <td>
								 <Form.Group as={Col}>
									 <Form.Check disabled={true} type="checkbox" label="Yes" checked={true}/>
								</Form.Group>
							 </td>
						 </tr>

					 </tbody>
				 </Table>
		 </Form>
		 </Card.Body>
		 </Card>

			<Alert variant="info"> You have successfully completed the Informed Consent. Click the <b>Experiment Tasks</b> tab above to go to the Experiment. </Alert>
			</Col>
		 </Row>
	  );
	}
}export default InformedConsentSuccess;
