import React, { useState } from 'react'
import Container from 'react-bootstrap/Container'
import Button from 'react-bootstrap/Button'
import Modal from 'react-bootstrap/Modal'
import Row from 'react-bootstrap/Row'
import Col from 'react-bootstrap/Col'

class OutsideProlific extends React.Component{
	constructor(props) {
		super(props);
    this.goToProlific = this.goToProlific.bind(this);
	}

 goToProlific() {
   console.log("here")
   window.location.href = "https://www.prolific.co/"
  }

	render() {

		 return (

      <Modal
        show={this.props.show}
        size="lg"
        aria-labelledby="contained-modal-title-vcenter"
        backdrop="static"
        keyboard={false}
      >
      <Modal.Header closeButton>
        <Modal.Title>Restricted Access</Modal.Title>
      </Modal.Header>

      <Modal.Body>
      <Row>
        <Col xs={3} md={3}>
          <img width="60px" class="img-responsive" src="../images/locked.png"/>
        </Col>

        <Col xs={15} md={9}>
          You must be a registered Prolific user to participate in the study.
          <br/ >This web page can only be accessed through Prolific.
        </Col>
      </Row>

      </Modal.Body>

      <Modal.Footer>
        <Button variant="primary" onClick={this.goToProlific}>Login to Prolific</Button>
      </Modal.Footer>
    </Modal>

		);
	 }
}export default OutsideProlific;
