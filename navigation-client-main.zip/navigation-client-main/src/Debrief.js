import React from 'react'
import Row from 'react-bootstrap/Row'
import Col from 'react-bootstrap/Col'
import Card from 'react-bootstrap/Card'
import CardGroup from 'react-bootstrap/CardGroup'
import Container from 'react-bootstrap/Container'
import Alert from 'react-bootstrap/Alert'

class Debrief extends React.Component{

	constructor(props) {
		super(props);
	  }

	render() {
		 return (
		 <Container>
				<Card>
			  <Card.Header><b>Debriefing</b></Card.Header>
			  <Card.Body>
				<Card.Text>
				<b>ETHICAL CLEARNCE REFERENCE NUMBER</b> <br/>
				LRM-21/22-26742 <br/><br/>

				<b>VERSION NUMBER</b> <br/>
				31/1/22 <br/><br/>

				<b>TITLE OF STUDY</b> <br/>
				Understanding How Humans Interact with an Intelligent Assistant During a Collaborative Navigation Task<br/><br/>

			  <b>WHAT WAS BEING STUDIED?</b><br/>
				Nowadays, driving is more than just going from point A to point B.
				The experience has been enhanced by intelligent assistants built in to the vehicle.
				Through this study, we aim to better understand how human users develop trust in a collaborative environment where the user and the intelligent assistant interact and
				work together to complete a navigation task.

				You were presented with a navigation task where you were required to interect with two intelligent assistants with different capabilities.
				In addition to helping you with the navigation task, the assistants also have the ability to improve the interaction through explanations.
				To understand how the human user's trust develops during each task and also at the end, you were asked to subjectively rate the trust toward the intelligent assistsants through several questionnaires. <br/>

				<b>HOW WILL THE RESULTS BE EVALUATED?</b><br/>
				All responses to the questionnaires and the demographic survey will be anonymized for processing. Therefore, when the data is used in research publications, it will not be possible to connect the data with you personally.
				Only Sachini Weerawardhana will have access to the personal data collected during the study.<br/>

				<b>WHAT IF I CHANGE MY MIND ABOUT TAKING PART?</b><br/>
				You are free withdraw at any point without having to give a reason. Withdrawing from the project will not affect you in any way. If you choose to withdraw from the project we will not retain the information you have given thus far. If you decide to withdraw from the study, please follow the <a href="https://participant-help.prolific.co/hc/en-gb/articles/360022342094-How-do-I-withdraw-my-participation-in-a-study-#:~:text=If%20you're%20active%20in,click%20the%20red%20looped%20arrow." target="_blank" rel="noopener noreferrer">Study Withdrawal Policy in Prolific</a> before 31/8/2022, and your data will be deleted. You will not be able to withdraw your data <b>after 31/8/2022</b> due to the data being pseudonymized and prepared for a peer-reviewed research article.
				<br /> <br />
				</Card.Text>
				 <Alert variant="dark">Thank you for taking part in this study! <a href="https://app.prolific.co/submissions/complete?cc=45ABDCEA"> Go back to Prolific.</a></Alert>
			  </Card.Body>
			</Card>

		</Container>
	  );
	}
}export default Debrief;
