import React from 'react'
import Container from 'react-bootstrap/Container'
import Card from 'react-bootstrap/Card'
import Row from 'react-bootstrap/Row'
import Col from 'react-bootstrap/Col'
import Button from 'react-bootstrap/Button'

class PlannerMessage extends React.Component{

  constructor(props) {
		super(props);
  }

  render() {

    if(this.props.profile==="TIME"){
      name = "Dede"
    }else if(this.props.profile==="SAFETY"){
      name = "Cece"
    }

     return (
       <Row>
  			<Col sm className="instructions">

         <Card>
           <Card.Header><img className="panel-icon-img" src="../images/comment.svg"/><b>{name} Explains</b></Card.Header>
   			  <Card.Body>
   				<Card.Text>
            {this.props.msg}
   				</Card.Text>
   			  </Card.Body>
   			</Card>

        </Col>
  		 </Row>

    );
  }

}export default PlannerMessage;
