import React from 'react'
import { Alert, TabContent, TabPane, Nav, NavItem, NavLink, Card, Button, CardTitle, CardText, Row, Col } from 'reactstrap';
import Environment from './Environment'
import Demographics from './Demographics'
import InformationSheet from './InformationSheet'
import InformedConsentSuccess from './InformedConsentSuccess'
import OutsideProlific from './OutsideProlific'
import Debrief from './Debrief'
import classnames from 'classnames';

class MainApp extends React.Component{
	  constructor(props) {
			super(props);
			this.fetch = this.fetch.bind(this);
			this.toggle = this.toggle.bind(this);
			this.toggleContent = this.toggleContent.bind(this);
			this.handleGiveConsent = this.handleGiveConsent.bind(this);
			this.closing = this.closing.bind(this);
			this.endSession = this.endSession.bind(this);
			this.consentSuccess = this.consentSuccess.bind(this);
			this.accessedFromOutside = this.accessedFromOutside.bind(this);

			let pattern = new RegExp(/(https:\/\/collabplan-9090\.nms\.kcl\.ac\.uk\/\?PROLIFIC\_PID=)(.*)(\&STUDY\_ID)/)
			let str = "https://collabplan-9090.nms.kcl.ac.uk/?PROLIFIC_PID=" + String(Math.random()).substring(2) + "&STUDY_ID=629f5a6730b9c0010444b993&SESSION_ID=0p0ybhmjzawk"
			//let str = "https://collabplan-9090.nms.kcl.ac.uk/?PROLIFIC_PID=" + "49985459710025837" + "&STUDY_ID=629f5a6730b9c0010444b993&SESSION_ID=0p0ybhmjzawk"
			let url =  window.location.href
			let obj = pattern.exec(str) //TODO:: replace str with url at deploy
			let prolific = ""
			if(obj!=null){
				prolific = obj[2]
			}
			console.log("user prolific id>>>>>", prolific)
			console.log("window url=",url);

			this.state = {
				prolificid:prolific,
				activeTab: '1',
				sessionComplete:false,
				tasksComplete:false,
				active: false,
				error:null
			};
	  }

	  toggle(tab) {
			if (this.state.activeTab !== tab) {
			  this.setState({
				activeTab: tab
			  });
			}
	  }

		consentSuccess(ok){
			if(ok){
				this.setState({
						active: true
				 });
			}
		}

	async fetch(input) {
        let id = input.split("#")[0]; //conveys type of request. start game? save result?
        let data = input.split("#")[1]; //gives the parameters needed for the server to produce an output for the request
        let clientRequest = {   // Create client->server request message. IMPORTANT: This object must match the structure of whatever object the server is reading into
            parameters: data,
            type: id
        };
        try { //post to the server url
            let serverUrl = window.location.href.substring(0, window.location.href.length - 6) + ":9999/api";
            let jsonReturned = await fetch(serverUrl,
                {
                    method: "POST",
                    body: JSON.stringify(clientRequest)
                });
            let ret = await jsonReturned.json();// Wait for server to return and convert it to json.
            let retJSON = JSON.parse(ret); //parse ret to JSON object.
            let responseType = retJSON.type;//behavior changes based on the value here

						if(retJSON.type==="SOLUTIONSAVED" && retJSON.message==="SUCCESS"){
							 this.setState({
								sessionComplete: true
							});
						}
         } catch (e) {
						let err =
						<Alert color="danger">
							<h4 className="alert-heading">Error</h4>
							Could not connect to the remote server. <p>Contact administrator: sachini.weerawardhana@kcl.ac.uk </p>
						</Alert>
						 this.setState({
								error: err
						});
         }
    }

	closing(canClose){
		this.setState({
			close: canClose,
		});
	}

	endSession(){
		this.setState({
			activeTab: '3',
			puzzleComplete: true
		});
	}

  handleGiveConsent(inputstr){
			this.fetch(inputstr)
	}

  toggleContent(){ //fixes the tab activation sequence.
			let tab1=null, tab2=null, tab3=null
			if(!this.state.active){
				tab1 = <InformationSheet prolificid={this.state.prolificid} consentSuccess={this.consentSuccess}/>
			}else{
				tab1 = <InformedConsentSuccess />
			}
			if(!this.state.active){
						tab2 = <NavLink className={classnames({ active: this.state.activeTab === '2' })} onClick={() => { this.toggle('2');}} disabled >
						 Experiment Tasks
						 </NavLink>
			}else{
				tab2 = <NavLink className={classnames({ active: this.state.activeTab === '2' })} onClick={() => { this.toggle('2');}} >
				Experiment Tasks
				 </NavLink>
			}
			if(this.state.active){
				if(this.state.puzzleComplete){
					tab3 = <NavLink className={classnames({ active: this.state.activeTab === '3' })}onClick={() => { this.toggle('3');}} >
						  Demographics Survey
					</NavLink>
				}else{
					tab3 = <NavLink className={classnames({ active: this.state.activeTab === '3' })}onClick={() => { this.toggle('3');}} disabled>
						 Demographics Survey
					</NavLink>
				}
			}else{
				tab3 = <NavLink className={classnames({ active: this.state.activeTab === '3' })}onClick={() => { this.toggle('3');}} disabled>
						  Demographics Survey
					</NavLink>
			}
			return [tab1,tab2,tab3]
	}

	accessedFromOutside(){
		if(this.state.prolificid === ""){
			return <OutsideProlific show={true} />
		}
	}

	render() {
		let conditional = this.toggleContent()
		let demo = <Demographics uid={this.state.prolificid} unmount={this.closing}/>
		let outside = this.accessedFromOutside()
		 return (
			<div>
				<div><h4>Navigate with an Intelligent Assistant</h4></div>
				<div><h5>Prolific ID: {this.state.prolificid}</h5></div>
				<div>{outside}</div>
	         <Nav tabs>
	         <NavItem as="li">
						<NavLink className={classnames({ active: this.state.activeTab === '1'})} onClick={() => { this.toggle('1');}}  >
						  Information Sheet & Consent Form
						</NavLink>
			  	 </NavItem>

				  <NavItem as="li">
						{conditional[1]}
				  </NavItem>

				  <NavItem as="li">
						{conditional[2]}
				  </NavItem>
				</Nav>

				<TabContent activeTab={this.state.activeTab}>
				  <TabPane tabId="1">
					<Row>
					  <Col sm="12">
						{conditional[0]}
					  </Col>
					</Row>
				  </TabPane>

				  <TabPane tabId="2">
					<Environment prolific={this.state.prolificid} endSession={this.endSession} />
				  </TabPane>

				  <TabPane tabId="3">
					<Row>
					  <Col sm="12">
					   {this.state.puzzleComplete && !this.state.close ? demo: null }
					   {this.state.close ? <Debrief /> :null}
					  </Col>
					</Row>
				  </TabPane>
				</TabContent>

			</div>
		  );
	 }
}
export default MainApp;
