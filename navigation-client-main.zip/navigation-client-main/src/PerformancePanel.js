import React from 'react'
import Row from 'react-bootstrap/Row'
import Col from 'react-bootstrap/Col'
import Card from 'react-bootstrap/Card'
import Container from 'react-bootstrap/Container'

class PerformancePanel extends React.Component{

  constructor(props) {
		super(props);
	  }

	render() {
		 return (

        <Col sm className="instructions">
    			<Card bg="light">
    			  <Card.Header><img className="panel-icon-img" src="../images/dashboard.svg"/><b>Navigation Performance</b></Card.Header>
    			  <Card.Body className="performance">
              <div className="performanceScoreBlock">
                <div className="performanceScore performanceTime">{this.props.time}</div>
                Blocks Budget
              </div>
              <div className="performanceScoreBlock">
                <div className="performanceScore performanceSafety">{this.props.safety}</div>
                Time Budget
              </div>
              <div></div>
              <div>
                <Card.Text>
                 {String.fromCharCode(this.props.grocerycheck)} Passed the grocery store <br/>
                 {String.fromCharCode(this.props.schoolcheck)} Passed the school <br/>
                 {String.fromCharCode(this.props.constructioncheck)} Passed the construction site <br/>
        				</Card.Text>
              </div>
    			  </Card.Body>
    			</Card>
        </Col>

	  );
	}

}export default PerformancePanel;
