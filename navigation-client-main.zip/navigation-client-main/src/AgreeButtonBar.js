import React from 'react'
import Button from 'react-bootstrap/Button'
import ButtonToolbar from 'react-bootstrap/ButtonToolbar'

class AgreeButtonBar extends React.Component{

	constructor(props) {
		super(props);
	  }

	render() {
		 return (
       <ButtonToolbar>
   				<Button variant="success" id="ok" onClick={this.props.handleClick}>I agree</Button> &nbsp; &nbsp; &nbsp;
   				<Button variant="danger" id="no" onClick={this.props.handleClick}>I do not agree</Button>
   		</ButtonToolbar>
	  );
	}
}export default AgreeButtonBar;
