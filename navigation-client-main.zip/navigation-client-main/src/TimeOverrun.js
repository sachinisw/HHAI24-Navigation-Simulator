import React from 'react'
import Modal from 'react-bootstrap/Modal'
import Container from 'react-bootstrap/Container'
import Row from 'react-bootstrap/Row'
import Col from 'react-bootstrap/Col'
import Button from 'react-bootstrap/Button'

class TimeOverrun extends React.Component{

  constructor(props) {
		super(props);
	  }


    render() {
       return (

         <Modal show={this.props.showTime} backdrop="static">
          <Modal.Header>
            <Modal.Title>Time Alert</Modal.Title>
          </Modal.Header>
          <Modal.Body>

              <Row>
              <Col xs={6} md={3}>
                <img width="60px" class="img-responsive" src="../images/disappointed.png"/>
              </Col>

                <Col xs={12} md={9}>
                  <p>You are taking a longer time to take your friend to the hospital. They are in a lot of pain.</p>
                </Col>
              </Row>

          </Modal.Body>
          <Modal.Footer>
            <Button variant="primary" onClick={this.props.onShowTime}>Continue</Button>
          </Modal.Footer>
        </Modal>


      );
    }

  }export default TimeOverrun;
