import React from 'react'
import Container from 'react-bootstrap/Container'
import Card from 'react-bootstrap/Card'
import Row from 'react-bootstrap/Row'
import Col from 'react-bootstrap/Col'
import Button from 'react-bootstrap/Button'
import Spinner from 'react-bootstrap/Spinner'

class IncidentRecovery extends React.Component{

  constructor(props) {
		super(props);
    this.state={
      waiting: null,
      delay_text: "",
    }
    this.handleClick = this.handleClick.bind(this);
  }

  handleClick(event){
    let text = "Searching for a new route. Please wait"
    let delay = <Spinner animation="border" role="status" size="sm"> <span className="visually-hidden"> </span>  </Spinner>

    this.props.handleDirectionChoice(event.target.id)
    this.setState({
        waiting:delay,
        delay_text:text
    });
  }

  render() {
    let button = <Button variant="primary" id={this.props.blobat} onClick={this.handleClick} className="directionChoices">Continue</Button>

     return (

       <Row>
  			<Col sm className="instructions">

         <Card>
           <Card.Header><img className="panel-icon-img" src="../images/announcement.svg"/><b>Notifications</b></Card.Header>

   			  <Card.Body>
   				<Card.Text>
            <ul>
              <li>The areas affected by the accident are closed.</li>
              <li> The assistant will now find a new route.</li>
            </ul>
            <hr/>

            <br />Click the Continue button.
            <br /> {button}
            <br /> {this.state.waiting} {this.state.delay_text}
   				</Card.Text>
   			  </Card.Body>
   			</Card>

        </Col>
  		 </Row>



    );
  }

}export default IncidentRecovery;
