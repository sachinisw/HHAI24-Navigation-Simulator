import React from 'react'
import Modal from 'react-bootstrap/Modal'
import Container from 'react-bootstrap/Container'
import Row from 'react-bootstrap/Row'
import Col from 'react-bootstrap/Col'
import Button from 'react-bootstrap/Button'

class FuelOverrun extends React.Component{

  constructor(props) {
		super(props);
	  }


    render() {
       return (

         <Modal show={this.props.showFuel} backdrop="static">
          <Modal.Header>
            <Modal.Title>Out of Fuel!</Modal.Title>
          </Modal.Header>
          <Modal.Body>

              <Row>
              <Col xs={6} md={3}>
                <img width="60px" class="img-responsive" src="../images/fuel.png"/>
              </Col>

                <Col xs={12} md={9}>
                  <p>The car has run out of fuel (blocks budget = 0).</p>
                  <p>Stop the navigation and call a taxi or an ambulance to take your friend to the hospital.</p>
                </Col>
              </Row>

          </Modal.Body>
          <Modal.Footer>
            <Button variant="primary" onClick={this.props.onFuel}>Continue</Button>
          </Modal.Footer>
        </Modal>


      );
    }

  }export default FuelOverrun;
