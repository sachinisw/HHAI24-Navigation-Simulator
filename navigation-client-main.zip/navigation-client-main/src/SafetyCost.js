import React from 'react'

class SafetyCost extends React.Component{

  constructor(props){
    super(props);
  };

  render(){
    return(
      <div className="valueLabels Safety">{this.props.value}</div>
    );
  }
}export default SafetyCost;
