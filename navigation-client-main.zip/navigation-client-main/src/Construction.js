import React from 'react'

class Construction extends React.Component{

  constructor(props){
    super(props);
  };

  render(){
    return(
      <div className="icon Construction"> </div>
    );
  }
}export default Construction;
