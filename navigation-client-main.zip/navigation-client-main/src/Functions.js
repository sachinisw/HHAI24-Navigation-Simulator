export function getDirection(from, to){
  let from_row = ~~(from/10)
  let from_col = from%10
  let to_row = ~~(to/10)
  let to_col = to%10

  if(to_row===from_row && to_col===from_col-1){
    return "GO LEFT"
  }else if(to_row===from_row && to_col===from_col+1){
    return "GO RIGHT"
  }else if(to_col===from_col && to_row===from_row-1){
    return "GO UP"
  }else if(to_col===from_col && to_row===from_row+1){
    return "GO DOWN"
  }else{
    return ""
  }

}

//decide the actual move based on a probability. return the landing cell number
//position = current blob position
//direction = best direction to take from current blob position
//blocked = cells that are closed off now. when computing the probabilistic landing position, don't give the blocked cells as an option.
export function probabilisticLandingPosition(position, direction, blocked){
 let validated = validatedNeighbors(position, 4) //cell numbers of neighbors
 let original = getLandingPosition(position, direction); //cell number of suggested direction

 let landings = []

 for(let i=0; i<validated.length; i++){
   if(!blocked.includes(validated[i])){
     if(validated[i] != original){
        landings.push(validated[i])
     }else{
        original = validated[i]
     }
   }
 }

 let d = Math.random();
 console.log("random prob", d);
 if (d < 0.8) { // 80% chance of moving to the originally suggested direction
   console.log("going to originally proposed", original);
   return original
 } else { //choose an available direction randomly
   let randomChoice = Math.floor(Math.random() * landings.length);
   console.log("going to randomly chosen besides original", landings[randomChoice]);
   return landings[randomChoice]
 }

}

//which cell number will you land on from your current "position" if you go in the direction indicated by "direction"?
//if off the board, do the invisible move and land on the original cell. (i.e. bounce off the wall)
export function getLandingPosition(position, direction){
  console.log("getLandingPosition() now at position", position, " heading in the direction", direction)
  let row = ~~(position/10)
  let col = position%10
  let landing_row = -1
  let landing_col = -1

  if(direction==='right'){
   landing_row = row
   if(col+1 < 10 && col+1 >= 0){
     landing_col = col+1
   }else{ //go to original place. (bounce back)
     landing_col = col
   }
    return landing_col + landing_row*10
 }
 if(direction==='left'){
   landing_row = row
   if(col-1 >= 0){
     landing_col = col-1
   }else{
     landing_col = col
   }
   return landing_col + landing_row*10
 }
 if(direction==='down'){
   landing_col = col
   if(row+1 < 10 && row >=0){
     landing_row = row+1
   }else {
     landing_row = row
   }
   return landing_col + landing_row*10
 }
 if(direction==='up'){
   landing_col = col
   if(row-1 >= 0){
     landing_row = row-1
   }else{
     landing_row = row
   }
   return landing_col + landing_row*10
 }

}

//compute the 8 neighbors around the accident cell using the row/col of accident cell. only return neighbors within the 10x10 grid
//if all=true return all 8. else return 4
export function validatedNeighbors(accidentcell, option){
  let validated = []
  let row = ~~(accidentcell/10)
  let col = accidentcell%10

  let top_left = [row-1, col-1]
  let top_mid = [row-1, col]
  let top_right = [row-1, col+1]
  let same_left = [row, col-1]
  let same_right = [row, col+1]
  let bot_left = [row+1, col-1]
  let bot_mid = [row+1, col]
  let bot_right = [row+1, col+1]

  if(option==8){ // all 8 neighbors surrounding the accident cell
    if( (row-1>=0 && row-1<10) && (col-1>=0 && col-1<10) ){
      validated.push(top_left[0]*10 + top_left[1])
    }
    if( (row-1>=0 && row-1<10) && (col>=0 && col<10) ){
      validated.push(top_mid[0]*10 + top_mid[1])
    }
    if( (row-1>=0 && row-1<10) && (col+1>=0 && col+1<10) ){
      validated.push(top_right[0]*10 + top_right[1])
    }
    if( (row>=0 && row<10) && (col-1>=0 && col-1<10) ){
      validated.push(same_left[0]*10 + same_left[1])
    }
    if( (row>=0 && row<10) && (col+1>=0 && col+1<10) ){
      validated.push(same_right[0]*10 + same_right[1])
    }
    if( (row+1>=0 && row+1<10) && (col-1>=0 && col-1<10) ){
      validated.push(bot_left[0]*10 + bot_left[1])
    }
    if( (row+1>=0 && row+1<10) && (col>=0 && col<10) ){
      validated.push(bot_mid[0]*10 + bot_mid[1])
    }
    if( (row+1>=0 && row+1<10) && (col+1>=0 && col+1<10) ){
      validated.push(bot_right[0]*10 + bot_right[1])
    }
  }else if(option==4){ //left, right, up, down only
    if( (row-1>=0 && row-1<10) && (col>=0 && col<10) ){
      validated.push(top_mid[0]*10 + top_mid[1])
    }
    if( (row+1>=0 && row+1<10) && (col>=0 && col<10) ){
      validated.push(bot_mid[0]*10 + bot_mid[1])
    }
    if( (row>=0 && row<10) && (col-1>=0 && col-1<10) ){
      validated.push(same_left[0]*10 + same_left[1])
    }
    if( (row>=0 && row<10) && (col+1>=0 && col+1<10) ){
      validated.push(same_right[0]*10 + same_right[1])
    }
  }else if(option==2){ //left, right only
    if( (row>=0 && row<10) && (col-1>=0 && col-1<10) ){
      validated.push(same_left[0]*10 + same_left[1])
    }
    if( (row>=0 && row<10) && (col+1>=0 && col+1<10) ){
      validated.push(same_right[0]*10 + same_right[1])
    }
  }
  return validated;
}

//for nondet agent
//after trying to find a path to the <insert milestone> 100 times, I have found that the best direction to take from this position is to go <insert direction>
export function explainTheBestDirection(profile, milestone, direction){
  let str = "", pos = ""
  if (milestone===73){
    pos = "GROCERY"
  }else if(milestone===46){
    pos = "SCHOOL"
  }else if(milestone===14){
    pos = "CONSTRUCTION SITE"
  }else if(milestone===9){
    pos = "HOSPITAL"
  }
  if(profile==="TIME"){
    str = "I ran 100 trials to find the best path that travels the least number of blocks to the next milestone " + pos
    +". Considering all the trials, I have concluded that the best direction from this position is to MOVE " + direction.toUpperCase()
  }else if(profile==="SAFETY"){
    str = "I ran 100 trials to find the best path that avoids the red zones to the next milestone " + pos +
    ". Considering all the trials, I have concluded that the best direction from this position is to MOVE " + direction.toUpperCase()
  }
  return str
}

//for nondet agent
//after trying to find a path to the <insert milestone> 100 times, I have found that the best direction to take from this position is to go <insert direction>
export function explainTheBestDirectionAfterInterrupt(profile, milestone, direction){
  let str = "" , pos = ""
  if (milestone===73){
    pos = "GROCERY"
  }else if(milestone===46){
    pos = "SCHOOL"
  }else if(milestone===14){
    pos = "CONSTRUCTION SITE"
  }else if(milestone===9){
    pos = "HOSPITAL"
  }

  if(profile==="TIME"){
    str = "I have moved to the position you proposed. I ran 100 trials to find the best path that travels the least number of blocks to the next milestone " + pos
    +". Considering all the trials, I have concluded that the best direction from this position is to MOVE " + direction.toUpperCase()
  }else if(profile==="SAFETY"){
    str = "I have moved to the position you proposed. I ran 100 trials to find the best path that avoids the red zones to the next milestone " + pos
    +". Considering all the trials, I have concluded that the best direction from this position is to MOVE " + direction.toUpperCase()
  }
  return str
}

//deterministic environment explanation
export function explainTheBestPlan(profile, cost, timebudget, safetybudget, breakdown, grocery, construction, school){
  let str = "", s1 = "", s2 = "", s3 = "", s4 = ""

  if(profile==="TIME"){
    str = "the number of blocks travelled"
  }else if(profile==="SAFETY"){
    str = "the time travelled"
  }
  s1 =  "I found a path to the hospital that minimizes " + str
  if(profile==="TIME"){
    s2 = "The total number of blocks travelled to reach the hospital is " + cost
    if(cost<=timebudget){
      s2 += ". My path is within the blocks budget"
    }else{
      s2 += ". My path exceeds the blocks budget"
    }

  }
  if(profile==="SAFETY"){
    s2 = "The total travel time to reach the hospital is " + cost
    if(cost<=safetybudget){
      s2 += ". My path is within the time budget"
    }else{
      s2 += ". My path exceeds the time budget"
    }
  }

  s3 = "I will suggest directions from this path because it is the best path I could find for the map."
  if(breakdown.length>0){
    s4 = "On this path you will reach, "
    breakdown.sort( compare );
    let index = 0
    for (let ob of breakdown) {
      if(ob.loc===grocery){
        if(index===0){
          if(ob.objective==="TIME"){
              s4 += "first, the grocery store after " + ob.time + " blocks,"
          }else if(ob.objective==="SAFETY"){
              s4 += "first, the grocery store with travel time " + ob.safety + ","
          }
        }else if(index===1){
          if(ob.objective==="TIME"){
              s4 += "second, the grocery store after " + ob.time + " blocks,"
          }else if(ob.objective==="SAFETY"){
              s4 += "second, the grocery store with travel time " + ob.safety + ","
          }
        }else if(index===2){
          if(ob.objective==="TIME"){
              s4 += "third, the grocery store after " + ob.time + " blocks,"
          }else if(ob.objective==="SAFETY"){
              s4 += "third, the grocery store with travel time " + ob.safety + ","
          }
        }

      }else if(ob.loc===construction){
        if(index===0){
          if(ob.objective==="TIME"){
              s4 += " first, the construction site after " + ob.time + " blocks,"
          }else if(ob.objective==="SAFETY"){
              s4 += " first, the construction site with travel time " + ob.safety + ","
          }
        }else if(index===1){
          if(ob.objective==="TIME"){
              s4 += " second, the construction site after " + ob.time + " blocks,"
          }else if(ob.objective==="SAFETY"){
              s4 += " second, the construction site with travel time " + ob.safety + ","
          }
        }else if(index===2){
          if(ob.objective==="TIME"){
              s4 += " third, the construction site after " + ob.time + " blocks,"
          }else if(ob.objective==="SAFETY"){
              s4 += " third, the construction site with travel time " + ob.safety + ","
          }
        }

      }else if(ob.loc===school){
        if(index===0){
          if(ob.objective==="TIME"){
              s4 += " first, the school after " + ob.time + " blocks"
          }else if(ob.objective==="SAFETY"){
              s4 += " first, the school with with travel time = " + ob.safety
          }
        }else if(index===1){
          if(ob.objective==="TIME"){
              s4 += " second, the school after " + ob.time + " blocks"
          }else if(ob.objective==="SAFETY"){
              s4 += " second, the school with with travel time = " + ob.safety
          }
        }else if(index===2){
          if(ob.objective==="TIME"){
              s4 += " third, the school with after " + ob.time + " blocks"
          }else if(ob.objective==="SAFETY"){
              s4 += " third, the school with with travel time = " + ob.safety
          }
        }

      }
      index++
    }
  }else{
    s4 = " You have passed all intermediate stops: grocery store, construction site and the school."
  }

  return [s1, s2, s3, s4]
}

//deterministic environment explanation
export function explainAgentPlanAtInterruption(profile, time, safety, openneighbors, agchoice, currentpos, breakdown, grocery, construction, school){
  let label = "", str = "", s2 = "", s4 = ""

  for(let i=0; i<openneighbors.length; i++){
    if(openneighbors[i]===agchoice){
      break
    }
  }

  label = getDirection(currentpos, agchoice)

  if(profile==="TIME"){
    str = "the number of blocks travelled"
  }else if(profile==="SAFETY"){
    str = "the time travelled"
  }

  if(profile==="TIME"){
    s2 = "The number of blocks to reach the hospital will be " + time
  }
  if(profile==="SAFETY"){
    s2 = "The total travel time to reach the hospital will be " + safety
  }


  let s1 = "I suggested direction "+ label + " because it is the next direction to take on the best path I could find that minimizes " + str

  if(breakdown.length>0){
    s4 = " On this path, you would have reached, "
    breakdown.sort( compare );
    let index = 0
    for (let ob of breakdown) {
      if(ob.loc===grocery){
        if(index===0){
          if(ob.objective==="TIME"){
              s4 += "first, the grocery store after " + ob.time + " blocks,"
          }else if(ob.objective==="SAFETY"){
              s4 += "first, the grocery store with travel time = " + ob.safety + ","
          }
        }else if(index===1){
          if(ob.objective==="TIME"){
              s4 += "second, the grocery store after " + ob.time + " blocks,"
          }else if(ob.objective==="SAFETY"){
              s4 += "second, the grocery store with travel time = " + ob.safety + ","
          }
        }else if(index===2){
          if(ob.objective==="TIME"){
              s4 += "third, the grocery store after = " + ob.time + " blocks,"
          }else if(ob.objective==="SAFETY"){
              s4 += "third, the grocery store with travel time = " + ob.safety + ","
          }
        }
      }else if(ob.loc===construction){
        if(index===0){
          if(ob.objective==="TIME"){
              s4 += " first, the construction site after " + ob.time + " blocks,"
          }else if(ob.objective==="SAFETY"){
              s4 += " first, the construction site with travel time = " + ob.safety + ","
          }
        }else if(index===1){
          if(ob.objective==="TIME"){
              s4 += " second, the construction site after " + ob.time + " blocks,"
          }else if(ob.objective==="SAFETY"){
              s4 += " second, the construction site with travel time = " + ob.safety + ","
          }
        }else if(index===2){
          if(ob.objective==="TIME"){
              s4 += " third, the construction site after " + ob.time + " blocks,"
          }else if(ob.objective==="SAFETY"){
              s4 += " third, the construction site with travel time = " + ob.safety + ","
          }
        }

      }else if(ob.loc===school){
        if(index===0){
          if(ob.objective==="TIME"){
              s4 += " first, the school after " + ob.time + " blocks,"
          }else if(ob.objective==="SAFETY"){
              s4 += " first, the school with travel time = " + ob.safety
          }
        }else if(index===1){
          if(ob.objective==="TIME"){
              s4 += " second, the school after " + ob.time + " blocks,"
          }else if(ob.objective==="SAFETY"){
              s4 += " second, the school with travel time = " + ob.safety
          }
        }else if(index===2){
          if(ob.objective==="TIME"){
              s4 += " third, the school after " + ob.time + " blocks,"
          }else if(ob.objective==="SAFETY"){
              s4 += " third, the school with travel time = " + ob.safety
          }
        }

      }
      index++
    }
  }else{
    s4 = " You have passed all intermediate stops: grocery store, construction site and the school."
  }

  return [s1, s4, s2, ""] //empty string is needed because The PlannerMessage card needs 4 elements
}

export function costBreakdown(profile, timecostmap, safetycostmap, points, groceryloc, constructionloc, schoolloc){
  let result = []
  let safety = 0, time = 0
  for(let i=0; i<points.length; i++){
    if(profile==="TIME"){
      let ob = null
      time += timecostmap[points[i]]

      if(points[i]===groceryloc){
        ob = {"loc":groceryloc, "index":i, "objective":profile, "time":time}
        result.push(ob)
      }
      if(points[i]===constructionloc){
        ob = {"loc":constructionloc, "index":i, "objective":profile, "time":time}
        result.push(ob)
      }
      if(points[i]===schoolloc){
        ob = {"loc":schoolloc, "index":i, "objective":profile, "time":time}
        result.push(ob)
      }
    }

    if(profile==="SAFETY"){
      let ob = null
      safety += safetycostmap[points[i]]

      if(points[i]===groceryloc){
        ob = {"loc":groceryloc, "index":i, "objective":profile, "safety":safety}
        result.push(ob)
      }
      if(points[i]===constructionloc){
        ob = {"loc":constructionloc, "index":i, "objective":profile, "safety":safety}
        result.push(ob)
      }
      if(points[i]===schoolloc){
        ob = {"loc":schoolloc, "index":i, "objective":profile, "safety":safety}
        result.push(ob)
      }
    }
  }
  return result
}

function compare( a, b ) {
  if ( a.index < b.index ){
    return -1;
  }
  if ( a.index > b.index ){
    return 1;
  }
  return 0;
}
