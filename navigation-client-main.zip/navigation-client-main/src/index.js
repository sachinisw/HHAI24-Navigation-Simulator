import '!style-loader!css-loader!bootstrap/dist/css/bootstrap.css';
import React from 'react';
import ReactDOM from 'react-dom';
import MainApp from './MainApp';
import './index.css';

const render = Component => {
  ReactDOM.render(
    <MainApp />,
    document.getElementById('main')
  )
}

//render(Board)
render(MainApp)
if (module.hot) {
  module.hot.accept('./MainApp', () => { render(MainApp) })
}
