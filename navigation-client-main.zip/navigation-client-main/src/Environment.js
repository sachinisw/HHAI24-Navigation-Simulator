import React from 'react'
import Blob from './Blob'
import {Alert, Button, Col, Row, Container, Spinner} from 'react-bootstrap'
import Square from './Square'
import TimeCost from './TimeCost'
import SafetyCost from './SafetyCost'
import ActionButtonBar from './ActionButtonBar'
import PerformancePanel from './PerformancePanel'
import EnvironmentHeader from './EnvironmentHeader'
import IncidentAlert from './IncidentAlert'
import IncidentRecovery from './IncidentRecovery'
import InterimQuestionnaire from './InterimQuestionnaire'
import PosthocTrustQuestionnaire from './PosthocTrustQuestionnaire'
import InterruptAlert from './InterruptAlert'
import InterruptRecovery from './InterruptRecovery'
import AgentProfile from './AgentProfile'
import TaskEndNotification from './TaskEndNotification'
import SessionEndNotification from './SessionEndNotification'
import PlannerMessage from './PlannerMessage'
import RedZoneAlert from './RedZoneAlert'
import TimeOverrun from './TimeOverrun'
import FuelOverrun from './FuelOverrun'
import ConditionWorsenAlert from './ConditionWorsenAlert'
import MilestoneReplan from './MilestoneReplan'
import {getDirection, validatedNeighbors, explainTheBestPlan, explainAgentPlanAtInterruption,
  costBreakdown, getLandingPosition, probabilisticLandingPosition,
  explainTheBestDirection, explainTheBestDirectionAfterInterrupt} from './Functions'


class Environment extends React.Component{

  constructor(props){
		super(props);
		this.state={
      cause_milestone: "MILESTONE_REACHED",
      cause_accident: "ACCIDENT",
      cause_interrupt: "INTERRUPT",
      session_end: "END",
      label_grocery: "GROCERY",
      label_construction: "CONSTRUCTION",
      label_school: "SCHOOL",
      label_hospital: "HOSPITAL",
      square_style:"Square",
      square_unsafe_style:" SquareUnsafe", //need the space in front
      square_construction_style:"Square icon Construction",
      square_grocery_style: "Square icon Grocery",
      square_school_style: "Square icon School",
      square_hospital_style: "Square icon Hospital",
      square_house_style: "Square icon House",
      square_blocked_style: " blockedSquare",
      square_blocked_house_style: " blockedSquareHouse",
      waiting_message:"Please wait. This may take about a minute.",
      task_safe: "SAFETY",
      task_speed: "TIME",
      currentTaskID:"",
      remainingTaskIDs:"",
      userid:"",
      actionButtonsDisabled:"",
      events:[],
			moves:[],
      times:[],
      safety:[],
      blocked:[],
      replanChoices:[],
			squares:[], //1D array of square id
      history:[], //already visited cell numbers
      milestones_completed:[],
      waitForServer:true,
      enableActions:false,
			start: true,
      loading:false,
      milestoneReached:false,
      incidentHappened:false,
      interruptHappened:false,
      showConditionTimer:true,
      showTimeOverrun:true,
      showFuelOverrun:true,
      legComplete:false,
      next:false,
			errorMsg:null,
      interruptAlert:null,
      interruptRecovery:null,
      incidentAlert:null,
      incidentRecovery:null,
      plannerMessage:null,
      timeOverrun:null,
      fuelOverrun:null,
      interim:null,
      posthoc:null,
      profile:null,
      taskEnd:null,
      planError:null,
      conditionAlert:null,
      milestoneReplan:null,
      startpos:0,
      endpos: 0,
      stop_construction: 0,
      stop_grocery: 0,
      stop_school: 0,
      blobat:0, //grid cell number
      blobdestination:0, //grid cell number
      blobatPrev:0,//grid cell number
      remainingDistance:0,
      remainingSafety:0,
      currentPlanCost:0,
      totalIncidents:1, //hardcoded total number of accidents on the board
      totalConditionChecks:1, //hardcoded total number of patient condition alerts
      incidentCount:0,
      conditionCount:0,
      unsafescore:3, //hardcoded safety score. used to apply colors to unsafe blocks
      distanceBudget:28, //uninterrupted blocks optimal for cc=25, dd=23 //TODO::nondet agent cc=55 dd=30
      timeBudget: 49, //uninterrupted safety optimal for cc=33, dd=49 //TODO: nondet agent cc=50 dd=50
      conditionTimer:25, // show condition worsen alert when remaining time. TODO:change for nondet agent
      accidentPoint:27, //trigger accident after travelling 15 blocks TODO:change for nondet agent
      rows:0, //rows on the board
      cols:0, //cols on the board
      timeOverrunCount:0,
      interruptCount:0,
      check:10004,
      grocerycheck:9744,
      schoolcheck:9744,
      constructioncheck:9744,
      max_value:50 //blocked cell cost
		}
		this.handleStartButtonClick = this.handleStartButtonClick.bind(this);
    this.readGame = this.readGame.bind(this);
    this.drawEnvironment = this.drawEnvironment.bind(this);
    this.handleActionButtonClick = this.handleActionButtonClick.bind(this);
    this.generateLandingSquareFromPlan = this.generateLandingSquareFromPlan.bind(this);
    this.generateeLeavingSquare = this.generateLeavingSquare.bind(this);
    this.generateLandingSquareFromChoice = this.generateLandingSquareFromChoice.bind(this);
    this.handleIncidentOK = this.handleIncidentOK.bind(this);
    this.handleIncident = this.handleIncident.bind(this);
    this.generateBlockedArea = this.generateBlockedArea.bind(this);
    this.generateLabeledSquares = this.generateLabeledSquares.bind(this);
    this.sendDirectionChoiceToServer = this.sendDirectionChoiceToServer.bind(this);
    this.handleDirectionChoiceResponse = this.handleDirectionChoiceResponse.bind(this);
    this.updateEnvironmentAfterAccident = this.updateEnvironmentAfterAccident.bind(this);
    this.updateEnvironmentOnChoiceAfterInterrupt = this.updateEnvironmentOnChoiceAfterInterrupt.bind(this);
    this.removeDirectionLabelsFromNeighbors = this.removeDirectionLabelsFromNeighbors.bind(this);
    this.handleIntermSurveyResponse = this.handleIntermSurveyResponse.bind(this);
    this.handlePosthocSurveyResponse = this.handlePosthocSurveyResponse.bind(this);
    this.handleInterrupt = this.handleInterrupt.bind(this);
    this.handleInterruptOK = this.handleInterruptOK.bind(this);
    this.getNextTask = this.getNextTask.bind(this);
    this.generateExplanationTextFromPlannerResponse = this.generateExplanationTextFromPlannerResponse.bind(this);
    this.generateExplanationTextForInterrupt = this.generateExplanationTextForInterrupt.bind(this);
    this.closeSessionEndDialog = this.closeSessionEndDialog.bind(this);
    this.onTimeOverrun = this.onTimeOverrun.bind(this);
    this.onConditionWorsen = this.onConditionWorsen.bind(this);
    this.onFuelOverrun = this.onFuelOverrun.bind(this);
    this.sendNextMilestoneToServer = this.sendNextMilestoneToServer.bind(this);
    this.handleNextMilestoneResponse = this.handleNextMilestoneResponse.bind(this);
	};

  async fetch(input) {
        let id = input.split("#")[0]; //conveys type of request. start game? save result?
        let data = input.split("#")[1]; //gives the parameters needed for the server to produce an output for the request
        let clientRequest = {   // Create client->server request message. IMPORTANT: This object must match the structure of whatever object the server is reading into
            parameters: data,
            type: id
        };
        try {
            let serverUrl = window.location.href.substring(0, window.location.href.length - 6) + ":9999/api";
            //let serverUrl = "https://collabplan-9999.nms.kcl.ac.uk/api";
            let jsonReturned = await fetch(serverUrl,
                {
                    method: "POST",
                    body: JSON.stringify(clientRequest)
                });
            let ret = await jsonReturned.json();// Wait for server to return and convert it to json.
            let retJSON = JSON.parse(ret); //parse ret to JSON object.
            let responseType = retJSON.type;//behavior changes based on the value here
            console.log(retJSON);
            if(responseType==="START-RESPONSE"){
				      this.readGame(retJSON.game, retJSON.uuid, retJSON.taskId, retJSON.taskOrder, retJSON.solution, retJSON.solutionCost, retJSON.init, retJSON.goal)
              this.setState({
   					    loading: false
   			     });
            }else if(responseType==="CHOICE-RESPONSE"){
              this.handleDirectionChoiceResponse(retJSON.game, retJSON.uuid, retJSON.taskId, retJSON.solution, retJSON.at, retJSON.solutionCost, retJSON.init, retJSON.goal)
            }else if(responseType==="NEXT-MILESTONE-RESPONSE"){
              this.handleNextMilestoneResponse(retJSON.game, retJSON.uuid, retJSON.taskId, retJSON.solution, retJSON.at, retJSON.solutionCost, retJSON.init, retJSON.goal)
            }else if(responseType==="INTERIM-RESPONSE-GROCERY" || responseType==="INTERIM-RESPONSE-SCHOOL" || responseType==="INTERIM-RESPONSE-CONSTRUCTION"){
              this.handleIntermSurveyResponse()
            }else if(responseType==="POSTHOC-RESPONSE-TIME_SAFETY" || responseType==="POSTHOC-RESPONSE-TIME" || responseType==="POSTHOC-RESPONSE-SAFETY"){
              this.handlePosthocSurveyResponse()
            }else if(responseType==="FRONTENDEVENTLOG-RESPONSE"){
               // nothing to do here.
            }else if(responseType==="ERROR-RESPONSE"){
              let planerr =
           			<Alert variant="danger">
           				<h4 className="alert-heading">Error</h4>
                    There was an error retrieving the server response. Refresh the page and start again or contact administrator: sachini.weerawardhana@kcl.ac.uk.
           			</Alert>
              this.setState({
   					    loading: false,
                start: false,
                planError: planerr
   			     });
           }
         } catch (e) {
           let err =
        			<Alert variant="danger">
        				<h4 className="alert-heading">Error</h4>
                Could not connect to the remote server. <p>Contact administrator: sachini.weerawardhana@kcl.ac.uk </p>
        			</Alert>
			     this.setState({
					    errorMsg: err
			     });
        }
  }

  async readGame(game, uuid, taskid, taskorder, points, cost, init, goal){
    let r = game["rows"]
    let c = game["columns"]
    let st = game["home"]
    let ed = game["hospital"]
    let stop1 = game["construction"]
    let stop2 = game["school"]
    let stop3 = game["grocery"]
    let tasks = taskorder.split("@")
    let next = "";
    for(let i=0; i<tasks.length; i++){
      next += tasks[i]+"@"
    }
    console.log(points);
    await this.setState({
       currentTaskID:taskid,
       blobdestination:goal,
       remainingTaskIDs:next.substring(0,next.length-1),
       userid:uuid,
       rows:r,
       cols:c,
       startpos:st,
       blobat:init,
       endpos:ed,
       stop_construction: stop1, //construction
       stop_school: stop2, //school
       stop_grocery: stop3,  //grocery
       currentPlanCost: cost,
       remainingDistance: this.state.distanceBudget, //start with the allocated budgets for distance and time and count down
       remainingSafety: this.state.timeBudget,
       times: game["timeCosts"]["times"].slice(), //game object has the property timeCosts. timeCosts value is object. this object has a property times containing an array of 100 elements
       safety: game["safetyCosts"]["safeties"].slice(), //same as getting the time costs
       moves: points.slice(), //if deterministic, then this is the position sequence. if nondeterministic then best direction to take in each state. comes as array. not an object
     }, ()=> {this.drawEnvironment()});
  }


  handleStartButtonClick() {
    this.setState(prevState => ({
      start: !prevState.start,
      loading: true
    }));
    if(this.state.start && !this.state.next) {
      this.fetch("START-GAME#"+this.props.prolific)
    }else if(this.state.start && this.state.next){
      let obj = {prolific: this.props.prolific, order:this.state.remainingTaskIDs};
      this.fetch("NEXT-GAME#"+JSON.stringify(obj))
    }
  }


  drawEnvironment(){
    let localsquares = []
    let localevents = this.state.events.slice()
    let numcells = this.state.rows*this.state.cols
    for (let i = 0; i < numcells; i++) {
        if(i != this.state.startpos || i != this.state.endpos ){ //apply style to all empty cells
          let timecost = <TimeCost value={this.state.times[i]} />
          let sqstyle = ""

          if (this.state.safety[i] == this.state.unsafescore ){  //dont show safety score in the cell. instead show them as red
            sqstyle = this.state.square_style + this.state.square_unsafe_style
          }else {
            sqstyle = this.state.square_style
          }

          let empty=<Square key={i} id={i} blob={null} time={timecost} style={sqstyle}/>
          localsquares[i]=empty
        }
        if(i == this.state.startpos){ //apply style to start cell
          let timecost = <TimeCost value={this.state.times[i]} />
          let start = null
          start=<Square key={i} id={i} blob={<Blob agent={this.state.currentTaskID}/>} time={timecost} style={this.state.square_house_style}/>
          localsquares[i]=start
        }
        if(i == this.state.stop_construction){ //apply style to construction cell
          let timecost = <TimeCost value={this.state.times[i]} />
          let sqstyle = ""

          if (this.state.safety[i]==this.state.unsafescore){
            sqstyle = this.state.square_construction_style + this.state.square_unsafe_style
          }else{
            sqstyle = this.state.square_construction_style
          }

          let construction=<Square key={i} id={i} blob={null} time={timecost} style={sqstyle}/>
          localsquares[i]=construction
        }
        if(i == this.state.stop_school){ //apply style to school cell
          let timecost = <TimeCost value={this.state.times[i]} />
          let sqstyle = ""

          if (this.state.safety[i]==this.state.unsafescore ){
            sqstyle = this.state.square_school_style + this.state.square_unsafe_style
          }else{
            sqstyle = this.state.square_school_style
          }

          let school=<Square key={i} id={i} blob={null} time={timecost} style={sqstyle}/>
          localsquares[i]=school
        }
        if(i == this.state.stop_grocery){ //apply style to grocery cell
          let timecost = <TimeCost value={this.state.times[i]} />
          let sqstyle = ""

          if (this.state.safety[i]==this.state.unsafescore ){
            sqstyle = this.state.square_grocery_style + this.state.square_unsafe_style
          }else{
            sqstyle = this.state.square_grocery_style
          }

          let grocery=<Square key={i} id={i} blob={null} time={timecost} style={sqstyle}/>
          localsquares[i]=grocery
        }
        if(i == this.state.endpos){ //apply style to hospital
          let timecost = <TimeCost value={this.state.times[i]} />
          let hospital = null

          hospital = <Square key={i} id={i} blob={null} time={timecost} style={this.state.square_hospital_style}/>

          localsquares[i]=hospital
        }
    }

    //create agent profile info panel
    let agentProfile = <AgentProfile profile={this.state.currentTaskID} />

    //create plan explanation info panel.
    let direction = this.state.moves[this.state.blobat]
    let retOb = this.generateExplanationTextFromPlannerResponse(this.state.currentTaskID, this.state.blobdestination, direction)

    //create event text
    localevents.push(retOb['evtext'])

    this.setState({
        squares:localsquares,
        events:localevents,
        profile:agentProfile,
        plannerMessage:retOb['component'],
        enableActions: true
        //showPlan: false
    });
  }


  handleActionButtonClick(event){
    let inaccessible = this.state.blocked.slice()
    let localsquares = this.state.squares.slice()
    let localevents = this.state.events.slice()
    let moveHistory = this.state.history.slice()
    let milestonescompleted = this.state.milestones_completed.slice()
    let activateIncident = false, incidenthappened = false, interrupthappened = false, timeOverrunAlert = null, fuelOverrunAlert = null
    let incidentcounter = this.state.incidentCount
    let conditioncounter = this.state.conditionCount
    let interruptcounter = this.state.interruptCount
    let plannermsg = this.state.plannerMessage
    let incident = null, interrupt = null
    let quiz = null
    let posthoc = null
    let condition = null
    let milestonereplan = null
    let distance = this.state.remainingDistance
    let time = this.state.remainingSafety
    let sc = this.state.schoolcheck, gc = this.state.grocerycheck, cc = this.state.constructioncheck
    let blobcurrent = this.state.blobat
    let milestone = this.state.milestoneReached
    let legcomplete = this.state.legComplete
    let landing = -1

    let to = getLandingPosition(blobcurrent, this.state.moves[blobcurrent])

    if(event.target.id === 'go'){
      //create event text
      let ev_txt1 = "Timestamp " + Date.now() + " Participant " + this.state.userid + " Task " + this.state.currentTaskID
      let ev_txt2 = "Timestamp " + Date.now() + " Accept_agent_suggestion_to_go_to_cell " + to
      localevents.push(ev_txt1)
      localevents.push(ev_txt2)

      //probabilistically decide what move to make.
      landing = probabilisticLandingPosition(blobcurrent, this.state.moves[blobcurrent], inaccessible)
      console.log("blob at=",blobcurrent, " SxA suggestion=", to, " probabilistic landing--->", landing);
      //update square object array
      let newsquare = this.generateLandingSquareFromPlan(landing)
      let oldsquare = this.generateLeavingSquare(blobcurrent)
      localsquares[blobcurrent]=oldsquare
      localsquares[landing]= newsquare

      distance -= this.state.times[landing]
      time -= this.state.safety[landing]

      if(time < this.state.conditionTimer && conditioncounter < this.state.totalConditionChecks){ //trigger an patient condition check remaining time budget is lower than the conditionTimer. if blob at a landmark, wait until it comes out of it
        if(blobcurrent!=this.state.stop_construction && blobcurrent!=this.state.stop_school && blobcurrent!=this.state.stop_grocery) {
            condition = <ConditionWorsenAlert showCondition={this.state.showConditionTimer} onCondition={this.onConditionWorsen} />
            conditioncounter++

            let ev_txt3 = "Timestamp " + Date.now() + " Generated_condition_worsened_alert " + " time_remaining " + time + " distance_remaining " + distance
            localevents.push(ev_txt3)
          }

      }

      if(time <=0 && this.state.timeOverrunCount==0){
        timeOverrunAlert = <TimeOverrun showTime={this.state.showTimeOverrun} onShowTime={this.onTimeOverrun} />

        let ev_txt4 = "Timestamp " + Date.now() + " Generated_time_budget_overrun_alert " + " time_remaining " + time + " distance_remaining " + distance
        localevents.push(ev_txt4)
      }

      if(distance == 0 ){
        fuelOverrunAlert = <FuelOverrun showFuel={this.state.showFuelOverrun} onFuel={this.onFuelOverrun} />

        let ev_txt5 = "Timestamp " + Date.now() + " Generated_distance_budget_overrun_alert " + " time_remaining " + time + " distance_remaining " + distance
        localevents.push(ev_txt5)
      }

      if(distance < (this.state.accidentPoint) && incidentcounter < this.state.totalIncidents){ //trigger an accident when number of blocks remaining is lower than the accident point. if blob at a landmark, wait until it comes out of it
        if(blobcurrent!=this.state.stop_construction &&
          blobcurrent!=this.state.stop_school &&
          blobcurrent!=this.state.stop_grocery) {
              activateIncident = true
              incidentcounter++
            }
       }

      if(landing==this.state.stop_school && sc!=this.state.check){ //at school. add check to progress
          sc=this.state.check
          milestone = true
          legcomplete = true
          quiz = <InterimQuestionnaire uid={this.state.userid} taskid={this.state.currentTaskID} quiz={this.state.label_school} unmount={this.handleIntermSurveyResponse} interrupts={this.state.interruptCount} />

          let ev_txt8 = "Timestamp " + Date.now() + " reached_school " + " time_remaining " + time + " distance_remaining " + distance
          localevents.push(ev_txt8)

          milestonescompleted.push(landing)

      }
      if(landing==this.state.stop_grocery && gc!=this.state.check){ //at grocery. add check to progress
          gc=this.state.check
          milestone = true
          legcomplete = true
          quiz = <InterimQuestionnaire uid={this.state.userid} taskid={this.state.currentTaskID} quiz={this.state.label_grocery} unmount={this.handleIntermSurveyResponse} interrupts={this.state.interruptCount} />

          let ev_txt9 = "Timestamp " + Date.now() + " reached_grocery " + " time_remaining " + time + " distance_remaining " + distance
          localevents.push(ev_txt9)

          milestonescompleted.push(landing)
      }
      if(landing==this.state.stop_construction && cc!=this.state.check){ //at construction. add check to progress
          cc=this.state.check
          milestone = true
          legcomplete = true
          quiz = <InterimQuestionnaire uid={this.state.userid} taskid={this.state.currentTaskID} quiz={this.state.label_construction} unmount={this.handleIntermSurveyResponse} interrupts={this.state.interruptCount} />

          let ev_txt10 = "Timestamp " + Date.now() + " reached_construction " + " time_remaining " + time + " distance_remaining " + distance
          localevents.push(ev_txt10)

          milestonescompleted.push(landing)
      }
      if(landing==this.state.endpos){ //at hospital or ran out of fuel. end game. show Posthoc Questionnaire.
          posthoc = <PosthocTrustQuestionnaire uid={this.state.userid} taskid={this.state.currentTaskID}
          unmount={this.handlePosthocSurveyResponse}/>

          let ev_txt11 = "Timestamp " + Date.now() + " reached_hospital " + " time_remaining " + time + " distance_remaining " + distance
          localevents.push(ev_txt11)

          milestonescompleted.push(landing)
      }

      moveHistory.push(landing)

    }else if (event.target.id ==='stop'){   //handle user initiated interruptions here //show the direction options + explanations. replan
      interrupthappened = true
      //showplaninterrupt = true
      interrupt = <InterruptAlert show={interrupthappened} onInterruptOK={this.handleInterruptOK}/>

      let ev_txt = "Timestamp " + Date.now() + " Generated_interrupt " + " time_remaining " + time + " distance_remaining " + distance
      localevents.push(ev_txt)
      interruptcounter++

      landing = this.state.blobat
    }

    if( activateIncident ){
      incidenthappened = true
      incident = <IncidentAlert show={incidenthappened} onIncidentOK={this.handleIncidentOK}/>

      let ev_txt6 = "Timestamp " + Date.now() + " Generated_accident " + " time_remaining " + time + " distance_remaining " + distance
      localevents.push(ev_txt6)

    }

    ///////////////console.log("milestonescompleted", milestonescompleted)
    if( milestone && !activateIncident){
      let list = [this.state.stop_grocery, this.state.stop_school, this.state.stop_construction, this.state.endpos]
      let nextms = -1
      let ms = ""
    ///////////////  console.log("list",list)
      for(let i=0; i<list.length; i++){ //find the first unvisited milestone in list
        let id = milestonescompleted.indexOf(list[i])
        if(id == -1){
            nextms = i
            break
        }
      }

      if(list[nextms] == this.state.stop_grocery){
        ms = this.state.label_grocery
      }else if(list[nextms] == this.state.stop_school){
        ms = this.state.label_school
      }else if (list[nextms] == this.state.stop_construction){
        ms = this.state.label_construction
      }else if (list[nextms] == this.state.endpos){
        ms = this.state.label_hospital
      }

    ///////////////  console.log("next milestone to visit=", ms)
      milestonereplan = <MilestoneReplan blobat={this.state.blobat} next={ms} handleDirectionChoice={this.sendNextMilestoneToServer}/>

      let ev_txt7 = "Timestamp " + Date.now() + " Milestone_reached_replanning " + " time_remaining " + time + " distance_remaining " + distance
      localevents.push(ev_txt7)

    }

    if(plannermsg != null){
      plannermsg = null
    }

    console.log("history",moveHistory);

    this.setState({
        squares:localsquares,
        history:moveHistory,
        events:localevents,
        blobat:landing,
        remainingDistance:distance,
        remainingSafety:time,
        grocerycheck:gc,
        constructioncheck:cc,
        schoolcheck:sc,
        incidentCount:incidentcounter,
        conditionCount:conditioncounter,
        interruptCount:interruptcounter,
        incidentAlert: incident,
        interruptAlert:interrupt,
        interim: quiz,
        plannerMessage: plannermsg,
        posthoc: posthoc,
        incidentHappened: incidenthappened,
        interruptHappened: interrupthappened,
        conditionAlert: condition,
        timeOverrun: timeOverrunAlert,
        fuelOverrun: fuelOverrunAlert,
        milestoneReached: milestone,
        milestoneReplan: milestonereplan,
        milestones_completed:milestonescompleted,
        legComplete:legcomplete
      });
  }

  handleIncidentOK(){
    this.setState({
        incidentHappened: false,
        incidentAlert: null,
        plannerMessage:null,
        actionButtonsDisabled: "disabled"
      }, ()=>{this.handleIncident()});
  }

  handleInterruptOK(){
    this.setState({
        interruptAlert: null,
        actionButtonsDisabled: "disabled"
      }, ()=>{this.handleInterrupt()});
  }

  handleInterrupt(){
    //explain why the direction choice was made originally //show options
      let taskId = this.state.currentTaskID
      let interruptsquare = this.state.blobat
      let localsquares=this.state.squares.slice()
      let safeties = this.state.safety.slice()
      let timevals = this.state.times.slice()
      let inaccessible = this.state.blocked.slice()
      let points = this.state.moves.slice()
      let localevents = this.state.events.slice()
      let timecost = 0
      let safetyhit = 0

      ///////////////console.log("handling interrupt");
      let agnextmove =  getLandingPosition(interruptsquare, this.state.moves[interruptsquare]) //this is the suggested landing position

      let neighbors = validatedNeighbors(interruptsquare, 4) //4 available directions to go after interruption
      let freeblobneighbors = []
      for(let i=0; i<neighbors.length; i++){
        if(!inaccessible.includes(neighbors[i])){
            freeblobneighbors.push(neighbors[i])
        }
      }
      ///////////////console.log("neighbors",neighbors);
      let freetogo = this.generateLabeledSquares(safeties, timevals, freeblobneighbors, interruptsquare)
      let keys = []
      for(let i=0; i<freetogo.length; i++){
        let labelob = freetogo[i]
        localsquares[labelob["surrounding_cell_id"]] = labelob["square"]
        keys[i] = labelob["surrounding_cell_id"]
      }
      ///////////////console.log("interrupted", interruptsquare, "freetogo",freetogo);

      //generate explnation text
      let retOb = this.generateExplanationTextForInterrupt(taskId, milestone, direction)
      let recovery = <InterruptRecovery buttons={freetogo.length} keys={keys} at={interruptsquare} handleDirectionChoice={this.updateEnvironmentOnChoiceAfterInterrupt}/>

      let ev_txt = "Timestamp " + Date.now() + " Interrupted_at " + interruptsquare + " Agent_cell_at_interrupt " + agnextmove
      localevents.push(ev_txt)
      localevents.push(retOb['evtext'])

      this.setState({
          events: localevents,
          squares:localsquares,
          replanChoices:freeblobneighbors,
          blobat:interruptsquare,
          interruptRecovery: recovery,
          plannerMessage: retOb['component']
        });
  }

  handleIncident(){
    //An accident occured.
    //change style to block where blobby is Now and a neighbor left or right. push blob back in the moves until the first free cell is found. no need to color things. too complicated.
    //if this incident happens after a choice taken at an interrupt, then we would have received a fresh plan from the server. This means currentMove = 1 blobAt = interruptposition. cant use plan to go back. need to remember where it moved from at interrupt
    //for the forced go-back do not change distance, time
      let accidentsquare = this.state.blobat
      let localsquares=this.state.squares.slice()
      let safeties = this.state.safety.slice()
      let timevals = this.state.times.slice()
      let inaccessible = this.state.blocked.slice()
      let blobpushed = 0
      let tabu = [this.state.stop_construction, this.state.stop_grocery, this.state.stop_school, this.state.endpos]


      let blockedsquares = this.generateBlockedArea(accidentsquare) //there is a list of 2 here. last one is always the accident square
      localsquares[parseInt(accidentsquare)]=blockedsquares[1].ob //replace the square where the accident happened with a new blocked style square
      localsquares[blockedsquares[0].key]=blockedsquares[0].ob //replace accident's neighbor with the same style
      inaccessible.push(parseInt(this.state.blobat))
      inaccessible.push(blockedsquares[0].key)

      //update costmaps to 100 for all inaccessible cells
      for(let i=0; i<inaccessible.length; i++){
        safeties[inaccessible[i]] = this.state.max_value
        timevals[inaccessible[i]] = this.state.max_value
      }

      //get all 8 cells around the accident cell. move the blob to the first unblocked cell, that is also not a landmark
      let eight_neighbors = validatedNeighbors(accidentsquare,8)
      for(let i=0; i<eight_neighbors.length; i++){
        if(!inaccessible.includes(eight_neighbors[i]) && !tabu.includes(eight_neighbors[i])){
          blobpushed = eight_neighbors[i]
          break
        }
      }
      let newsquare = this.generateLandingSquareFromPlan(blobpushed)
      localsquares[blobpushed]= newsquare

      let recovery = <IncidentRecovery blobat={blobpushed} handleDirectionChoice={this.updateEnvironmentAfterAccident} wait={this.state.waitForServer}/>
      this.setState({
          squares:localsquares,
          safety:safeties,
          times:timevals,
          blobat:blobpushed,
          blocked:inaccessible,
          incidentRecovery: recovery
      });
  }

  sendDirectionChoiceToServer(choice, cause){
    let timestamp = Date.now() //create unique problem pddl using system time
    let visited_grocery = "", visited_construction = "", visited_school = ""

    if (this.state.grocerycheck===this.state.check) {
      visited_grocery = this.state.stop_grocery
    }
    if (this.state.constructioncheck===this.state.check) {
      visited_construction = this.state.stop_construction
    }
    if(this.state.schoolcheck===this.state.check){
      visited_school = this.state.stop_school
    }

    let choiceOb = {"uid":this.state.userid, "timestamp": timestamp, "at":this.state.blobat,
                    "visited":[this.state.startpos,visited_grocery, visited_construction, visited_school],
                      "safety":this.state.safety, "times":this.state.times, "blocked":this.state.blocked, "choice":choice, "task":this.state.currentTaskID, "cause":cause}
    this.fetch("CHOICE#"+JSON.stringify(choiceOb));
  }


  sendNextMilestoneToServer(){
    let timestamp = Date.now() //create unique problem pddl using system time
    let visited_grocery = "", visited_construction = "", visited_school = ""

    if (this.state.grocerycheck===this.state.check) {
      visited_grocery = this.state.stop_grocery
    }
    if (this.state.constructioncheck===this.state.check) {
      visited_construction = this.state.stop_construction
    }
    if(this.state.schoolcheck===this.state.check){
      visited_school = this.state.stop_school
    }

    let nextMs = {"uid":this.state.userid, "timestamp": timestamp, "at":this.state.blobat,
                    "visited":[this.state.startpos,visited_grocery, visited_construction, visited_school],
                      "safety":this.state.safety, "times":this.state.times, "blocked":this.state.blocked, "choice":this.state.blobat, "task":this.state.currentTaskID, "cause":this.state.cause_milestone}
    this.fetch("NEXT-MILESTONE#"+JSON.stringify(nextMs));
  }


  handleDirectionChoiceResponse(game, uuid, taskid, points, at, cost, init, goal){
    let time = this.state.remainingDistance, safety = this.state.safetyscore
    let timeCostInResponse = game["timeCosts"]["times"]
    let safetyCostInResponse = game["safetyCosts"]["safeties"]

    // let to = getLandingPosition(at, points[at])
    // let direction = getDirection(at, to)
    let direction = this.state.moves[this.state.blobat]
    let retOb = this.generateExplanationTextFromPlannerResponse(this.state.currentTaskID, goal, direction)

    this.setState({
        userid:uuid,
        blobat:at,
        blobdestination:goal,
        actionButtonsDisabled:"",
        incidentRecovery:null,
        interruptRecovery:null,
        plannerMessage: retOb['component'],
        waitForServer:false,
        times: timeCostInResponse.slice(),
        safety: safetyCostInResponse.slice(),
        moves: points.slice(),
    });
  }

  handleNextMilestoneResponse(game, uuid, taskid, points, at, cost, init, goal){
    let time = this.state.remainingDistance, safety = this.state.safetyscore
    let timeCostInResponse = game["timeCosts"]["times"]
    let safetyCostInResponse = game["safetyCosts"]["safeties"]

    // let to = getLandingPosition(at, points[at])
    // let direction = getDirection(at, to)
    let direction = this.state.moves[this.state.blobat]
    let retOb = this.generateExplanationTextFromPlannerResponse(this.state.currentTaskID, goal, direction)

    this.setState({
        userid:uuid,
        blobat:at,
        blobdestination:goal,
        actionButtonsDisabled:"",
        incidentRecovery:null,
        interruptRecovery:null,
        milestoneReplan:null,
        milestoneReplan:null,
        plannerMessage: retOb['component'],
        waitForServer:false,
        legComplete:false,
        times: timeCostInResponse.slice(),
        safety: safetyCostInResponse.slice(),
        moves: points.slice(),
    });
  }

  handleIntermSurveyResponse(){
    this.setState({
        interruptCount:0,
        actionButtonsDisabled: "disabled",
        milestoneReached:false,
        interim : null
    });
  }

  handlePosthocSurveyResponse(){
    //if this is the last posthoc survey    //save event log; //activate the demographic survey tab //clear page contents //close dialog
    //if this is not the last posthoc //close dialog
    let next = null
    if(this.state.remainingTaskIDs.split("@")[0]!==this.state.session_end){
      next = <TaskEndNotification show={true} currentTask={this.state.currentTaskID} nextTask={this.state.remainingTaskIDs.split("@")[0]} getNextTask={this.getNextTask}/>

    }else if(this.state.remainingTaskIDs.split("@")[0]===this.state.session_end){
      next = <SessionEndNotification show={true} onDialogClose={this.closeSessionEndDialog}/>
    }

    this.setState({
        posthoc: null,
        profile: null,
        plannerMessage: null,
        incidentAlert: null,
        interruptAlert: null,
        incidentRecovery: null,
        interruptRecovery: null,
        incidentCount: 0,
        conditionCount: 0,
        squares: [],
        moves:[],
        blocked: [],
        replanChoices: [],
        taskEnd: next,
        enableActions: false,
        showFuelOverrun:true,
        showTimeOverrun:true,
        grocerycheck:9744,
        schoolcheck:9744,
        constructioncheck:9744,
        remainingDistance:0,
        remainingSafety:0,
        blobat:0,
        timeOverrunCount:0
      } );
  }

  getNextTask(){
    let localevents = this.state.events.slice()

    let ev_txt = "Timestamp " + Date.now() + " Posthoc_submitted_user " + this.state.userid + " Posthoc_submitted_task " + this.state.currentTaskID
    localevents.push(ev_txt)

    let obj = {prolific: this.state.userid, task:this.state.currentTaskID, log: localevents};
    this.fetch("TASK-EVENT-LOG#"+JSON.stringify(obj))

    this.setState({
      events: [],
      taskEnd: null,
      start: true,
      next: true
    });
  }

  closeSessionEndDialog(){
    let localevents = this.state.events.slice()

    let ev_txt2 = "Timestamp " + Date.now() + " Both_tasks_completed_user " +  this.state.userid
    localevents.push(ev_txt2)

    let obj = {prolific: this.state.userid, task:this.state.currentTaskID, log: localevents};
    this.fetch("TASK-EVENT-LOG#"+JSON.stringify(obj))

    this.setState({
      events: [],
      taskEnd: null,
      start: false,
      next: false
    }, ()=>{this.props.endSession()});
  }

  updateEnvironmentAfterAccident(choice){ //choice for accident is the position to which the blob is pushed
    let localsquares=this.state.squares.slice()
    let localevents=this.state.events.slice()
    let leaving = this.state.blobat
    let goingto = choice

    let newsq = this.generateLandingSquareFromChoice(goingto) //put blob in the blobpushed cell
    localsquares[goingto]=newsq

    let ev_txt1 = "Timestamp " + Date.now() + " Blob_cell_after_accident " + choice
    let ev_txt2 = "Timestamp " + Date.now() + " Finished_accident_move " + " time_remaining " + this.state.timeBudget + " distance_remaining " + this.state.distanceBudget
    localevents.push(ev_txt1)
    localevents.push(ev_txt2)

    this.setState({
      squares:localsquares.slice(),
      events: localevents,
      replanChoices:[],
      blobat:choice,
      blobatPrev:leaving
    }, ()=>{this.sendDirectionChoiceToServer(choice, this.state.cause_accident)});
  }

  updateEnvironmentOnChoiceAfterInterrupt(choice){
    let localsquares = this.state.squares.slice()
    let localevents = this.state.events.slice()
    let safeties = this.state.safety.slice()
    let timevals = this.state.times.slice()
    let moveHistory = this.state.history.slice()
    let oldsq = this.generateLeavingSquare(this.state.blobat) //give an array index
    let choices = this.state.replanChoices
    let distance = this.state.remainingDistance
    let time = this.state.remainingSafety
    let incidentcounter = this.state.incidentCount
    let conditioncounter = this.state.conditionCount
    let legcomplete = this.state.legComplete
    let activateIncident = false, incidenthappened = false
    let incident = null, condition = null, timeOverrunAlert = null, fuelOverrunAlert = null
    let blobatprev = this.state.blobat
    let sc = this.state.schoolcheck, gc = this.state.grocerycheck, cc = this.state.constructioncheck
    let quiz = null, posthoc = null
    let milestonereplan = null
    localsquares[this.state.blobat]=oldsq //remove blob from == blobat
    let milestone = this.state.milestoneReached
    let milestonescompleted = this.state.milestones_completed.slice()
    let unlabled = this.removeDirectionLabelsFromNeighbors(safeties, timevals, choices, choice) //remove direction label style from cells. including blobat cell
    for(let i=0; i<unlabled.length; i++){
      let nolabel = unlabled[i]
      localsquares[nolabel["surrounding_cell_id"]] = nolabel["square"]
    }

    distance -= timevals[choice] //update performance scores from values in times and safety arrays. this.state.moves[] doesn't have updated solution. do
    time -= safeties[choice]

    let ev_txt = "Timestamp " + Date.now() + " Interrupt_user_chosen_cell " + choice
    let ev_txt2 = "Timestamp " + Date.now() + " Interrupt_finished_move " + " time_remaining " + time + " distance_remaining " + distance

    localevents.push(ev_txt)
    localevents.push(ev_txt2)

    if(time < this.state.conditionTimer && conditioncounter < this.state.totalConditionChecks){ //trigger an patient condition check remaining time budget is lower than the conditionTimer. if blob at a landmark, wait until it comes out of it
      if(this.state.blobat!=this.state.stop_construction &&
        this.state.blobat!=this.state.stop_school &&
        this.state.blobat!=this.state.stop_grocery) {
          condition = <ConditionWorsenAlert showCondition={this.state.showConditionTimer} onCondition={this.onConditionWorsen} />
          conditioncounter++

          let ev_txt3 = "Timestamp " + Date.now() + " Interrupt_generated_condition_worsened_alert " + " time_remaining " + time + " distance_remaining " + distance
          localevents.push(ev_txt3)
        }

    }

    if(time <=0 && this.state.timeOverrunCount==0){
      timeOverrunAlert = <TimeOverrun showTime={this.state.showTimeOverrun} onShowTime={this.onTimeOverrun} />

      let ev_txt4 = "Timestamp " + Date.now() + " Interrupt_generated_time_budget_overrun_alert " + " time_remaining " + time + " distance_remaining " + distance
      localevents.push(ev_txt4)
    }

    if(distance == 0 ){
      fuelOverrunAlert = <FuelOverrun showFuel={this.state.showFuelOverrun} onFuel={this.onFuelOverrun} />

      let ev_txt5 = "Timestamp " + Date.now() + " Interrupt_generated_distance_budget_overrun_alert " + " time_remaining " + time + " distance_remaining " + distance
      localevents.push(ev_txt5)
    }

    //when you choose a square after the interrupt, you can go to the landmarks
    if(choice==this.state.stop_school && sc!=this.state.check){ //at school. add check to progress
        sc = this.state.check
        milestone = true
        legcomplete = true
        quiz = <InterimQuestionnaire uid={this.state.userid} taskid={this.state.currentTaskID} quiz={this.state.label_school} unmount={this.handleIntermSurveyResponse} interrupts={this.state.interruptCount}/>

        let ev_txt8 = "Timestamp " + Date.now() + " Interrupt_reached_school " + " time_remaining " + time + " distance_remaining " + distance
        localevents.push(ev_txt8)

        milestonescompleted.push(parseInt(choice))
    }
    if(choice==this.state.stop_grocery && gc!=this.state.check){ //at grocery. add check to progress
        gc=this.state.check
        milestone = true
        legcomplete = true
        quiz = <InterimQuestionnaire uid={this.state.userid} taskid={this.state.currentTaskID} quiz={this.state.label_grocery} unmount={this.handleIntermSurveyResponse} interrupts={this.state.interruptCount}/>

        let ev_txt9 = "Timestamp " + Date.now() + " Interrupt_reached_grocery " + " time_remaining " + time + " distance_remaining " + distance
        localevents.push(ev_txt9)

        milestonescompleted.push(parseInt(choice))
    }
    if(choice==this.state.stop_construction && cc!=this.state.check){ //at construction. add check to progress
        cc=this.state.check
        milestone = true
        legcomplete = true
        quiz = <InterimQuestionnaire uid={this.state.userid} taskid={this.state.currentTaskID} quiz={this.state.label_construction} unmount={this.handleIntermSurveyResponse} interrupts={this.state.interruptCount}/>

        let ev_txt10 = "Timestamp " + Date.now() + " Interrupt_reached_construction " + " time_remaining " + time + " distance_remaining " + distance
        localevents.push(ev_txt10)

        milestonescompleted.push(parseInt(choice))
    }
    if(choice==this.state.endpos){ //at hospital or has run out of fuel. game end. show Posthoc Questionnaire.
        posthoc = <PosthocTrustQuestionnaire uid={this.state.userid} taskid={this.state.currentTaskID} unmount={this.handlePosthocSurveyResponse}/>

        let ev_txt11 = "Timestamp " + Date.now() + " Interrupt_reached_hospital " + " time_remaining " + time + " distance_remaining " + distance
        localevents.push(ev_txt11)
    }

    //choice can make you move to a milestone
    if( milestone ){
      let list = [this.state.stop_grocery, this.state.stop_school, this.state.stop_construction, this.state.endpos]
      let nextms = -1
      let ms = ""
      ///////////////console.log("list",list)
      for(let i=0; i<list.length; i++){ //find the first unvisited milestone in list
        let id = milestonescompleted.indexOf(list[i])
        if(id == -1){
            nextms = i
            break
        }
      }

      if(list[nextms] == this.state.stop_grocery){
        ms = this.state.label_grocery
      }else if(list[nextms] == this.state.stop_school){
        ms = this.state.label_school
      }else if (list[nextms] == this.state.stop_construction){
        ms = this.state.label_construction
      }else if (list[nextms] == this.state.endpos){
        ms = this.state.label_hospital
      }

      ///////////////console.log("updateEnvironmentOnChoiceAfterInterrupt() next milestone to visit=", ms)
      milestonereplan = <MilestoneReplan blobat={this.state.blobat} next={ms} handleDirectionChoice={this.sendNextMilestoneToServer}/>

      let ev_txt7 = "Timestamp " + Date.now() + " Milestone_reached_replanning " + " time_remaining " + time + " distance_remaining " + distance
      localevents.push(ev_txt7)

    }

    moveHistory.push(parseInt(choice)) //add choice to history
    this.setState({
      remainingDistance:distance,
      remainingSafety:time,
      history:moveHistory,
      squares:localsquares,
      milestones_completed:milestonescompleted,
      blobat:choice,
      blobatPrev:blobatprev,
      incidentHappened: incidenthappened,
      incidentAlert: incident,
      incidentCount: incidentcounter,
      conditionCount: conditioncounter,
      grocerycheck:gc,
      constructioncheck:cc,
      schoolcheck:sc,
      interim: quiz,
      posthoc: posthoc,
      conditionAlert: condition,
      timeOverrun: timeOverrunAlert,
      fuelOverrun: fuelOverrunAlert,
      milestoneReplan: milestonereplan,
      legComplete:legcomplete
    }, ()=>{this.sendDirectionChoiceToServer(choice, this.state.cause_interrupt)});
  }

  generateLabeledSquares(safeties, timevals, surrounding, interruptedat){
    let labeledarea = []
    for(let i=0; i<surrounding.length; i++){
      let newsquare = null
      let blob = null
      let sqstyle = ""
      let newcell = surrounding[i]
      let new_timecost = <TimeCost value={timevals[newcell]} />
      let label = getDirection(interruptedat, newcell).split(" ")[1]

      if(this.state.blobat==newcell){
        blob = <Blob agent={this.state.currentTaskID}/>
      }

      if(newcell==this.state.endpos){
        newsquare = <Square key={newcell} id={newcell} blob={blob} time={new_timecost} style={this.state.square_hospital_style} label={label}/>

      }else if(newcell==this.state.startpos){
          newsquare = <Square key={newcell} id={newcell} blob={blob} time={new_timecost} style={this.state.square_house_style} label={label}/>

      }else if(newcell==this.state.stop_construction){ // construction
          if (safeties[newcell]==this.state.unsafescore){
            sqstyle = this.state.square_construction_style + this.state.square_unsafe_style
          }else{
            sqstyle = this.state.square_construction_style
          }
        newsquare = <Square key={newcell} id={newcell} blob={blob} time={new_timecost} style={sqstyle} label={label}/>

      }else if(newcell==this.state.stop_school){ //school
          if (safeties[newcell]==this.state.unsafescore){
            sqstyle = this.state.square_school_style + this.state.square_unsafe_style
          }else{
            sqstyle = this.state.square_school_style
          }
        newsquare = <Square key={newcell} id={newcell} blob={blob} time={new_timecost} style={sqstyle} label={label}/>

      }else if(newcell==this.state.stop_grocery){ //grocery
          if (safeties[newcell]==this.state.unsafescore){
            sqstyle = this.state.square_grocery_style + this.state.square_unsafe_style
          }else{
            sqstyle = this.state.square_grocery_style
          }

        newsquare = <Square key={newcell} id={newcell} blob={blob} time={new_timecost} style={sqstyle} label={label}/>

      }else{ //empty
          if (safeties[newcell]==this.state.unsafescore){
            sqstyle = this.state.square_style + this.state.square_unsafe_style
          }else{
            sqstyle = this.state.square_style
          }

        newsquare = <Square key={newcell} id={newcell} blob={blob} time={new_timecost} style={sqstyle} label={label}/>

      }
      labeledarea.push({"surrounding_cell_id":newcell, "square":newsquare})
    }
    return labeledarea
  }

  removeDirectionLabelsFromNeighbors(safeties, timevals, surrounding, choice){
    let unlabeledarea = []
    for(let i=0; i<surrounding.length; i++){
      let newsquare = null
      let sqstyle = ""
      let newcell = surrounding[i];
      let new_timecost = <TimeCost value={timevals[newcell]} />
      let blob = null
      if(choice==newcell){
        blob = <Blob agent={this.state.currentTaskID}/>
      }

      if(newcell==this.state.endpos){
          newsquare = <Square key={newcell} id={newcell} blob={blob} time={new_timecost} style={this.state.square_hospital_style}/>
      }else if(newcell==this.state.startpos){
          newsquare = <Square key={newcell} id={newcell} blob={blob} time={new_timecost} style={this.state.square_house_style}/>
      }else if(newcell==this.state.stop_construction){ // construction
          if (safeties[newcell]==this.state.unsafescore){
            sqstyle = this.state.square_construction_style + this.state.square_unsafe_style
          }else{
            sqstyle = this.state.square_construction_style
          }
        newsquare = <Square key={newcell} id={newcell} blob={blob} time={new_timecost} style={sqstyle} />

      }else if(newcell==this.state.stop_school){ //school
          if (safeties[newcell]==this.state.unsafescore){
            sqstyle = this.state.square_school_style + this.state.square_unsafe_style
          }else{
            sqstyle = this.state.square_school_style
          }
        newsquare = <Square key={newcell} id={newcell} blob={blob} time={new_timecost} style={sqstyle} />

      }else if(newcell==this.state.stop_grocery){ //grocery
          if (safeties[newcell]==this.state.unsafescore){
            sqstyle = this.state.square_grocery_style + this.state.square_unsafe_style
          }else{
            sqstyle = this.state.square_grocery_style
          }
        newsquare = <Square key={newcell} id={newcell} blob={blob} time={new_timecost} style={sqstyle} />

      }else{ //empty
          if (safeties[newcell]==this.state.unsafescore){
            sqstyle = this.state.square_style + this.state.square_unsafe_style
          }else{
            sqstyle = this.state.square_style
          }
        newsquare = <Square key={newcell} id={newcell} blob={blob} time={new_timecost} style={sqstyle} />

      }
      unlabeledarea.push({"surrounding_cell_id":newcell, "square":newsquare})
    }
    return unlabeledarea
  }


  generateBlockedArea(accidentsquare){
    console.log("accident happened in", accidentsquare);
    let blocked_squares = []
    let tabu = [this.state.stop_construction, this.state.stop_grocery, this.state.stop_school, this.state.endpos] //don't let the accident happen in school, grocery, construction site or the hospital
    let lr_neighbors = validatedNeighbors(accidentsquare,2) //get left and right neighbors
    let neighborstyle = "", accidentstyle = ""

    for(let i=0; i<lr_neighbors.length; i++){ //add one of the left or right neighbors. ****if neighbor is a landmark then don't add***. can add if it is
      if(!tabu.includes(lr_neighbors[i])){
        let new_timecost = <TimeCost value={this.state.max_value} />
        if(lr_neighbors[i]==this.state.startpos){ //if accident neighbor happens in the house cell
          neighborstyle = this.state.square_style + this.state.square_blocked_style + this.state.square_blocked_house_style
        }else{
          neighborstyle = this.state.square_style + this.state.square_blocked_style
        }
        let blocked_neighbor = <Square key={lr_neighbors[i]} id={lr_neighbors[i]} blob={null} time={new_timecost} style={neighborstyle}/>
        blocked_squares.push({ key:lr_neighbors[i], ob:blocked_neighbor})
        break
      }
    }

    let new_timecost = <TimeCost value={this.state.max_value} />
    if(accidentsquare==this.state.startpos){ // if accident cell is the house cell
      accidentstyle = this.state.square_style + this.state.square_blocked_style + this.state.square_blocked_house_style
    }else{
      accidentstyle = this.state.square_style + this.state.square_blocked_style
    }
    let blocked_accident = <Square key={accidentsquare} id={accidentsquare} blob={null} time={new_timecost} style={accidentstyle}/> //add the accident cell, even if it's a landmark
    blocked_squares.push({ key:accidentsquare, ob:blocked_accident})

    return blocked_squares
  }

// generate the styled square object when the landing point can be picked from the plan
// in the nondet environment the agent could also go into the accident cell. when agent lands on the accident cell, don't remove the accident style.
  generateLandingSquareFromPlan(landingsquare){
    console.log("generating move landing sq---",this.state.blocked);
    let newsquare = null, new_timecost = null
    let blob = <Blob agent={this.state.currentTaskID}/>
    let sqstyle = ""

    if(!this.state.blocked.includes(landingsquare)){ //decide which time value to show. if landing in an accident cell, show the new cost. else, get time cost from times[]
      new_timecost = <TimeCost value={this.state.times[landingsquare]} />
    }else{
      new_timecost = <TimeCost value={this.state.max_value} />
    }

    if(landingsquare==this.state.endpos){ //decide what styles to apply to the landing cell
      newsquare = <Square key={landingsquare} id={landingsquare} blob={blob} time={new_timecost} style={this.state.square_hospital_style}/>

    }else if(landingsquare==this.state.startpos){
      if(this.state.blocked.includes(landingsquare)){
        sqstyle = this.state.square_style + this.state.square_blocked_style + this.state.square_blocked_house_style
      }else{
        sqstyle = this.state.square_house_style
      }
      newsquare = <Square key={landingsquare} id={landingsquare} blob={blob} time={new_timecost} style={sqstyle}/>

    }else if(landingsquare==this.state.stop_construction){ // construction
      if (this.state.safety[landingsquare]==this.state.unsafescore){
        sqstyle = this.state.square_construction_style + this.state.square_unsafe_style
      }else{
        sqstyle = this.state.square_construction_style
      }
      newsquare = <Square key={landingsquare} id={landingsquare} blob={blob} time={new_timecost} style={sqstyle}/>

    }else if(landingsquare==this.state.stop_school){ //school
      if (this.state.safety[landingsquare]==this.state.unsafescore){
        sqstyle = this.state.square_school_style + this.state.square_unsafe_style
      }else{
        sqstyle = this.state.square_school_style
      }
      newsquare = <Square key={landingsquare} id={landingsquare} blob={blob} time={new_timecost} style={sqstyle}/>

    }else if(landingsquare==this.state.stop_grocery){ //grocery
      if (this.state.safety[landingsquare]==this.state.unsafescore){
        sqstyle = this.state.square_grocery_style + this.state.square_unsafe_style
      }else{
        sqstyle = this.state.square_grocery_style
      }
      newsquare = <Square key={landingsquare} id={landingsquare} blob={blob} time={new_timecost} style={sqstyle}/>

    }else{ //empty
      if(this.state.blocked.includes(landingsquare)){
        if (this.state.safety[landingsquare]==this.state.unsafescore){
          sqstyle = this.state.square_style + this.state.square_unsafe_style + this.state.square_blocked_style
        }else{
          sqstyle = this.state.square_style + this.state.square_blocked_style
        }
      }else{
        if (this.state.safety[landingsquare]==this.state.unsafescore){
          sqstyle = this.state.square_style + this.state.square_unsafe_style
        }else{
          sqstyle = this.state.square_style
        }
      }

      newsquare = <Square key={landingsquare} id={landingsquare} blob={blob} time={new_timecost} style={sqstyle}/>
    }
    return newsquare
  }

//instead of picking the landing position from an array of plan steps, landing position is provided by user's choice
  generateLandingSquareFromChoice(choice){
    let newsquare = null, new_timecost = null
    let blob = <Blob agent={this.state.currentTaskID}/>
    let sqstyle = ""

    if(!this.state.blocked.includes(choice)){ //decide which time value to show. if landing in an accident cell, show the new cost. else, get time cost from times[]
      new_timecost = <TimeCost value={this.state.times[choice]} />
    }else{
      new_timecost = <TimeCost value={this.state.max_value} />
    }

    if(choice==this.state.endpos){
      newsquare = <Square key={choice} id={choice} blob={blob} time={new_timecost} style={this.state.square_hospital_style}/>

    }else if(choice==this.state.startpos){
      if(this.state.blocked.includes(choice)){
        sqstyle = this.state.square_style + this.state.square_blocked_style + this.state.square_blocked_house_style
      }else{
        sqstyle = this.state.square_house_style
      }
      newsquare = <Square key={choice} id={choice} blob={blob} time={new_timecost} style={sqstyle}/>

    }else if(choice==this.state.stop_construction){ // construction
        if (this.state.safety[choice]==this.state.unsafescore){
          sqstyle = this.state.square_construction_style + this.state.square_unsafe_style
        }else{
          sqstyle = this.state.square_construction_style
        }
      newsquare = <Square key={choice} id={choice} blob={blob} time={new_timecost} style={sqstyle}/>

    }else if(choice==this.state.stop_school){ //school
        if (this.state.safety[choice]==this.state.unsafescore){
          sqstyle = this.state.square_school_style + this.state.square_unsafe_style
        }else{
          sqstyle = this.state.square_school_style
        }
      newsquare = <Square key={choice} id={choice} blob={blob} time={new_timecost} style={sqstyle}/>

    }else if(choice==this.state.stop_grocery){ //grocery
        if (this.state.safety[choice]==this.state.unsafescore){
          sqstyle = this.state.square_grocery_style + this.state.square_unsafe_style
        }else{
          sqstyle = this.state.square_grocery_style
        }
      newsquare = <Square key={choice} id={choice} blob={blob} time={new_timecost} style={sqstyle}/>

    }else{ //empty
      if(this.state.blocked.includes(choice)){
        if (this.state.safety[choice]==this.state.unsafescore){
          sqstyle = this.state.square_style + this.state.square_unsafe_style + this.state.square_blocked_style
        }else{
          sqstyle = this.state.square_style + this.state.square_blocked_style
        }
      }else{
        if (this.state.safety[choice]==this.state.unsafescore){
          sqstyle = this.state.square_style + this.state.square_unsafe_style
        }else{
          sqstyle = this.state.square_style
        }
      }
      newsquare = <Square key={choice} id={choice} blob={blob} time={new_timecost} style={sqstyle}/>

    }
    return newsquare
  }

  generateLeavingSquare(leavingsquare){
    let timecost, oldsquare = null, sqstyle = ""

    if(!this.state.blocked.includes(leavingsquare)){ //decide which time value to show. if landing in an accident cell, show the new cost. else, get time cost from times[]
      timecost = <TimeCost value={this.state.times[leavingsquare]} />
    }else{
      timecost = <TimeCost value={this.state.max_value} />
    }

    if(leavingsquare==this.state.endpos){
      oldsquare = <Square key={leavingsquare} id={leavingsquare} blob={null} time={timecost} style={this.state.square_hospital_style}/>

    }else if(leavingsquare==this.state.startpos){
      if(this.state.blocked.includes(leavingsquare)){
        sqstyle = this.state.square_style + this.state.square_blocked_style + this.state.square_blocked_house_style
      }else{
        sqstyle = this.state.square_house_style
      }
      oldsquare = <Square key={leavingsquare} id={leavingsquare} blob={null} time={timecost} style={sqstyle}/>
    }else if(leavingsquare==this.state.stop_construction){ //construction
      if (this.state.safety[leavingsquare]==this.state.unsafescore){
        sqstyle = this.state.square_construction_style + this.state.square_unsafe_style
      }else{
        sqstyle = this.state.square_construction_style
      }
      oldsquare = <Square key={leavingsquare} id={leavingsquare} blob={null} time={timecost} style={sqstyle}/>

    }else if(leavingsquare==this.state.stop_school){ //school
      if (this.state.safety[leavingsquare]==this.state.unsafescore){
        sqstyle = this.state.square_school_style + this.state.square_unsafe_style
      }else{
        sqstyle = this.state.square_school_style
      }
      oldsquare = <Square key={leavingsquare} id={leavingsquare} blob={null} time={timecost} style={sqstyle}/>

    }else if(leavingsquare==this.state.stop_grocery){ //grocery
      if (this.state.safety[leavingsquare]==this.state.unsafescore){
        sqstyle = this.state.square_grocery_style + this.state.square_unsafe_style
      }else{
        sqstyle = this.state.square_grocery_style
      }
      oldsquare = <Square key={leavingsquare} id={leavingsquare} blob={null} time={timecost} style={sqstyle}/>

    }else{ //empty
      if(this.state.blocked.includes(leavingsquare)){
        if (this.state.safety[leavingsquare]==this.state.unsafescore){
          sqstyle = this.state.square_style + this.state.square_unsafe_style + this.state.square_blocked_style
        }else{
          sqstyle = this.state.square_style + this.state.square_blocked_style
        }
      }else{
        if (this.state.safety[leavingsquare]==this.state.unsafescore){
          sqstyle = this.state.square_style + this.state.square_unsafe_style
        }else{
          sqstyle = this.state.square_style
        }
      }
      oldsquare = <Square key={leavingsquare} id={leavingsquare} blob={null} time={timecost} style={sqstyle}/>

    }
    return oldsquare
  }

  generateExplanationTextFromPlannerResponse(taskId, milestone, direction){
    let text = explainTheBestDirection(taskId, milestone, direction)

    //create event text
    let ev_txt2 = "Timestamp " + Date.now() + " Plan_explanation " + text
    let component = <PlannerMessage profile={this.state.currentTaskID} msg={text}/>

    return {component: component, evtext: ev_txt2}
  }

  generateExplanationTextForInterrupt(taskId, milestone, direction){
      let explanation = explainTheBestDirectionAfterInterrupt(taskId, milestone, direction)

    //create event text
    let ev_txt2 = "Timestamp " + Date.now() + " Interrupt_Plan_explanation " + explanation
    let component = <PlannerMessage profile={this.state.currentTaskID} msg={explanation}/>

    return {component: component, evtext: ev_txt2}
  }

  onTimeOverrun(){
    let show = this.state.showTimeOverrun
    let count = this.state.timeOverrunCount
    if(show){
      show = false
      count += 1
    }

   this.setState({
     showTimeOverrun: show,
     timeOverrunCount: count,
     timeOverrun: null
    });
  }

  onFuelOverrun(){
    let show = this.state.showFuelOverrun
    if(show){
      show = false
    }
    let posthoc = <PosthocTrustQuestionnaire uid={this.state.userid} taskid={this.state.currentTaskID} unmount={this.handlePosthocSurveyResponse}/>

    this.setState({
      showFuelOverrun: show,
      fuelOverrun: null,
      posthoc: posthoc
    });
  }

  onConditionWorsen(){
    let show = this.state.showConditionTimer
    if(show){
      show = false
    }

    this.setState({
      showConditionTimer: show,
      conditionAlert:null
    });
  }

  render() {//10x10 board
    let direction = this.state.moves[this.state.blobat]

    let waiting_text = ""
    let alert = null
    if (this.state.safety[this.state.moves[this.state.blobat]]==this.state.unsafescore){
      alert = <RedZoneAlert />
    }

    let startButton = null
    if(this.state.start){
      startButton = <Button variant="primary" onClick={this.handleStartButtonClick}>Start Task</Button>
    }else if(this.state.loading){
      startButton = <Button variant="primary" disabled> <Spinner animation="border" role="status" size="sm"> <span className="visually-hidden"></span> </Spinner> {'  '} Loading...</Button>
      waiting_text = this.state.waiting_message
    }

  	return(
			<Container>
      <Row className="Instructions">
        { <EnvironmentHeader distanceBudget={this.state.distanceBudget} timeBudget={this.state.timeBudget}/>}
      </Row>
      <Row className="Instructions" xs="auto">
          <Col> {startButton} &nbsp; &nbsp; &nbsp; {waiting_text}</Col>
      </Row>
      <Row>
          <Col> {this.state.enableActions ? <PerformancePanel time={this.state.remainingDistance} safety={this.state.remainingSafety}
                                        grocerycheck={this.state.grocerycheck} schoolcheck={this.state.schoolcheck}
                                        constructioncheck={this.state.constructioncheck}/> : null } </Col>
          <Col> {alert} </Col>
      </Row>
			<Row>
  				<Col>
            <div className="Environment">{this.state.squares}</div>
            {this.state.enableActions ? <ActionButtonBar handleClick={this.handleActionButtonClick} disabled={this.state.actionButtonsDisabled} nextmove={direction}/> : null}
  				</Col>
  				<Col>
            {this.state.profile}
            {this.state.plannerMessage}
            {this.state.incidentAlert}
            {this.state.interruptAlert}
            {this.state.incidentRecovery}
            {this.state.interruptRecovery}
            {this.state.interim}
            {this.state.posthoc}
            {this.state.taskEnd}
            {this.state.planError}
            {this.state.timeOverrun}
            {this.state.conditionAlert}
            {this.state.fuelOverrun}
            {this.state.milestoneReplan}
  				</Col>
			</Row>
		 </Container>
		);
  }
}
export default Environment;
