import React, { useState } from 'react'
import Container from 'react-bootstrap/Container'
import Button from 'react-bootstrap/Button'
import Modal from 'react-bootstrap/Modal'

class SessionEndNotification extends React.Component{
	constructor(props) {
		super(props);
	}

	render() {

		 return (

			 <Modal show={this.props.show} backdrop="static" keyboard={false} size="lg" aria-labelledby="contained-modal-title-vcenter" centered>
					<Modal.Header>
             <Modal.Title>Great! You completed all tasks.</Modal.Title>
           </Modal.Header>
          <Modal.Body>
            <h5>To finish, please click <b>Demographics Survey Tab</b> and submit the survey</h5>
          </Modal.Body>

          <Modal.Footer>
              <Button onClick={this.props.onDialogClose}>Close</Button>
          </Modal.Footer>
      </Modal>

		);
	 }
}export default SessionEndNotification;
