import React, { useState } from 'react'
import Form from 'react-bootstrap/Form'
import FormGroup from 'react-bootstrap/FormGroup'
import Container from 'react-bootstrap/Container'
import Card from 'react-bootstrap/Card'
import Row from 'react-bootstrap/Row'
import Col from 'react-bootstrap/Col'
import Button from 'react-bootstrap/Button'
import Alert from 'react-bootstrap/Alert'
import Modal from 'react-bootstrap/Modal'
import {posthocTrustResponse} from './FormValidator'


class PosthocTrustQuestionnaire extends React.Component{
	constructor(props) {
		super(props);
		this.handleFormSubmit = this.handleFormSubmit.bind(this);
		this.collectData = this.collectData.bind(this);
		this.setErrorValues = this.setErrorValues.bind(this);
		this.validateandSubmit = this.validateandSubmit.bind(this);
		this.fetch = this.fetch.bind(this);
		this.state = {
			q1:"",
			q2:"",
			q3:"",
			q4:"",
			eq1:false,	//empty
			eq2:false,
			eq3:false,
			eq4:false,
			quiz:this.props.uid,
			alertmsg1:"",
			show:true,
			displayAlert:null,
			validated:false,
			connectionError:null
		};
	  }

	  handleFormSubmit(event) { //In our handler for the submit event, we need to stop the event from bubbling up and trying to submit the form to another page which causes a refresh and then posts all of our data appended to the web address. The line of code that does this is event.preventDefault()
			event.preventDefault();
			let valuearr = [{q1:this.state.q1},{q2:this.state.q2},{q3:this.state.q3},{q4:this.state.q4}]
			let errComplete = posthocTrustResponse(valuearr)
			this.setErrorValues(errComplete)
	  }

	validateandSubmit(){
		let al=null
		if(this.state.eq1 || this.state.eq2 ||this.state.eq3 ||this.state.eq4){
			al = <Alert variant="danger"> <Alert.Heading> Errors in Survey! </Alert.Heading> <hr />
				<div className="mb-0">{this.state.alertmsg1}</div>
			</Alert>
		}else{
			let valuearr = [{q1:this.state.q1},{q2:this.state.q2},{q3:this.state.q3},{q4:this.state.q4}]
			let obj = { prolificid:this.props.uid, taskid:this.props.taskid, answers: valuearr};
			this.fetch("POSTHOC#"+JSON.stringify(obj))
		}
		this.setState({
			displayAlert:al
		});
	}

	setErrorValues(errEmpty){
		//set empty field error
		let msg='- Question(s):'
		let e1=false,e2=false,e3=false,e4=false
		for(let i=0; i<errEmpty.length; i++){
			let ob=errEmpty[i]
			if(Object.keys(ob)[0]==="q1"){
				e1=true
				msg+=" 1,"
			}else if(Object.keys(ob)[0]==="q2") {
				e2=true
				msg+=" 2,"
			}else if(Object.keys(ob)[0]==="q3") {
				e3=true
				msg+=" 3,"
			}else if(Object.keys(ob)[0]==="q4") {
				e4=true
				msg+=" 4"
			}
		}
		if (errEmpty.length>0) {
			msg+=" can not be blank."
		}else{
			msg=""
		}

		this.setState({
			eq1:e1,	//empty
			eq2:e2,
			eq3:e3,
			eq4:e4,
			alertmsg1:msg
		},
		function ()
		{
			this.validateandSubmit();
		});
	}

	collectData(event){
		if(event.target.name==="q1"){
			this.setState({
			 q1:event.target.value
			 });
		}else if(event.target.name==="q2"){
			this.setState({
			 q2:event.target.value
			 });
		}else if(event.target.name==="q3"){
			this.setState({
			 q3:event.target.value
			 });
		}else if(event.target.name==="q4"){
			this.setState({
			 q4:event.target.value
			 });
		}
	}

	async fetch(input) {
        let id = input.split("#")[0]; //conveys type of request. give consent
        let data = input.split("#")[1]; //gives the parameters needed for the server to produce an output for the request
        let clientRequest = {   // Create client->server request message. IMPORTANT: This object must match the structure of whatever object the server is reading into
            parameters: data,
            type: id
        };
        try {
            // Attempt to send `clientRequest` via a POST request to java backend running on port 9999// Notice how the end of the url below matches what the server is listening on
            let serverUrl = window.location.href.substring(0, window.location.href.length - 6) + ":9999/api";
            let jsonReturned = await fetch(serverUrl,
                {
                    method: "POST",
                    body: JSON.stringify(clientRequest)
                });
            let ret = await jsonReturned.json();// Wait for server to return and convert it to json.
            let retJSON = JSON.parse(ret); //parse ret to JSON object. check retJSON.type and apply correct behavior
            if(retJSON.type==="POSTHOC-RESPONSE-TIME" && retJSON.message==="SUCCESS" ||
							retJSON.type==="POSTHOC-RESPONSE-SAFETY" && retJSON.message==="SUCCESS" ||
							retJSON.type==="POSTHOC-RESPONSE-TIME_SAFETY" && retJSON.message==="SUCCESS" ){
							this.props.unmount()
              this.setState({
          			show:false
          		});
						}
         } catch (e) {
           let err =
						<Alert color="danger">
							<h4 className="alert-heading">Error</h4>
							There was an error connecting to the remote server. <p>Contact administrator: sachini.weerawardhana@kcl.ac.uk </p>
						</Alert>
						 this.setState({
								connectionError: err
						});
        }
    }

	render() {
		 return (

			 <Modal show={this.state.show} backdrop="static" keyboard={false} size="lg">
					<Modal.Header>
             <Modal.Title>Evaluate the Navigation Assistant</Modal.Title>
           </Modal.Header>
          <Modal.Body>
            <Form onSubmit={this.handleFormSubmit} noValidate>

             <Form.Group>{this.state.displayAlert}</Form.Group>

 					 	<Form.Group><b>Considering the full trip</b><br/><br/></Form.Group>

             <Form.Group>
               <Form.Label className={(this.state.eq1)?'form-label-error':''}>
               <b>Q1:</b> To what extent can the navigation assistant’s behavior be predicted from moment to moment?
               </Form.Label>
               <Form.Group as={Col}>
                 <Form.Check inline="true" type="radio" label="1 (Not at all)" name="q1" value="1" onChange={this.collectData} required />
                 <Form.Check inline="true" type="radio" label="2" name="q1" value="2" onChange={this.collectData}  required />
                 <Form.Check inline="true" type="radio" label="3" name="q1" value="3" onChange={this.collectData} required />
                 <Form.Check inline="true" type="radio" label="4" name="q1" value="4" onChange={this.collectData} required />
                 <Form.Check inline="true" type="radio" label="5" name="q1" value="5" onChange={this.collectData} required />
                 <Form.Check inline="true" type="radio" label="6" name="q1" value="6" onChange={this.collectData} required />
                 <Form.Check inline="true" type="radio" label="7" name="q1" value="7" onChange={this.collectData} required />
                 <Form.Check inline="true" type="radio" label="8" name="q1" value="8" onChange={this.collectData} required />
                 <Form.Check inline="true" type="radio" label="9" name="q1" value="9" onChange={this.collectData} required />
                 <Form.Check inline="true" type="radio" label="10 (Completely)" name="q1" value="10" onChange={this.collectData} required />
               </Form.Group>
             </Form.Group>
						 <br/>
						 <Form.Group>
							 <Form.Label className={(this.state.eq2)?'form-label-error':''}>
							 <b>Q2:</b> To what extent can you count on the navigation assistant to do its job?
							 </Form.Label>
							 <Form.Group as={Col}>
								 <Form.Check inline="true" type="radio" label="1 (Not at all)" name="q2" value="1" onChange={this.collectData} required />
								 <Form.Check inline="true" type="radio" label="2" name="q2" value="2" onChange={this.collectData}  required />
								 <Form.Check inline="true" type="radio" label="3" name="q2" value="3" onChange={this.collectData} required />
								 <Form.Check inline="true" type="radio" label="4" name="q2" value="4" onChange={this.collectData} required />
								 <Form.Check inline="true" type="radio" label="5" name="q2" value="5" onChange={this.collectData} required />
								 <Form.Check inline="true" type="radio" label="6" name="q2" value="6" onChange={this.collectData} required />
								 <Form.Check inline="true" type="radio" label="7" name="q2" value="7" onChange={this.collectData} required />
								 <Form.Check inline="true" type="radio" label="8" name="q2" value="8" onChange={this.collectData} required />
								 <Form.Check inline="true" type="radio" label="9" name="q2" value="9" onChange={this.collectData} required />
								 <Form.Check inline="true" type="radio" label="10 (Completely)" name="q2" value="10" onChange={this.collectData} required />
							 </Form.Group>
						 </Form.Group>
						 	<br/>
						 <Form.Group>
							 <Form.Label className={(this.state.eq3)?'form-label-error':''}>
							 <b>Q3:</b> What degree of faith do you have that the navigation assistant will be able to cope with all system "state in the future"?
							 </Form.Label>
							 <Form.Group as={Col}>
								 <Form.Check inline="true" type="radio" label="1 (Not at all)" name="q3" value="1" onChange={this.collectData} required />
								 <Form.Check inline="true" type="radio" label="2" name="q3" value="2" onChange={this.collectData}  required />
								 <Form.Check inline="true" type="radio" label="3" name="q3" value="3" onChange={this.collectData} required />
								 <Form.Check inline="true" type="radio" label="4" name="q3" value="4" onChange={this.collectData} required />
								 <Form.Check inline="true" type="radio" label="5" name="q3" value="5" onChange={this.collectData} required />
								 <Form.Check inline="true" type="radio" label="6" name="q3" value="6" onChange={this.collectData} required />
								 <Form.Check inline="true" type="radio" label="7" name="q3" value="7" onChange={this.collectData} required />
								 <Form.Check inline="true" type="radio" label="8" name="q3" value="8" onChange={this.collectData} required />
								 <Form.Check inline="true" type="radio" label="9" name="q3" value="9" onChange={this.collectData} required />
								 <Form.Check inline="true" type="radio" label="10 (Completely)" name="q3" value="10" onChange={this.collectData} required />
							 </Form.Group>
						 </Form.Group>
						 	<br/>
						 <Form.Group>
							 <Form.Label className={(this.state.eq4)?'form-label-error':''}>
							 <b>Q4:</b> Overall, how much do you trust the navigation assistant?
							 </Form.Label>
							 <Form.Group as={Col}>
								 <Form.Check inline="true" type="radio" label="1 (Not at all)" name="q4" value="1" onChange={this.collectData} required />
								 <Form.Check inline="true" type="radio" label="2" name="q4" value="2" onChange={this.collectData}  required />
								 <Form.Check inline="true" type="radio" label="3" name="q4" value="3" onChange={this.collectData} required />
								 <Form.Check inline="true" type="radio" label="4" name="q4" value="4" onChange={this.collectData} required />
								 <Form.Check inline="true" type="radio" label="5" name="q4" value="5" onChange={this.collectData} required />
								 <Form.Check inline="true" type="radio" label="6" name="q4" value="6" onChange={this.collectData} required />
								 <Form.Check inline="true" type="radio" label="7" name="q4" value="7" onChange={this.collectData} required />
								 <Form.Check inline="true" type="radio" label="8" name="q4" value="8" onChange={this.collectData} required />
								 <Form.Check inline="true" type="radio" label="9" name="q4" value="9" onChange={this.collectData} required />
								 <Form.Check inline="true" type="radio" label="10 (Completely)" name="q4" value="10" onChange={this.collectData} required />
							 </Form.Group>
						 </Form.Group>

             <Form.Group as={Row}>
                 <Col>
                 <br/>
                 <Button type="submit">Submit</Button>
                 {this.state.connectionError}
                 </Col>
            </Form.Group>
            </Form>
          </Modal.Body>

      </Modal>

		);
	 }
}export default PosthocTrustQuestionnaire;
