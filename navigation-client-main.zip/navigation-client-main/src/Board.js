import React from 'react'
import {Alert, Button, Col, Row, Container, Toast} from 'react-bootstrap'
import Square from './Square'
import Car from './Car'
import Truck from './Truck'
import Vehicle from './Vehicle'
import Explanation from './Explanation'
import {moveCar, moveTruck, getVehicleOrientation} from './Game'

let hcar=["hl","hr"]
let vcar=["vt","vb"]
let htruck=["hl","hm","hr"]
let vtruck=["vt","vm","vb"]
let exitlabel="exit"

class Board extends React.Component{

	constructor(props){
		super(props);
		this.state={
			moves:[],
			vehicles:[], //2D array of square (x,y) coordinates
			squares:[], //1D array of square id
			exit:[],
			badcars:[],
			cells:-1,
			modal:null,
			prev:null,//prev vehicle
			prevcell:-1,//prev cell id
			rows:0, //rows on the board
			cols:0, //cols on the board
			error:"",
			win:"",
			userid:"",
			boardconfig:"",
			start: true,
			errorMsg:null
		}
		this.handleStartButtonClick = this.handleStartButtonClick.bind(this);
		this.readGame = this.readGame.bind(this);
		this.findVehicle = this.findVehicle.bind(this);
		this.findVehicleIndex = this.findVehicleIndex.bind(this);
		this.drawBoard = this.drawBoard.bind(this);
		this.onSquareClick = this.onSquareClick.bind(this);
		this.findVehicleAtSelectedCell = this.findVehicleAtSelectedCell.bind(this);
		this.move = this.move.bind(this);
		this.cellEmpty = this.cellEmpty.bind(this);
		this.playerWon = this.playerWon.bind(this);
		this.parseGameString = this.parseGameString.bind(this);
		this.addSquareCar = this.addSquareCar.bind(this);
		this.addSquareTruck = this.addSquareTruck.bind(this);
		this.nowVacant = this.nowVacant.bind(this);
		this.generateMoveTextCar = this.generateMoveTextCar.bind(this);
		this.generateMoveTextTruck = this.generateMoveTextTruck.bind(this);
	};

	handleStartButtonClick() {
		this.setState(prevState => ({
		  start: !prevState.start,
		  win:""
		}));
		if(this.state.start) {
			this.fetch("START-GAME:"+this.props.uid)
		}
	}

	async readGame(gamestr,exitstr,uuid,badcars){ //load a random game
		let data = this.parseGameString(gamestr,exitstr,badcars) //[board,[exitx,y],cellcount,rows on board, cols on board)
		let board = new Array (data[3])
		let localVehicles=this.state.vehicles
		let result = data[0].split("|")
		let pattern = /[ctgCTG][0-9]*/
		for(let i=0; i<result.length; i++){
			let item = result[i].split(" ")
			board[i] = item
			for(let j=0; j<item.length; j++){
				let v = null;
				if(pattern.test(item[j])){
					const coords = [i,j]
					v = new Vehicle(item[j])
					v.vehicleCoordinates=coords
					const found = this.findVehicle(v)
					if(found==null){ //create new object
						localVehicles.push(v)
					}else{ //already exists
						let index = this.findVehicleIndex(v)
						if(index !== -1){
							localVehicles[index].vehicleCoordinates=coords
						}
					}
				}
			}
		}
		let arr=data[1].split(",")
		let ex=[]
		for(let i=0; i<arr.length; i++){
			ex.push(Number(arr[i]))
		}
		//If we want the drawBoard() to take into account the recent changes we’ve made to the state like the exit array, we need to invoke it inside the callback, like this:	//https://www.freecodecamp.org/news/get-pro-with-react-setstate-in-10-minutes-d38251d1c781/
		await this.setState({
				vehicles:localVehicles,
				exit:ex,
				cells:data[2],
				rows:data[3],
				cols:data[4],
				badcars:data[5],
				boardconfig:gamestr+"|"+exitstr,
		}, ()=> {this.drawBoard()});
	}

	parseGameString(gamestr,exitstr,badcars){
		//convert gamestr that comes like this
		//C1 C1 34 33 32 31|30 29 28 27 26 25|24 23 22 C3 C4 19|C0 C0 T0 C3 C4 13|12 C2 T0 9 C5 C5|6 C2 T0 3 2 1|
		//exit 13,14 to this
		//"C1 0 0 0 0 0|C1 0 g g 0 0|0 0 0 0 0 0|0 0 T2 T2 T2 0";
		//exit = "1,5"; row col ids of the cell on the border
		let cellcount = 0, rows = 0, cols = 0, count=0
		let exarr=[exitstr.split(",")[0],exitstr.split(",")[1]]
		let bads=[]
		let parts = badcars.split(",");
		for(let i=0; i<parts.length; i++){
			bads.push(parts[i])
		}
		let expos=[], rev=[]
		let ex="", board=""
		let result = gamestr.split("|")
		let pattern = /[ctgCTG][0-9]*/
		for(let i=0; i<result.length; i++){
			let item = result[i].split(" ")//numbers on a line must be separated with a space
			let conv = []
			for(let j=0; j<item.length; j++){
				if(!isNaN(item[j])){
					conv.push(0)
				}else{
					conv.push(item[j])
				}
				cellcount++
			}
			for(let k=0; k<conv.length; k++){
				board+=conv[k]+" "
			}
			board = board.substring(0,board.length-1)+"|"
			rows++
			cols=item.length
		}
		for(let i=0; i<exarr.length; i++){ //reverse number exit car cells
			rev[i]=cellcount-parseInt(exarr[i]) //cellcount=42 cell index start at 0
		}
		for(let i=0; i<rows; i++){
			for(let j=0; j<cols; j++){
				if(rev.indexOf(count)!==-1){
					expos.push([i,j])
				}
				count++
			}
		}
		if(Math.abs(parseInt(exarr[0]) - parseInt(exarr[1]))===1){ //horizontal
			for(let i=0; i<expos.length; i++){
				let cell=expos[i]
				if(cell[1]===0 || cell[1]===cols-1){ //exit from left border or right border
					ex=cell[0]+","+cell[1]
				}
			}
		}else{ //verticle
			for(let i=0; i<expos.length; i++){
				let cell=expos[i]
				if(cell[0]===0 || cell[0]===rows-1){ //exit from top border or bottom border
					ex=cell[0]+","+cell[1]
				}
			}
		}
		return [board.substring(0,board.length-1),ex,cellcount,rows,cols,bads]
	}

	drawBoard(){
		let localsquares=[]
		let occupied=[]
		let clicked=false
		let exitid=this.state.exit[0]*this.state.cols+this.state.exit[1]
		for(let i=0; i<this.state.vehicles.length; i++){//add vehicles to board
			let v = this.state.vehicles[i];
			if(v.vehicleCoordinates.length===2){//car
				let ori=getVehicleOrientation(v)
				let x1=v.vehicleCoordinates[0][0]
				let y1=v.vehicleCoordinates[0][1]
				let x2=v.vehicleCoordinates[1][0]
				let y2=v.vehicleCoordinates[1][1]
				v.vehicleOrientation=ori //how to call the set method
				let sqid1=x1*this.state.cols+y1
				let sqid2=x2*this.state.cols+y2
				let c1,c2
				if(ori===1){ //vertical car
					if(x1<x2){ //c1 is the top cell //c2 is the bottom cell
						if(exitid!==sqid1){//this square is not an exit. so don't pass the exit prop
							c1 = <Square key={sqid1} id={sqid1} children={<Car id={v.vehicleId} row={x1} col={y1} cell={"vt"}/>} onClick={this.onSquareClick.bind(this)} selected={clicked}/>
						}else if(exitid===sqid1){
							c1 = <Square key={sqid1} id={sqid1} children={<Car id={v.vehicleId} row={x1} col={y1} cell={"vt"}/>} onClick={this.onSquareClick.bind(this)} selected={clicked} exit={exitlabel}/>
						}
						if(exitid!==sqid2){
							c2 = <Square key={sqid2} id={sqid2} children={<Car id={v.vehicleId} row={x2} col={y2} cell={"vb"}/>} onClick={this.onSquareClick.bind(this)} selected={clicked}/>
						}else if(exitid===sqid2){
							c2 = <Square key={sqid2} id={sqid2} children={<Car id={v.vehicleId} row={x2} col={y2} cell={"vb"}/>} onClick={this.onSquareClick.bind(this)} selected={clicked} exit={exitlabel}/>
						}
					}else{ //c2 is the top cell
						if(exitid!==sqid1){//this square is not an exit. so don't pass the exit prop
							c1 = <Square key={sqid1} id={sqid1} children={<Car id={v.vehicleId} row={x1} col={y1} cell={"vb"}/>} onClick={this.onSquareClick.bind(this)} selected={clicked}/>
						}else if(exitid===sqid1){
							c1 = <Square key={sqid1} id={sqid1} children={<Car id={v.vehicleId} row={x1} col={y1} cell={"vb"}/>} onClick={this.onSquareClick.bind(this)} selected={clicked} exit={exitlabel}/>
						}
						if(exitid!==sqid2){
							c2 = <Square key={sqid2} id={sqid2} children={<Car id={v.vehicleId} row={x2} col={y2} cell={"vt"}/>} onClick={this.onSquareClick.bind(this)} selected={clicked}/>
						}else if(exitid===sqid2){
							c2 = <Square key={sqid2} id={sqid2} children={<Car id={v.vehicleId} row={x2} col={y2} cell={"vt"}/>} onClick={this.onSquareClick.bind(this)} selected={clicked} exit={exitlabel}/>
						}
					}
				}else if(ori===0){ //horizontal car
					if(y1<y2){ //c1 is the left cell //c2 is the right cell
						if(exitid!==sqid1){//this square is not an exit. so don't pass the exit prop
							c1 = <Square key={sqid1} id={sqid1} children={<Car id={v.vehicleId} row={x1} col={y1} cell={"hl"}/>} onClick={this.onSquareClick.bind(this)} selected={clicked}/>
						}else if(exitid===sqid1){
							c1 = <Square key={sqid1} id={sqid1} children={<Car id={v.vehicleId} row={x1} col={y1} cell={"hl"}/>} onClick={this.onSquareClick.bind(this)} selected={clicked} exit={exitlabel}/>
						}
						if(exitid!==sqid2){
							c2 = <Square key={sqid2} id={sqid2} children={<Car id={v.vehicleId} row={x2} col={y2} cell={"hr"}/>} onClick={this.onSquareClick.bind(this)} selected={clicked}/>
						}else if(exitid===sqid2){
							c2 = <Square key={sqid2} id={sqid2} children={<Car id={v.vehicleId} row={x2} col={y2} cell={"hr"}/>} onClick={this.onSquareClick.bind(this)} selected={clicked} exit={exitlabel}/>
						}
					}else{ //c2 is the left cell c1 is the right cell
						if(exitid!==sqid1){//this square is not an exit. so don't pass the exit prop
							c1 = <Square key={sqid1} id={sqid1} children={<Car id={v.vehicleId} row={x1} col={y1} cell={"hr"}/>} onClick={this.onSquareClick.bind(this)} selected={clicked}/>
						}else if(exitid===sqid1){
							c1 = <Square key={sqid1} id={sqid1} children={<Car id={v.vehicleId} row={x1} col={y1} cell={"hr"}/>} onClick={this.onSquareClick.bind(this)} selected={clicked} exit={exitlabel}/>
						}
						if(exitid!==sqid2){
							c2 = <Square key={sqid2} id={sqid2} children={<Car id={v.vehicleId} row={x2} col={y2} cell={"h1"}/>} onClick={this.onSquareClick.bind(this)} selected={clicked}/>
						}else if(exitid===sqid2){
							c2 = <Square key={sqid2} id={sqid2} children={<Car id={v.vehicleId} row={x2} col={y2} cell={"h1"}/>} onClick={this.onSquareClick.bind(this)} selected={clicked} exit={exitlabel}/>
						}
					}
				}
				localsquares[sqid1]=c1
				localsquares[sqid2]=c2
				occupied.push(sqid1)
				occupied.push(sqid2)
			}else if(v.vehicleCoordinates.length===3){ //truck
				let ori=getVehicleOrientation(v)
				let x1=v.vehicleCoordinates[0][0]
				let y1=v.vehicleCoordinates[0][1]
				let x2=v.vehicleCoordinates[1][0]
				let y2=v.vehicleCoordinates[1][1]
				let x3=v.vehicleCoordinates[2][0]
				let y3=v.vehicleCoordinates[2][1]
				let sqid1=x1*this.state.cols+y1
				let sqid2=x2*this.state.cols+y2
				let sqid3=x3*this.state.cols+y3
				let t1,t2,t3
				v.vehicleOrientation=ori
				if(ori===1){ //vertical truck
					if(x1<x2 && x2<x3){ //t1 is the top cell //t2 is the mod cell //t3 is the bottom cell
						if(exitid!==sqid1){
							t1 = <Square key={sqid1} id={sqid1} children={<Truck id={v.vehicleId} row={x1} col={y1} cell={"vt"}/>} onClick={this.onSquareClick.bind(this)} selected={clicked}/>
						}else if(exitid===sqid1){
							t1 = <Square key={sqid1} id={sqid1} children={<Truck id={v.vehicleId} row={x1} col={y1} cell={"vt"}/>} onClick={this.onSquareClick.bind(this)} selected={clicked} exit={exitlabel}/>
						}
						if(exitid!==sqid2){
							t2 = <Square key={sqid2} id={sqid2} children={<Truck id={v.vehicleId} row={x2} col={y2} cell={"vm"}/>} onClick={this.onSquareClick.bind(this)} selected={clicked}/>
						}else if(exitid===sqid2){
							t2 = <Square key={sqid2} id={sqid2} children={<Truck id={v.vehicleId} row={x2} col={y2} cell={"vm"}/>} onClick={this.onSquareClick.bind(this)} selected={clicked} exit={exitlabel}/>
						}
						if(exitid!==sqid3){
							t3 = <Square key={sqid3} id={sqid3} children={<Truck id={v.vehicleId} row={x3} col={y3} cell={"vb"}/>} onClick={this.onSquareClick.bind(this)} selected={clicked}/>
						}else if(exitid===sqid3){
							t3 = <Square key={sqid3} id={sqid3} children={<Truck id={v.vehicleId} row={x3} col={y3} cell={"vb"}/>} onClick={this.onSquareClick.bind(this)} selected={clicked} exit={exitlabel}/>
						}
					}else if(x1>x2 && x2>x3){ //t3 is the top cell //t2 is the mod cell //t1 is the bottom cell
						if(exitid!==sqid1){
							t1 = <Square key={sqid1} id={sqid1} children={<Truck id={v.vehicleId} row={x1} col={y1} cell={"vb"}/>} onClick={this.onSquareClick.bind(this)} selected={clicked}/>
						}else if(exitid===sqid1){
							t1 = <Square key={sqid1} id={sqid1} children={<Truck id={v.vehicleId} row={x1} col={y1} cell={"vb"}/>} onClick={this.onSquareClick.bind(this)} selected={clicked} exit={exitlabel}/>
						}
						if(exitid!==sqid2){
							t2 = <Square key={sqid2} id={sqid2} children={<Truck id={v.vehicleId} row={x2} col={y2} cell={"vm"}/>} onClick={this.onSquareClick.bind(this)} selected={clicked}/>
						}else if(exitid===sqid2){
							t2 = <Square key={sqid2} id={sqid2} children={<Truck id={v.vehicleId} row={x2} col={y2} cell={"vm"}/>} onClick={this.onSquareClick.bind(this)} selected={clicked} exit={exitlabel}/>
						}
						if(exitid!==sqid3){
							t3 = <Square key={sqid3} id={sqid3} children={<Truck id={v.vehicleId} row={x3} col={y3} cell={"vt"}/>} onClick={this.onSquareClick.bind(this)} selected={clicked}/>
						}else if(exitid===sqid3){
							t3 = <Square key={sqid3} id={sqid3} children={<Truck id={v.vehicleId} row={x3} col={y3} cell={"vt"}/>} onClick={this.onSquareClick.bind(this)} selected={clicked} exit={exitlabel}/>
						}
					}
				}else if(ori===0){ //horizontal truck
					if(y1<y2 && y2<y3){ //t1 is the left// t2 is the mid //t3 is the right
						if(exitid!==sqid1){
							t1 = <Square key={sqid1} id={sqid1} children={<Truck id={v.vehicleId} row={x1} col={y1} cell={"hl"}/>} onClick={this.onSquareClick.bind(this)} selected={clicked}/>
						}else if(exitid===sqid1){
							t1 = <Square key={sqid1} id={sqid1} children={<Truck id={v.vehicleId} row={x1} col={y1} cell={"hl"}/>} onClick={this.onSquareClick.bind(this)} selected={clicked} exit={exitlabel}/>
						}
						if(exitid!==sqid2){
							t2 = <Square key={sqid2} id={sqid2} children={<Truck id={v.vehicleId} row={x2} col={y2} cell={"hm"}/>} onClick={this.onSquareClick.bind(this)} selected={clicked}/>
						}else if(exitid===sqid2){
							t2 = <Square key={sqid2} id={sqid2} children={<Truck id={v.vehicleId} row={x2} col={y2} cell={"hm"}/>} onClick={this.onSquareClick.bind(this)} selected={clicked} exit={exitlabel}/>
						}
						if(exitid!==sqid3){
							t3 = <Square key={sqid3} id={sqid3} children={<Truck id={v.vehicleId} row={x3} col={y3} cell={"hr"}/>} onClick={this.onSquareClick.bind(this)} selected={clicked}/>
						}else if(exitid===sqid3){
							t3 = <Square key={sqid3} id={sqid3} children={<Truck id={v.vehicleId} row={x3} col={y3} cell={"hr"}/>} onClick={this.onSquareClick.bind(this)} selected={clicked} exit={exitlabel}/>
						}
					}else if(y1>y2 && y2>y3){ //t3 is the left //t2 is the mid //t3 is the right
						if(exitid!==sqid1){
							t1 = <Square key={sqid1} id={sqid1} children={<Truck id={v.vehicleId} row={x1} col={y1} cell={"hr"}/>} onClick={this.onSquareClick.bind(this)} selected={clicked}/>
						}else if(exitid===sqid1){
							t1 = <Square key={sqid1} id={sqid1} children={<Truck id={v.vehicleId} row={x1} col={y1} cell={"hr"}/>} onClick={this.onSquareClick.bind(this)} selected={clicked} exit={exitlabel}/>
						}
						if(exitid!==sqid2){
							t2 = <Square key={sqid2} id={sqid2} children={<Truck id={v.vehicleId} row={x2} col={y2} cell={"hm"}/>} onClick={this.onSquareClick.bind(this)} selected={clicked}/>
						}else if(exitid===sqid2){
							t2 = <Square key={sqid2} id={sqid2} children={<Truck id={v.vehicleId} row={x2} col={y2} cell={"hm"}/>} onClick={this.onSquareClick.bind(this)} selected={clicked} exit={exitlabel}/>
						}
						if(exitid!==sqid3){
							t3 = <Square key={sqid3} id={sqid3} children={<Truck id={v.vehicleId} row={x3} col={y3} cell={"hl"}/>} onClick={this.onSquareClick.bind(this)} selected={clicked}/>
						}else if(exitid===sqid3){
							t3 = <Square key={sqid3} id={sqid3} children={<Truck id={v.vehicleId} row={x3} col={y3} cell={"hl"}/>} onClick={this.onSquareClick.bind(this)} selected={clicked} exit={exitlabel}/>
						}
					}
				}
				localsquares[sqid1]=t1
				localsquares[sqid2]=t2
				localsquares[sqid3]=t3
				occupied.push(sqid1)
				occupied.push(sqid2)
				occupied.push(sqid3)
			}
		}
		//then fill the empty squares
		for (let i = 0; i < this.state.cells; i++) {
			if(!occupied.includes(i)){
				let empty=null;
				if(exitid===i){
					empty = <Square key={i} id={i} children={null} onClick={this.onSquareClick.bind(this)} selected={clicked} exit={exitlabel}/>
				}else{
					empty = <Square key={i} id={i} children={null} onClick={this.onSquareClick.bind(this)} selected={clicked}/>
				}
				localsquares[i]=empty
			}
		}
		this.setState({
				squares:localsquares
		});
	}

	findVehicle(v){ //null=variable declared and assigned with value null. undefined=variable declared but not assigned a value
		if(v!==null){
			for(let i=0; i<this.state.vehicles.length; i++){
				if(this.state.vehicles[i].equals(v)){
					return this.state.vehicles[i];
				}
			}
		}
		return null;
	}

	findVehicleIndex(ob) {
		for (let i = 0; i < this.state.vehicles.length; i++) {
			if (this.state.vehicles[i].equals(ob)) {
				return i;
			}
		}
		return -1;
	}

	findVehicleAtSelectedCell(pos){
		for(let i=0; i<this.state.vehicles.length; i++){ //find in vehicles arr which car is in this cell
			let v = this.state.vehicles[i]
			if(v.hasCoordinates(pos)){
				return v;
			}
		}
		return null;
	}

	addSquareCar(j,sqid,svid,exitid,ori,selected){
		let sq=null
		if(ori===0){ //horizontal
			if(sqid===exitid){
				sq=<Square key={sqid} id={sqid} children={<Car id={svid} row={Math.trunc(sqid/this.state.rows)} col={sqid%this.state.cols} cell={hcar[j]}/>} onClick={this.onSquareClick.bind(this)} selected={selected} exit={exitlabel}/>
			}else{
				sq=<Square key={sqid} id={sqid} children={<Car id={svid} row={Math.trunc(sqid/this.state.rows)} col={sqid%this.state.cols} cell={hcar[j]}/>} onClick={this.onSquareClick.bind(this)} selected={selected}/>
			}
		}else if(ori===1){ //vertical
			if(exitid===sqid){
				sq=<Square key={sqid} id={sqid} children={<Car id={svid} row={Math.trunc(sqid/this.state.rows)} col={sqid%this.state.cols} cell={vcar[j]}/>} onClick={this.onSquareClick.bind(this)} selected={selected} exit={exitlabel}/>
			}else{
				sq=<Square key={sqid} id={sqid} children={<Car id={svid} row={Math.trunc(sqid/this.state.rows)} col={sqid%this.state.cols} cell={vcar[j]}/>} onClick={this.onSquareClick.bind(this)} selected={selected}/>
			}
		}
		return sq
	}

	addSquareTruck(j,sqid,svid,exitid,ori,selected){
		let sq=null
		if(ori===0){ //horizontal
			if(exitid===sqid){
				sq = <Square key={sqid} id={sqid} children={<Truck id={svid} row={Math.trunc(sqid/this.state.rows)} col={sqid%this.state.cols} cell={htruck[j]}/>} onClick={this.onSquareClick.bind(this)} selected={selected} exit={exitlabel}/>
			}else{
				sq = <Square key={sqid} id={sqid} children={<Truck id={svid} row={Math.trunc(sqid/this.state.rows)} col={sqid%this.state.cols} cell={htruck[j]}/>} onClick={this.onSquareClick.bind(this)} selected={selected}/>
			}
		}else if(ori===1){ //verticle
			if(exitid===sqid){
				sq = <Square key={sqid} id={sqid} children={<Truck id={svid} row={Math.trunc(sqid/this.state.rows)} col={sqid%this.state.cols} cell={vtruck[j]}/>} onClick={this.onSquareClick.bind(this)} selected={selected} exit={exitlabel}/>
			}else{
				sq = <Square key={sqid} id={sqid} children={<Truck id={svid} row={Math.trunc(sqid/this.state.rows)} col={sqid%this.state.cols} cell={vtruck[j]}/>} onClick={this.onSquareClick.bind(this)} selected={selected}/>
			}
		}
		return sq
	}

	async onSquareClick(isSelected, sqid){
		//check if g is at exit. display alert
		//call moveCar in Game.js here. i want to click a car (to select) and move it by clicking on an adjacent empty cell
		let movesSoFar=this.state.moves
		let localsquares=this.state.squares.slice()
		let localvehicles=this.state.vehicles.slice()
		let pos=[Math.trunc(sqid/this.state.cols),sqid%this.state.cols]
		let selectedVehicleId="",err="", winstat=""
		let m=null
		let restart=false
		let exitid=this.state.exit[0]*this.state.cols+this.state.exit[1]
		let vehicleCurrent=this.findVehicleAtSelectedCell(pos)
		let vehiclePrev=this.findVehicle(this.state.prev)
		if(vehicleCurrent!==null){//clicked a cell with a vehicle
				//if(vehicleCurrent.vehicleId==="C4"){ //show an explanationw when unwanted car is clicked
				//		m=<Explanation show={true} showquiz={null}/>
				//}
			selectedVehicleId=vehicleCurrent.vehicleId
			let vids=[], pvids=[]
			for(let i=0; i<vehicleCurrent.vehicleCoordinates.length; i++){ //locate squares with selected and prev vehicle objects
				vids.push(vehicleCurrent.vehicleCoordinates[i][0]*this.state.cols+vehicleCurrent.vehicleCoordinates[i][1])
			}
			if(this.state.prev!=null){ //previous cell has a vehicle
				for(let i=0; i<vehiclePrev.vehicleCoordinates.length; i++){
					pvids.push(vehiclePrev.vehicleCoordinates[i][0]*this.state.cols+vehiclePrev.vehicleCoordinates[i][1])
				}
				for(let i=0; i<localsquares.length; i++){
					if(vids.includes(i) || vehicleCurrent.equals(vehiclePrev)){ //square i is now clicked
						for(let j=0; j<vids.length; j++){ //highlight selected cell
							let sq=null
							if(selectedVehicleId.match(/c/i) || (selectedVehicleId.match(/g/i))){
								sq=this.addSquareCar(j,vids[j],selectedVehicleId,exitid,vehicleCurrent.orientation,true)
							}else{
								sq=this.addSquareTruck(j,vids[j],selectedVehicleId,exitid,vehicleCurrent.orientation,true)
							}
							localsquares[vids[j]]=sq
						}
						if(vehiclePrev!=null && !vehicleCurrent.equals(vehiclePrev)){ //unhighlight previously selected car
							for(let j=0; j<pvids.length; j++){
								let sq=null
								if(vehiclePrev.vehicleId.match(/c/i) || (vehiclePrev.vehicleId.match(/g/i))){
									sq=this.addSquareCar(j,pvids[j],vehiclePrev.vehicleId,exitid,vehiclePrev.orientation,false)
								}else{
									sq=this.addSquareTruck(j,pvids[j],vehiclePrev.vehicleId,exitid,vehiclePrev.orientation,false)
								}
								localsquares[pvids[j]]=sq
							}
						}else if(vehiclePrev===null || vehicleCurrent==null){ //unhighlight if prev selected is an empty cell
							if(this.state.prevcell===exitid){
								localsquares[this.state.prevcell]=	<Square key={this.state.prevcell} id={this.state.prevcell} children={null} onClick={this.onSquareClick.bind(this)} selected={false} exit={exitlabel}/>
							}else{
								localsquares[this.state.prevcell]=	<Square key={this.state.prevcell} id={this.state.prevcell} children={null} onClick={this.onSquareClick.bind(this)} selected={false}/>
							}
						}
					}
				}
			}else if(this.state.prev==null){
				//if current has vehicle, highlight
				for(let i=0; i<localsquares.length; i++){
					if(vids.includes(i)){ //square i is now clicked
						for(let j=0; j<vids.length; j++){ //highlight selected cell
							let sq=null
							if(selectedVehicleId.match(/c/i) || (selectedVehicleId.match(/g/i))){
								sq=this.addSquareCar(j,vids[j],selectedVehicleId,exitid,vehicleCurrent.orientation,true)
							}else{
								sq=this.addSquareTruck(j,vids[j],selectedVehicleId,exitid,vehicleCurrent.orientation,true)
							}
							localsquares[vids[j]]=sq
						}
					}
				}
			}
		}else{ //clicked an empty cell
			if(this.state.prev!==null){ //if prevselected has a vehicle move if allowed
				let result = this.move(this.state.prev,sqid)
				let movesSoFar = this.state.moves
				localsquares = result[0]
				localvehicles=result[1]
				vehicleCurrent = result[2]
				sqid = result[3]
				err=result[4]
				movesSoFar.push(result[5])
				let win  = this.playerWon(localvehicles)
				if(win){ //WINNING STATE---------------------------
					 winstat = <Alert variant="success"> You won the game!!! <br /> To wrap up, please complete a short survey by clicking on <b>Take a Survey</b> tab</Alert>
					 localvehicles = []
					 sqid=-1
					 vehicleCurrent = null
				     localsquares = []
				     this.props.onComplete(movesSoFar,this.state.boardconfig)
				}
			}
		}
		this.setState({
				modal:m,
				error:err,
				win: winstat,
				prevcell:sqid,
				prev:vehicleCurrent,
				squares:localsquares,
				vehicles:localvehicles,
				moves:movesSoFar
			});
	}

	nowVacant(oldvid,newvid){
		for(let i=0; i<oldvid.length; i++){
			if(!newvid.includes(oldvid[i])){
				return oldvid[i]
			}
		}
	}

	generateMoveTextCar(selectedVehicle,oldvids,newvids,newpos){
		let moveDesc=""
		let loc1 = (this.state.cols*this.state.rows)-newvids[0]
		let loc2 = (this.state.cols*this.state.rows)-newvids[1]
		let loc3 = (this.state.cols*this.state.rows)-this.nowVacant(oldvids,newvids)
		let loc1_old = (this.state.cols*this.state.rows)-oldvids[0]
		let loc2_old = (this.state.cols*this.state.rows)-oldvids[1]
		if(newpos[2]==="SN"){
			let from = Math.max(loc1_old,loc2_old)
			let to = Math.max(loc1,loc2)
			moveDesc = "MOVE-CAR "+ selectedVehicle.vehicleId + " L"+ from +" L"+ to+" L"+loc3+" "+newpos[2]
		}else if(newpos[2]==="NS"){
			let from = Math.min(loc1_old,loc2_old)
			let to = Math.min(loc1,loc2)
			moveDesc = "MOVE-CAR "+ selectedVehicle.vehicleId + " L"+ from +" L"+ to+" L"+loc3+" "+newpos[2]
		}else if(newpos[2]==="WE"){
			let from = Math.min(loc1_old,loc2_old)
			let to = Math.min(loc1,loc2)
			moveDesc = "MOVE-CAR "+ selectedVehicle.vehicleId + " L"+ from +" L"+ to+" L"+loc3+" "+newpos[2]
		}else if(newpos[2]==="EW"){
			let from = Math.max(loc1_old,loc2_old)
			let to = Math.max(loc1,loc2)
			moveDesc = "MOVE-CAR "+ selectedVehicle.vehicleId + " L"+ from +" L"+ to+" L"+loc3+" "+newpos[2]
		}
		return moveDesc
	}

	generateMoveTextTruck(selectedVehicle, oldvids,newvids,newpos){
		let moveDesc=""
		let loc1 = (this.state.cols*this.state.rows)-newvids[0]
		let loc2 = (this.state.cols*this.state.rows)-newvids[1]
		let loc3 = (this.state.cols*this.state.rows)-newvids[2]
		let loc4 = (this.state.cols*this.state.rows)-this.nowVacant(oldvids,newvids) //free pos after move
		let loc1_old = (this.state.cols*this.state.rows)-oldvids[0]
		let loc2_old = (this.state.cols*this.state.rows)-oldvids[1]
		let loc3_old = (this.state.cols*this.state.rows)-oldvids[2]
		if(newpos[3]==="SN"){
			let from = Math.max(loc1_old,loc2_old,loc3_old)
			let to = Math.max(loc1,loc2,loc3)
			let tailnow=Math.min(loc1,loc2,loc3)
			moveDesc = "MOVE-TRUCK "+ selectedVehicle.vehicleId + " L"+ from +" L"+ to+ " L"+ tailnow+" L"+loc4+" "+newpos[3]
		}else if(newpos[3]==="NS"){
			let from = Math.min(loc1_old,loc2_old,loc3_old)
			let to = Math.min(loc1,loc2,loc3)
			let tailnow=Math.max(loc1,loc2,loc3)
			moveDesc = "MOVE-TRUCK "+ selectedVehicle.vehicleId + " L"+ from +" L"+ to+ " L"+ tailnow+" L"+loc4+" "+newpos[3]
		}else if(newpos[3]==="WE"){
			let from = Math.min(loc1_old,loc2_old,loc3_old)
			let to = Math.min(loc1,loc2,loc3)
			let tailnow=Math.max(loc1,loc2,loc3)
			moveDesc = "MOVE-TRUCK "+ selectedVehicle.vehicleId + " L"+ from +" L"+ to+ " L"+ tailnow+" L"+loc4+" "+newpos[3]
		}else if(newpos[3]==="EW"){
			let from = Math.max(loc1_old,loc2_old,loc3_old)
			let to = Math.max(loc1,loc2,loc3)
			let tailnow=Math.min(loc1,loc2,loc3)
			moveDesc = "MOVE-TRUCK "+ selectedVehicle.vehicleId + " L"+ from +" L"+ to+ " L"+ tailnow+" L"+loc4+" "+newpos[3]
		}
		return moveDesc
	}

	move(selectedVehicle, moveToCell){
		let localsquares=this.state.squares.slice()
		let localvehicles=this.state.vehicles.slice()
		let empty=this.cellEmpty(moveToCell)
		let index=this.findVehicleIndex(selectedVehicle)
		let exitid=this.state.exit[0]*this.state.cols+this.state.exit[1]
		let oldvids=[],newvids=[]
		let msg="", moveDesc=""
		for(let i=0; i<selectedVehicle.vehicleCoordinates.length; i++){  //save old vehicle ids
			oldvids.push(selectedVehicle.vehicleCoordinates[i][0]*this.state.cols+selectedVehicle.vehicleCoordinates[i][1])
		}
		//console.log("old vehicle position", oldvids)
		if(selectedVehicle.vehicleId.match(/c/i) || (selectedVehicle.vehicleId.match(/g/i))){
			let newpos = moveCar(selectedVehicle,moveToCell,empty) //at this point localvehicles still have the old (x,y)
			//console.log("car new vehicle position, newpos",newpos)
			if(newpos!==null){ //can move safely
				for(let j=0; j<oldvids.length; j++){ //unhighlight old cells, no children
					let sq=null
					if(oldvids[j]===exitid){
						sq=<Square key={oldvids[j]} id={oldvids[j]} children={null} onClick={this.onSquareClick.bind(this)} selected={false} exit={exitlabel}/>
					}else{
						sq=<Square key={oldvids[j]} id={oldvids[j]} children={null} onClick={this.onSquareClick.bind(this)} selected={false}/>
					}
					localsquares[oldvids[j]]=sq
				}
				selectedVehicle.updateVehicleCoordinates(newpos.slice(0,2)) //update vehicle properties
				for(let i=0; i<selectedVehicle.vehicleCoordinates.length; i++){ //update new vehicle ids in vehicles array
					newvids.push(selectedVehicle.vehicleCoordinates[i][0]*this.state.cols+selectedVehicle.vehicleCoordinates[i][1])
				}
				moveDesc = this.generateMoveTextCar(selectedVehicle,oldvids,newvids,newpos)
				for(let j=0; j<newvids.length; j++){ //highlight new cells with the car
					let sq=null
						if(selectedVehicle.vehicleId.match(/c/i) || (selectedVehicle.vehicleId.match(/g/i))){
							if(selectedVehicle.orientation===0){ //horizontal
								if(newvids[j]===exitid){
									sq=<Square key={newvids[j]} id={newvids[j]} children={<Car id={selectedVehicle.vehicleId} row={Math.trunc(newvids[j]/this.state.cols)} col={newvids[j]%this.state.rows} cell={hcar[j]}/>} onClick={this.onSquareClick.bind(this)} selected={false} exit={exitlabel}/>
								}else{
									sq=<Square key={newvids[j]} id={newvids[j]} children={<Car id={selectedVehicle.vehicleId} row={Math.trunc(newvids[j]/this.state.cols)} col={newvids[j]%this.state.rows} cell={hcar[j]}/>} onClick={this.onSquareClick.bind(this)} selected={false}/>
								}
							}else if(selectedVehicle.orientation===1){ //verticle
								if(newvids[j]===exitid){
									sq=<Square key={newvids[j]} id={newvids[j]} children={<Car id={selectedVehicle.vehicleId} row={Math.trunc(newvids[j]/this.state.cols)} col={newvids[j]%this.state.rows} cell={vcar[j]}/>} onClick={this.onSquareClick.bind(this)} selected={false} exit={exitlabel}/>
								}else{
									sq=<Square key={newvids[j]} id={newvids[j]} children={<Car id={selectedVehicle.vehicleId} row={Math.trunc(newvids[j]/this.state.cols)} col={newvids[j]%this.state.rows} cell={vcar[j]}/>} onClick={this.onSquareClick.bind(this)} selected={false}/>
								}
							}
						}
					localsquares[newvids[j]]=sq
				}
				console.log(">>>>>>>>>>>>>>>>>>>>>>>>>>>> move finished",selectedVehicle.vehicleId)
				console.log(oldvids)
				console.log(newvids)
				if(selectedVehicle.vehicleId==='C1'){
					let sq=null, missingsq=null, missing=0
					for(let i=0; i<newvids.length; i++){
						if(oldvids.indexOf(newvids[i])===-1){
							missing=newvids[i]
						}
					}
					missingsq=<Square key={missing} id={missing} children={null} onClick={this.onSquareClick.bind(this)} selected={false}/>
					newvids=[] //clear newvids and replace with old
					newvids.push.apply(newvids, oldvids);
					console.log("-------   ",newvids,missing)
					for(let j=0; j<newvids.length; j++){ //highlight new cells with the car
						let sq=null
						if(selectedVehicle.orientation===0){ //horizontal
							if(newvids[j]===exitid){
								sq=<Square key={newvids[j]} id={newvids[j]} children={<Car id={selectedVehicle.vehicleId} row={Math.trunc(newvids[j]/this.state.cols)} col={newvids[j]%this.state.rows} cell={hcar[j]}/>} onClick={this.onSquareClick.bind(this)} selected={false} exit={exitlabel}/>
							}else{
								sq=<Square key={newvids[j]} id={newvids[j]} children={<Car id={selectedVehicle.vehicleId} row={Math.trunc(newvids[j]/this.state.cols)} col={newvids[j]%this.state.rows} cell={hcar[j]}/>} onClick={this.onSquareClick.bind(this)} selected={false}/>
							}
						}else if(selectedVehicle.orientation===1){ //verticle
							if(newvids[j]===exitid){
								sq=<Square key={newvids[j]} id={newvids[j]} children={<Car id={selectedVehicle.vehicleId} row={Math.trunc(newvids[j]/this.state.cols)} col={newvids[j]%this.state.rows} cell={vcar[j]}/>} onClick={this.onSquareClick.bind(this)} selected={false} exit={exitlabel}/>
							}else{
								sq=<Square key={newvids[j]} id={newvids[j]} children={<Car id={selectedVehicle.vehicleId} row={Math.trunc(newvids[j]/this.state.cols)} col={newvids[j]%this.state.rows} cell={vcar[j]}/>} onClick={this.onSquareClick.bind(this)} selected={false}/>
							}
						}
						localsquares[newvids[j]]=sq
						localsquares[missing]=missingsq
					}
				}
			}else if(newpos===null){ //tried to move multiple cells at once. bad move. reset everything
				 msg = <Alert variant="warning">Illegal move. Vehicle can only be moved by 1 cell in the same orientation</Alert>
				 //deselect selected vehicle
				 for(let j=0; j<oldvids.length; j++){ //unhighlight old cells, no children
					 let sq=null
					if(selectedVehicle.orientation===0){ //horizontal
						if(oldvids[j]===exitid){
							sq=<Square key={oldvids[j]} id={oldvids[j]} children={<Car id={selectedVehicle.vehicleId} row={Math.trunc(oldvids[j]/this.state.cols)} col={oldvids[j]%this.state.rows} cell={hcar[j]}/>} onClick={this.onSquareClick.bind(this)} selected={false} exit={exitlabel}/>
						}else{
							sq=<Square key={oldvids[j]} id={oldvids[j]} children={<Car id={selectedVehicle.vehicleId} row={Math.trunc(oldvids[j]/this.state.cols)} col={oldvids[j]%this.state.rows} cell={hcar[j]}/>} onClick={this.onSquareClick.bind(this)} selected={false}/>
						}
					}else if(selectedVehicle.orientation===1){ //verticle
						if(oldvids[j]===exitid){
							sq=<Square key={oldvids[j]} id={oldvids[j]} children={<Car id={selectedVehicle.vehicleId} row={Math.trunc(oldvids[j]/this.state.cols)} col={oldvids[j]%this.state.rows} cell={vcar[j]}/>} onClick={this.onSquareClick.bind(this)} selected={false} exit={exitlabel}/>
						}else{
							sq=<Square key={oldvids[j]} id={oldvids[j]} children={<Car id={selectedVehicle.vehicleId} row={Math.trunc(oldvids[j]/this.state.cols)} col={oldvids[j]%this.state.rows} cell={vcar[j]}/>} onClick={this.onSquareClick.bind(this)} selected={false}/>
						}
					}
					localsquares[oldvids[j]]=sq
				}
			}
			localvehicles[index]=selectedVehicle
		}else {
			let newpos = moveTruck(selectedVehicle,moveToCell,empty)
			//console.log("truck new vehicle position, newpos",newpos)
			if(newpos!==null){ //can move safely
				for(let j=0; j<oldvids.length; j++){ //unhighlight old cells, no children
					let sq=null
					if(oldvids[j]===exitid){
						sq=<Square key={oldvids[j]} id={oldvids[j]} children={null} onClick={this.onSquareClick.bind(this)} selected={false} exit={exitlabel}/>
					}else{
						sq=<Square key={oldvids[j]} id={oldvids[j]} children={null} onClick={this.onSquareClick.bind(this)} selected={false}/>
					}
					localsquares[oldvids[j]]=sq
				}
				selectedVehicle.updateVehicleCoordinates(newpos.slice(0,3)) //update vehicle properties
				for(let i=0; i<selectedVehicle.vehicleCoordinates.length; i++){ //update new vehicle ids in vehicles array
					newvids.push(selectedVehicle.vehicleCoordinates[i][0]*this.state.cols+selectedVehicle.vehicleCoordinates[i][1])
				}
				moveDesc = this.generateMoveTextTruck(selectedVehicle,oldvids,newvids,newpos)
				for(let j=0; j<newvids.length; j++){ //highlight new cells with the car
					let sq=null
						if(selectedVehicle.vehicleId.match(/t/i)){
							if(selectedVehicle.orientation===0){ //horizontal
								if(newvids[j]===exitid){
									sq=<Square key={newvids[j]} id={newvids[j]} children={<Truck id={selectedVehicle.vehicleId} row={Math.trunc(newvids[j]/this.state.cols)} col={newvids[j]%this.state.rows} cell={htruck[j]}/>} onClick={this.onSquareClick.bind(this)} selected={false} exit={exitlabel}/>
								}else{
									sq=<Square key={newvids[j]} id={newvids[j]} children={<Truck id={selectedVehicle.vehicleId} row={Math.trunc(newvids[j]/this.state.cols)} col={newvids[j]%this.state.rows} cell={htruck[j]}/>} onClick={this.onSquareClick.bind(this)} selected={false}/>
								}
							}else if(selectedVehicle.orientation===1){ //verticle
								if(newvids[j]===exitid){
									sq=<Square key={newvids[j]} id={newvids[j]} children={<Truck id={selectedVehicle.vehicleId} row={Math.trunc(newvids[j]/this.state.cols)} col={newvids[j]%this.state.rows} cell={vtruck[j]}/>} onClick={this.onSquareClick.bind(this)} selected={false} exit={exitlabel}/>
								}else{
									sq=<Square key={newvids[j]} id={newvids[j]} children={<Truck id={selectedVehicle.vehicleId} row={Math.trunc(newvids[j]/this.state.cols)} col={newvids[j]%this.state.rows} cell={vtruck[j]}/>} onClick={this.onSquareClick.bind(this)} selected={false}/>
								}
							}
						}
					localsquares[newvids[j]]=sq
				}
			}else if(newpos===null){ //tried to move multiple cells at once. bad move. reset everything
				 msg = <Alert variant="warning">Can not move vehicles by multiple cells. Move only by 1 cell at a time</Alert>
				 //deselect selected vehicle
				 for(let j=0; j<oldvids.length; j++){ //unhighlight old cells, no children
					let sq= null
					if(selectedVehicle.orientation===0){ //horizontal
						if(oldvids[j]===exitid){
							sq=<Square key={oldvids[j]} id={oldvids[j]} children={<Truck id={selectedVehicle.vehicleId} row={Math.trunc(oldvids[j]/this.state.cols)} col={oldvids[j]%this.state.rows} cell={htruck[j]}/>} onClick={this.onSquareClick.bind(this)} selected={false} exit={exitlabel}/>
						}else{
							sq=<Square key={oldvids[j]} id={oldvids[j]} children={<Truck id={selectedVehicle.vehicleId} row={Math.trunc(oldvids[j]/this.state.cols)} col={oldvids[j]%this.state.rows} cell={htruck[j]}/>} onClick={this.onSquareClick.bind(this)} selected={false}/>
						}
					}else if(selectedVehicle.orientation===1){ //verticle
						if(oldvids[j]===exitid){
							sq=<Square key={oldvids[j]} id={oldvids[j]} children={<Truck id={selectedVehicle.vehicleId} row={Math.trunc(oldvids[j]/this.state.cols)} col={oldvids[j]%this.state.rows} cell={vtruck[j]}/>} onClick={this.onSquareClick.bind(this)} selected={false} exit={exitlabel}/>
						}else{
							sq=<Square key={oldvids[j]} id={oldvids[j]} children={<Truck id={selectedVehicle.vehicleId} row={Math.trunc(oldvids[j]/this.state.cols)} col={oldvids[j]%this.state.rows} cell={vtruck[j]}/>} onClick={this.onSquareClick.bind(this)} selected={false}/>
						}
					}
					localsquares[oldvids[j]]=sq
				}
			}
			localvehicles[index]=selectedVehicle
		}
		return [localsquares,localvehicles,null,-1,msg,moveDesc];
	}

	playerWon(localvehicles){
		let exitid=this.state.exit[0]*this.state.cols+this.state.exit[1]
		for(let i=0;i<localvehicles.length; i++){
			if(localvehicles[i].vehicleId.match("C0")){ //goal car is at exit cell
				let c=localvehicles[i].vehicleCoordinates
				for(let j=0; j<c.length; j++){
					let val=c[j][0]*this.state.cols+c[j][1]
					if(val===exitid){
						return true
					}
				}
			}
		}
		return false
	}

	cellEmpty(moveToCell){
		let vehicleCurrent=this.findVehicleAtSelectedCell(Math.trunc(moveToCell/this.state.cols),moveToCell%this.state.rows)
		if(vehicleCurrent===null){
			return true
		}else{
			return false
		}
	}

	async fetch(input) {
        let id = input.split(":")[0]; //conveys type of request. start game? save result?
        let data = input.split(":")[1]; //gives the parameters needed for the server to produce an output for the request
        let clientRequest = {   // Create client->server request message. IMPORTANT: This object must match the structure of whatever object the server is reading into
            parameters: data,
            type: id
        };
        try {
            // Attempt to send `clientRequest` via a POST request to java backend running on port 9999
            // Notice how the end of the url below matches what the server is listening on
            let serverUrl = window.location.href.substring(0, window.location.href.length - 6) + ":9999/handleClientRequest";
            let jsonReturned = await fetch(serverUrl,
                {
                    method: "POST",
                    body: JSON.stringify(clientRequest)
                });
            let ret = await jsonReturned.json();// Wait for server to return and convert it to json.
            let retJSON = JSON.parse(ret); //parse ret to JSON object.
            let responseType = retJSON.type;//behavior changes based on the value here
            if(responseType=="START"){
							this.readGame(retJSON.game,retJSON.exit,retJSON.uuid,retJSON.badCar)
						}
         } catch (e) {
           let err =
						<Alert variant="danger">
							<h4 className="alert-heading">Error</h4>
							There was an error connecting to the remote server. <p>Contact administrator: sachini@cs.colostate.edu </p>
						</Alert>
					 this.setState({
							errorMsg: err
					});
        }
    }

	render() {//only support 6 column boards
		return(
			<Container>
			 <Row>
				<Col className="instructions">
					&#8227; Click to on a vehicle (red or green) to select it.
					<br/>&#8227; Click on any adjacent empty cell to move the selected vehicle to the empty cell.
					<br/>&#8227; A vehicle can only be moved <b> one cell at a time</b>, in the <b>same direction</b> (e.g., vertically aligned vehicle can only be moved up or down)
					<br/>&#8227; To win the game, move the red car to the cell without a black border.
					<br/>&#8227; Some vehicles on the board need not be moved to solve the puzzle.
				</Col>
			</Row>
			<Row>
				<Col>
					{this.state.start ? <Button color="primary" size="sm" className="NewPuzzle" onClick={this.handleStartButtonClick}>New Puzzle</Button> : null}
					<div className="Board6c">{this.state.squares}</div>
				</Col>
				<Col>
					<div className="Msg">{this.state.error}</div>
					<div className="Msg">{this.state.win}</div>
					<div className="Msg">{this.state.modal}</div>
					<div className="Msg">{this.state.errorMsg}</div>
				</Col>
			</Row>
		 </Container>
		);
  }
}
export default Board;
