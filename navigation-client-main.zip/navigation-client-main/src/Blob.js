import React from 'react'

class Blob extends React.Component{

  constructor(props){
    super(props);
  };

  render(){
    let style = ""
    if(this.props.agent === "TIME"){
			style = "blob-purple"
		}else if(this.props.agent === "SAFETY"){
			style = "blob-gold"
		}else if(this.props.agent === "TIME_SAFETY"){
			style = "blob-turquoise"
		}

    return(
        <div className={style}></div>

    );
  }
}export default Blob;
