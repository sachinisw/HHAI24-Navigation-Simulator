import React from 'react'

class Square extends React.Component{
	constructor(props){
		super(props);
	}


	render(){
		let sq=
		<div className={this.props.style} >
			<div className="icon grid-span-icon">
			</div>

			<div>
				{this.props.time}
			</div>

			<div></div>

			<div></div>

			<div className="grid-span-blob directionLabels">
				{this.props.blob}
				{this.props.label}
			</div>
		</div>

		return (
				sq
			);
	}
}
export default Square;
