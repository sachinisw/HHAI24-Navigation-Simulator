import React from 'react'
import Container from 'react-bootstrap/Container'
import Card from 'react-bootstrap/Card'
import Row from 'react-bootstrap/Row'
import Col from 'react-bootstrap/Col'

class AgentProfile extends React.Component{

  constructor(props) {
		super(props);
  }


  render() {
    let profile = ""
    let name = ""

    if(this.props.profile==="TIME_SAFETY"){
      profile = "TIME AND SAFETY"
    }else if(this.props.profile==="TIME"){
      name = "Dede"
      profile = "Dede will propose directions to minimize the distance (i.e., the number of blocks) travelled. The directions might make you go through red blocks, which will affect the time budget."
    }else if(this.props.profile==="SAFETY"){
      name = "Cece"
      profile = "Cece proposes directions to avoid red blocks and minimize the travel time. The directions might make you travel a longer distance, which will affect the blocks budget."
    }

     return (

       <Row>
  			<Col sm className="instructions">

         <Card>
           <Card.Header><img className="panel-icon-img" src="../images/robot.png"/><b>Assistant {name}</b></Card.Header>

   			  <Card.Body>
   				<Card.Text>
             {profile}
   				</Card.Text>
   			  </Card.Body>
   			</Card>

        </Col>
  		 </Row>



    );
  }

}export default AgentProfile;
