const path = require('path')
const express = require('express')
const helmet = require('helmet')
const http = require('http')
const https = require('https')
const fs = require('fs')
//const crypto = require('crypto')

//'modele.exports' is commonJS module syntax. NodeJS uses that. ES6 module syntax uses the 'export' keyword
//https://stackoverflow.com/questions/11744975/enabling-https-on-express-js
module.exports = function initServer(){
    const app = express()
    const indexPath = path.join(__dirname, 'index.html')
    const publicPath = express.static(path.join(__dirname, 'public'))
    const imgPath = express.static(path.join(__dirname, 'images'))
    // const csp = [ "'Content-Security-Policy-Report-Only'",
    //               "default-src 'self'",
    //               "font-src 'unsafe-inline'",
    //               "img-src 'unsafe-inline'",
    //               "script-src 'unsafe-inline'",
    //               "style-src 'unsafe-inline'",
    //               "connect-src http://localhost:9999/api"
    //           ].join(";")

    app.use(helmet({contentSecurityPolicy: false,}))
    app.disable('x-powered-by')
    app.use('/public', publicPath)
    app.use('/images', imgPath)
    app.use(helmet.xssFilter())
    app.use(helmet.frameguard('deny'))
    app.use(helmet.ieNoOpen())
    app.use(helmet.noSniff())
    // app.use((req, res, next) => {
    //   res.setHeader("Content-Security-Policy", csp);
    //   console.log(res);
    //   next();
    // });

    app.get('/', function (_, res) { res.sendFile(indexPath) } ) //serve the index.html file to the browser



	//key is the private key, cert is the certificate ---- TODO: change to this on deploy
	//const httpsserver = https.createServer({
	//	key:fs.readFileSync('/s/chopin/k/grad/sachini/certificates/server.key'),
	//	cert:fs.readFileSync('/s/chopin/k/grad/sachini/certificates/aiplanning_cs_colostate_edu_cert.cer')},app);
	const httpserver = http.createServer(app);
	const httpsserver = null;
    return [httpsserver,httpserver];
}
